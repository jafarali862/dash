<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\TokenSetting;
use Faker\Generator as Faker;

$factory->define(TokenSetting::class, function (Faker $faker) {
    return [
        //
    ];
});
