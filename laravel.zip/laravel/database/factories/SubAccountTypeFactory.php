<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\SubAccountType;
use Faker\Generator as Faker;

$factory->define(SubAccountType::class, function (Faker $faker) {
    return [
        //
    ];
});
