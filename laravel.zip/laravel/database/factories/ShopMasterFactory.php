<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\ShopMaster;
use Faker\Generator as Faker;

$factory->define(ShopMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
