<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AreaCode;
use Faker\Generator as Faker;

$factory->define(AreaCode::class, function (Faker $faker) {
    return [
        //
    ];
});
