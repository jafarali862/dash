<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\AddOn;
use Faker\Generator as Faker;

$factory->define(AddOn::class, function (Faker $faker) {
    return [
        //
    ];
});
