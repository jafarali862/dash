<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\TableSetting;
use Faker\Generator as Faker;

$factory->define(TableSetting::class, function (Faker $faker) {
    return [
        //
    ];
});
