<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\CustomerReciept;
use Faker\Generator as Faker;

$factory->define(CustomerReciept::class, function (Faker $faker) {
    return [
        //
    ];
});
