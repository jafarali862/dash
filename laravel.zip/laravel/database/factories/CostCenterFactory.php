<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CostCenter;
use Faker\Generator as Faker;

$factory->define(CostCenter::class, function (Faker $faker) {
    return [
        //
    ];
});
