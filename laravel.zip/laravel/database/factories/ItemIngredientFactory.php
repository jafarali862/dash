<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\ItemIngredient;
use Faker\Generator as Faker;

$factory->define(ItemIngredient::class, function (Faker $faker) {
    return [
        //
    ];
});
