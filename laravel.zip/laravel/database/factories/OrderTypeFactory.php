<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\OrderType;
use Faker\Generator as Faker;

$factory->define(OrderType::class, function (Faker $faker) {
    return [
        //
    ];
});
