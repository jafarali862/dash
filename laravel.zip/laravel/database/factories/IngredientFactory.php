<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Ingredient;
use Faker\Generator as Faker;

$factory->define(Ingredient::class, function (Faker $faker) {
    return [
        //
    ];
});
