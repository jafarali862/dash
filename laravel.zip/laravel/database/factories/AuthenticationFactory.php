<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Authentication;
use Faker\Generator as Faker;

$factory->define(Authentication::class, function (Faker $faker) {
    return [
        //
    ];
});
