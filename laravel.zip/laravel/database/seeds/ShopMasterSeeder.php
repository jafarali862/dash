<?php

use Illuminate\Database\Seeder;
use App\Model\ShopMaster;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str; 

class ShopMasterSeeder extends Seeder
{
    
    public function run()
    { 
        $date = '2020-08-11';
 
        $users = [
            [
            'id'             => 1,
            'name'           => 'Gnet admin',
            'eng_description' => 'Gnet Admin Dashboard',
            'line_1' => 'Test loc 1',
            'city' => 'clt',
            'state' => 'kar',
            'country' => 'ind',
            'primary_phone' => '9898989898',
            'start_date' => date('d-m-y'),
            'expiry_date' => date('Y-m-d', strtotime("+12 months $date")),
            'payment_recieved' => 1


            ],
        ];

        ShopMaster::insert($users);
    }
}
