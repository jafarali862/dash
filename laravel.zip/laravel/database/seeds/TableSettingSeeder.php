<?php

use Illuminate\Database\Seeder;
use App\Model\TableSetting;

class TableSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TableSetting::create([
           'table_name' =>'Table 1',
           'created_by' =>1,
           'is_active' =>1
        ],
        [
           'table_name' =>'Table 2',
           'created_by' =>1,
           'is_active' =>1
        ]
    );
    }
}
