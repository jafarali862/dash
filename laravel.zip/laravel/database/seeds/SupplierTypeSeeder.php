<?php

use App\Model\SupplierType;
use Illuminate\Database\Seeder;

class SupplierTypeSeeder extends Seeder
{
    
    public function run()
    {
        $data = [
            [
                'english_desptn'          => 'General Supplier',
                'arabic_desptn'           => 'General Supplier',
       			'status'                  => 1,
            ],
        ];

        SupplierType::insert($data);
    }
}
