<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run()
    {
        //Permission::truncate();
        
       // Role::truncate();

        $role = Role::create(['name' => 'shop']);
        $shop_user_role = Role::create(['name' => 'shop_user']);

        // main permissions
        $role->givePermissionTo(Permission::create(['name' => 'sales']));
        $role->givePermissionTo(Permission::create(['name' => 'wms']));
        $role->givePermissionTo(Permission::create(['name' => 'purchase']));
        $role->givePermissionTo(Permission::create(['name' => 'master_data']));
        $role->givePermissionTo(Permission::create(['name' => 'accounts']));
        $role->givePermissionTo(Permission::create(['name' => 'reports']));
        $role->givePermissionTo(Permission::create(['name' => 'admin']));

        // sub permissions of sales
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'restaurant']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'sales return']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'quotation']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'stock enquiry']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'damage']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'customer receipt']));

        // sub permissions of wms
        // $shop_user_role->givePermissionTo(Permission::create(['name' => 'wms_delivery_note']));

        // sub permissions of purchase
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'purchase return']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'supplier payment']));

        // sub permissions of master_data
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'setup']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'item']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'customer']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'supplier']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'accounts master']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'barcode']));

        // sub permissions of accounts
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'cash reciept']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'cash payment']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'bank deposit']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'bank payment']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'jounal entry']));

        // sub permissions of reports
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'sales report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'purchase report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'stock report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'pricelist report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'inventory report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'accounts report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'final accounts report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'vat report with expenses']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'vat report']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'stock report with damage']));

        // sub permissions of admin
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'users']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'security']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'admin accounts']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'opening stock']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'stock updation']));
        $shop_user_role->givePermissionTo(Permission::create(['name' => 'account updation']));
    }
}
