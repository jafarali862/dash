<?php

use App\Model\CustomerType;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str; 
use Illuminate\Database\Seeder;

class CustomerTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        CustomerType::create([
            'english_desptn' =>'General Customer',
            'arabic_desptn' =>'General Customer',
            'is_active' => 1,
         ]);
    }
}
