<?php

use App\Model\Ingredient;
use Illuminate\Database\Seeder;

class IngredientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ingredient::create([
           'ingredient' =>'Kuboos',
           'min_stock' => 100,
           'created_by' =>1,
           'is_active' =>1
        ],
        [
           'ingredient' =>'mayonnaise',
           'min_stock' => 100,
           'created_by' =>1,
           'is_active' =>1
        ]
    );
    }
}
