<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            ShopMasterSeeder::class,
            AuthenticationSeeder::class,
            CustomerTypeSeeder::class,
            SupplierTypeSeeder::class,
            RolePermissionSeeder::class,
            // IngredientSeeder::class,
            // ItemIngredientSeeder::class,
            // TableSettingSeeder::class,
            // TokenSettingSeeder::class,
            // OrderTypeSeeder::class
        ]);
    }
}
