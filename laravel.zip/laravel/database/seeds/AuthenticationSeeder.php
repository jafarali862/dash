<?php

use Illuminate\Database\Seeder;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str; 

class AuthenticationSeeder extends Seeder
{
   
    public function run()
    {
        User::create([
           'name' =>'Gnet admin',
           'email' =>'admin@gmail.com',
           'password' =>Hash::make('password'),
           'role'     =>'super admin',
           'remember_token' =>str::random(40),
           'shop_master_id' => 1,
        ]);
    }
}
