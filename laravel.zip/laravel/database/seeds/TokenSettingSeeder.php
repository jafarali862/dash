<?php

use App\Model\TokenSetting;
use Illuminate\Database\Seeder;

class TokenSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TokenSetting::create([
           'token_start_no' =>'Table 1',
           'start_time' => '05:00:00',
           'end_time' => '01:00:00',
           'created_by' =>1,
           'is_active' =>1
        ]);
    }
}
