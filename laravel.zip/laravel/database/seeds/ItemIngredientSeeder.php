<?php

use App\Model\ItemIngredient;
use Illuminate\Database\Seeder;

class ItemIngredientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         ItemIngredient::create([
           'item_id' =>1,
           'ingredient_id' => 1,
           'qty_used' => 10,
           'created_by' =>1,
           'is_active' =>1
        ]);
    }
}
