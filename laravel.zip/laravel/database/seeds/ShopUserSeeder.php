<?php

use Illuminate\Database\Seeder;

class ShopUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //App\ShopUser::truncate();

        App\ShopUser::create([
            'shop_id' => 1,
            'user_id' => 1,
        ]);

        // App\ShopUser::create([
        //     'shop_id' => 2,
        //     'user_id' => 4,
        // ]);

        // App\ShopUser::create([
        //     'shop_id' => 2,
        //     'user_id' => 5,
        // ]);

        // App\ShopUser::create([
        //     'shop_id' => 2,
        //     'user_id' => 6,
        // ]);
    }
}
