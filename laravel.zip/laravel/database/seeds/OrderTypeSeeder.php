<?php

use App\Model\OrderType;
use Illuminate\Database\Seeder;

class OrderTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        OrderType::create([
           'order_type' =>'DINE IN',
           'created_by' =>1,
           'is_active' =>1
        ],
        [
           'order_type' =>'TAKE AWAY',
           'created_by' =>1,
           'is_active' =>1
        ],
        [
           'order_type' =>'DELIVERY',
           'created_by' =>1,
           'is_active' =>1
        ]
    );
    }
}
