<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShopMastersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shop_masters', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('photo',200)->nullable();
            $table->string('eng_description',1000)->nullable();
            $table->string('arabic_description',1000)->nullable();
            $table->string('line_1',200);
            $table->string('line_2',200)->nullable();
            $table->string('city',50)->nullable();
            $table->string('state',50)->nullable();
            $table->string('country',50);
            $table->string('pin',15)->nullable();
            $table->string('primary_phone',20);
            $table->string('secondary_phone',20)->nullable();
            $table->date('start_date');
            $table->date('expiry_date');
            $table->boolean('payment_recieved')->default('0');
            $table->boolean('is_active')->default('1');
            $table->string('fb_url')->nullable();
            $table->integer('linked_url')->nullable();
            $table->integer('tiwtter_url')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shop_masters');
    }
}
