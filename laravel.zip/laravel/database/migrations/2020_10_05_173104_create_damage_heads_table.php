<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDamageHeadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('damage_heads', function (Blueprint $table) {
            $table->id();
            $table->string('doc_id')->nullable();
            $table->date('date')->nullable();
            $table->unsignedBigInteger('customer_id');
            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            $table->string('doc_ref')->nullable();
            $table->string('ret_type')->nullable();
            $table->string('credit')->nullable();
            $table->string('dis_val')->nullable();
            $table->date('tran_date')->nullable();
            $table->boolean('doc_status')->default(0);
            $table->integer('delivery_max_days')->nullable();
            $table->unsignedBigInteger('warehouse_id');
            $table->foreign('warehouse_id')->references('id')->on('warehouse_masters')->onDelete('cascade');
            $table->unsignedBigInteger('s_point_id');
            $table->foreign('s_point_id')->references('id')->on('s_point_masters')->onDelete('cascade');
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('id')->on('user_masters')->onDelete('cascade');
            $table->string('remark')->nullable();
            $table->integer('sman_id')->nullable();
            $table->integer('cacc_id')->nullable();
            $table->double('amount')->nullable();
            $table->double('round_val')->nullable();
            $table->double('grant_total');
            $table->date('olddoc_date');
            $table->date('date_to_sync');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('model_damage_heads');
    }
}
