<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWarehouseMastersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('warehouse_masters', function (Blueprint $table) {
            $table->id();
            $table->string('english_desptn');
            $table->string('arabic_desptn')->nullable();
            $table->unsignedBigInteger('warehouse_type_id');
            $table->foreign('warehouse_type_id')->references('id')->on('warehouse_type_masters')->onDelete('cascade');
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->integer('branch_id')->nullable();
            $table->integer('flag')->nullable();
            $table->boolean('is_active')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('warehouse_masters');
    }
}
