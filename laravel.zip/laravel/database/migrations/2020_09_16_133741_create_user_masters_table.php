<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserMastersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_masters', function (Blueprint $table) {
            $table->id();
            $table->string('eng_description',1000)->nullable();
            $table->string('arabic_description',1000)->nullable();
            $table->unsignedBigInteger('user_typer_master_id');
            $table->foreign('user_typer_master_id')->references('id')->on('user_type_masters')->onDelete('cascade');
            $table->string('user_login',200)->nullable();
            $table->string('password',200)->nullable();
            $table->integer('role_id')->nullable();
            $table->integer('branch_id')->nullable();
            $table->integer('fk_id')->nullable();
            $table->boolean('flag')->default('0');
            $table->unsignedBigInteger('s_point_master_id');
            $table->foreign('s_point_master_id')->references('id')->on('s_point_masters')->onDelete('cascade');
            $table->boolean('is_active')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_masters');
    }
}
