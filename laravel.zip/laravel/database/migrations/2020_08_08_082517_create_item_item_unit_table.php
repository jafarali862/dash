<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemItemUnitTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_item_unit', function (Blueprint $table) {
            $table->unsignedBigInteger('item_id');
            $table->unsignedBigInteger('item_unit_id');

            //FOREIGN KEY CONSTRAINTS
            $table->foreign('item_id')->references('id')->on('items')->onDelete('cascade');
            $table->foreign('item_unit_id')->references('id')->on('item_units')->onDelete('cascade');

            $table->integer('cost'); 
            $table->integer('price');
            $table->integer('quantity');
            $table->integer('minimum_stock')->nullable();
            $table->boolean('is_view')->default('1');

            //SETTING THE PRIMARY KEYS
            $table->primary(['item_id','item_unit_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_item_unit');
    }
}
