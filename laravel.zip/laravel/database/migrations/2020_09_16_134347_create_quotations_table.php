<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuotationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quotations', function (Blueprint $table) {
            $table->id();
            $table->string('quotation_number')->nullable();
            $table->date('date');
            $table->unsignedBigInteger('customer_id');
            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            $table->integer('quantity')->nullable();
            $table->integer('any');
            $table->integer('price')->nullable();
            $table->string('remark1')->nullable();
            $table->string('remark2')->nullable();
            $table->integer('free')->default(0);
            $table->double('discount')->default(0);
            $table->double('dispers')->default(0);
            $table->integer('status')->default(0);
            $table->double('sub_total')->default(0);
            $table->double('grant_total')->default(0);
            $table->double('cost')->default(0);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quotations');
    }
}
