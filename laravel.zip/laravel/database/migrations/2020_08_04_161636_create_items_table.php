<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class CreateItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id()->start_from(1000);
            $table->unsignedBigInteger('item_group_id');
            $table->string('english_description',2000); 
            $table->string('arabic_description',2000);
            $table->string('english_short_description',200)->nullable(); 
            $table->string('arabic_short_description',200)->nullable();
            $table->double('vat')->nullable();
            $table->string('barcode',200)->nullable();
            $table->string('country_id',10)->nullable();
            $table->boolean('is_vat')->nullable(); 
            $table->boolean('is_active')->default('1');
            $table->string('image',200)->nullable();
            $table->integer('opening_stock')->nullable();

         //FOREIGN KEY CONSTRAINTS
            $table->foreign('item_group_id')->references('id')->on('item_groups')->onDelete('cascade');
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->timestamps();
        });

        //then set autoincrement to 1000
        //after creating the table
        DB::update("ALTER TABLE items AUTO_INCREMENT = 1000;");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('items');
    }
}
