<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->string('invoice_number')->nullable();
            $table->date('date');
            $table->string('cnt_no')->nullable();
            $table->unsignedBigInteger('customer_id');
            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->integer('any');
            $table->string('cash_or_card');
            $table->string('po_no');
            $table->string('del_no');
            $table->string('remark1')->nullable();
            $table->string('remark2')->nullable();
            $table->bigInteger('phone_no');
            $table->double('discount')->nullable();
            $table->double('sub_total');
            $table->double('grant_total');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoices');
    }
}
