<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('sub_accnt_type_id');
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('sub_accnt_type_id')->references('id')->on('account_type_subs')->onDelete('cascade');
            $table->string('english_desptn');
            $table->string('arabic_desptn')->nullable();
            $table->integer('open_balance')->nullable();
            $table->string('balance_start_date')->nullable();
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->boolean('is_active')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accounts');
    }
}
