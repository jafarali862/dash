<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id()->start_from(1000);
            $table->unsignedBigInteger('cust_type_id');
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('cust_type_id')->references('id')->on('customer_types')->onDelete('cascade');
            $table->string('cust_name'); 
            $table->string('english_short_desptn')->nullable();
            $table->string('arabic_short_desptn')->nullable();
            $table->string('english_addrs')->nullable();
            $table->string('arabic_addrs')->nullable();
            $table->bigInteger('mobile')->nullable();
            $table->string('fax')->nullable();
            $table->string('email')->nullable();
            $table->string('vat_no')->nullable();
            $table->integer('credit_check')->nullable();
            $table->integer('credit_hold')->nullable();
            $table->integer('credit_limit')->nullable();
            // change to foreign key
            $table->integer('price_list_id')->nullable();
            // --------
            $table->string('customer_ref')->nullable();
            $table->integer('is_credit')->nullable();
            // change to foreign key
            $table->integer('point_type_id')->nullable();
            // ----------------
             $table->unsignedBigInteger('area_code_id')->nullable();;
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('area_code_id')->references('id')->on('area_codes')->onDelete('cascade');
            $table->string('own_code')->nullable();
            $table->unsignedBigInteger('sales_man_id')->nullable();;
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('sales_man_id')->references('id')->on('sales_men')->onDelete('cascade');
            $table->unsignedBigInteger('cost_center_id')->nullable();;
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('cost_center_id')->references('id')->on('cost_centers')->onDelete('cascade');
            $table->unsignedBigInteger('supplier_id')->nullable();
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
            $table->date('vist_date')->nullable();
            $table->boolean('is_regular_cust');
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->boolean('is_active')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
