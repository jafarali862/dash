<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccountTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('account_transactions', function (Blueprint $table) {
            $table->id()->start_from(1000);
            $table->string('doc_type')->nullable();
            $table->integer('doc_id')->nullable();
            $table->enum('type', array('cash','bank','cash-receipt','bank-payment','journal-entry'))->nullable();
            $table->date('doc_date');
            $table->string('trans_type')->default('R');
            $table->string('doc_ref')->nullable();
            $table->integer('amount')->default('0');
            $table->string('remarks')->nullable();
            $table->string('cheque_no')->nullable();
            $table->date('cheque_date')->nullable();
            $table->date('trans_date')->nullable();
            $table->boolean('doc_status')->default('0');
            $table->boolean('flag')->default('0');
            $table->integer('vat')->default('0');
            $table->integer('account_id');
            $table->integer('user_id')->default('1');
            $table->string('description')->nullable();
            $table->integer('bank_id')->nullable();
            $table->integer('cost_id')->nullable();
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->boolean('is_active')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('account_transactions');
    }
}
