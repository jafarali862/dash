<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSuppliersTable extends Migration
{
   
    public function up()
    {
        Schema::create('suppliers', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('arabic_desptn')->nullable();
            $table->unsignedBigInteger('supplier_type_id');
            //FOREIGN KEY CONSTRAINTS
            $table->foreign('supplier_type_id')->references('id')->on('supplier_types')->onDelete('cascade');
            $table->string('eng_address')->nullable();
            $table->string('arab_address')->nullable();
            $table->string('email')->unique();
            $table->string('phone',20)->nullable();
            $table->string('mobile',20)->nullable();
            $table->string('fax')->nullable();
            $table->string('cost_center')->nullable();
            $table->integer('credit_limit')->nullable();
            $table->string('customer_link')->nullable();
            $table->integer('vat_no')->nullable();
            $table->integer('pmt_type')->nullable();
            $table->string('supplier_ref')->nullable();
            $table->boolean('is_active');
            $table->integer('created_by');
            $table->timestamps();
        });
    }

  
    public function down()
    {
        Schema::dropIfExists('suppliers');
    }
}
