<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSupplierTypesTable extends Migration
{
   
    public function up()
    {
        Schema::create('supplier_types', function (Blueprint $table) {
            $table->id();
            $table->string('english_desptn');
            $table->string('arabic_desptn');
            $table->boolean('status');
            $table->timestamps();
        });
    }

   
    public function down()
    {
        Schema::dropIfExists('supplier_types');
    }
}
