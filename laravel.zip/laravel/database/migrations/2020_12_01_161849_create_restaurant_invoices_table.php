<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRestaurantInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('restaurant_invoices', function (Blueprint $table) {
            $table->id();
            $table->string('invoice_number')->nullable();
            $table->double('token_no');
            $table->unsignedBigInteger('table_id')->nullable();
            $table->foreign('table_id')->references('id')->on('table_settings')->onDelete('cascade');
            $table->date('date');
            $table->string('cnt_no')->nullable();
            $table->unsignedBigInteger('customer_id');
            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            $table->integer('any');
            $table->string('cash_or_card');
            $table->string('po_no');
            $table->string('del_no');
            $table->string('remark1')->nullable();
            $table->string('remark2')->nullable();
            $table->bigInteger('phone_no');
            $table->double('discount')->nullable();
            $table->double('sub_total');
            $table->double('grant_total');
            $table->string('paid/hold');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->foreign('created_by')->references('id')->on('shop_masters')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('restaurant_invoices');
    }
}
