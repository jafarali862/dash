<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// login
Route::get('/login', ['as' => 'login', 'uses' => 'AuthenticationController@index']);

// pwd reset
Route::get('/forgotpassword', ['as' => 'forgotpassword', 'uses' => 'AuthenticationController@forgotPassword']);

// post login data
Route::post('/auth/login','AuthenticationController@authentication');

// Sign out function
Route::get('sign-out', ['as' => 'sign-out', 'uses' => 'AuthenticationController@signOut']);

// Aj Routes
Route::group(['middleware'=>'auth'],function(){

    Route::get('/superadmin/dashboard', ['as' => 'superadmin.dashboard', 'uses' => 'AuthenticationController@superadminDashBorad']);

    Route::get('shop-register/status/change','SuperAdmin\ShopMasterController@statusChangeShop');
    Route::resource('shop-register', 'SuperAdmin\ShopMasterController');

    // permissions module - Shyam
    Route::get('permissions/{search?}', 'SuperAdmin\PermissionController@index')->name('permissions.index');
    Route::post('/shop/accessPermission','SuperAdmin\PermissionController@accessPermission');
    Route::post('/shop/revokePermission','SuperAdmin\PermissionController@revokePermission');
    Route::get('/permissions/users/{id}/{search?}', 'SuperAdmin\UserPermissionController@getUsers')->name('permissions.users');
    Route::get('/shopuser/create/{id}', 'SuperAdmin\UserPermissionController@addShopUser')->name('shopuser.create');
    Route::post('/shopuser/store/{id}', 'SuperAdmin\UserPermissionController@storeShopUser')->name('shopuser.store');
    Route::post('/shopuser/revokePermission', 'SuperAdmin\UserPermissionController@revokePermission')->name('user-permissions.revoke');
    Route::post('/shopuser/accessPermission', 'SuperAdmin\UserPermissionController@accessPermission')->name('user-permissions.access');
    Route::post('shop-user/status/change','SuperAdmin\UserPermissionController@changeShopUserStatus');
    Route::post('shop-user/delete-user','SuperAdmin\UserPermissionController@deleteShopUserStatus')->name('shop-user.delete');
});

Route::group(['middleware'=>'checkLogin'],function(){

    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){ 

        Route::get('/',['as' => 'shop.dashboard', 'uses' => 'ShopCommonController@shopDashBoard']);

        Route::get('items/status/change','ItemController@statusChangeItems');
        Route::resource('items', 'ItemController');
        
        Route::get('item-groups/status/change','ItemGroupController@statusChangeItemGroup');
        Route::resource('item-groups', 'ItemGroupController');
       
        Route::get('item-units/status/change','ItemUnitController@statusChangeItemUnit');             
        Route::resource('item-units', 'ItemUnitController');
        
    });

        // master bank
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('bank/status-change','BankController@statusChange');
        Route::resource('bank', 'BankController');
    });

    // customer (customer of shops)
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::get('/shop-customer/status/change' ,'CustomerController@statusChange');
        Route::resource('shop-customer','CustomerController');
        Route::post('/saveCustomerDetails','CustomerController@customerSave');
    });

    // Account type
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/account-type/status-change' ,'AccountTypeController@statusChange');
        Route::resource('account-type', 'AccountTypeController');

        Route::get('account-transactions/create/{type?}','PaymentController@create');
        Route::get('account-transactions/show/{type?}','PaymentController@show');
        Route::post('/account-transactions/status/change' ,'PaymentController@statusChange');
        Route::get('account-transactions/edit/{id}/{type?}','PaymentController@edit');
        Route::delete('account-transactions/delete/{id}','PaymentController@delete');
        Route::resource('account-transactions', 'PaymentController')->except([
            'create','show','edit'
        ]);
    });

       Route::get('create-journal','Admin\JournalController@createJournal');
        Route::post('save-journal','Admin\JournalController@saveJournal')->name('saveJournal');
        Route::get('view-journal','Admin\JournalController@viewJournal')->name('view-journal');
        Route::post('/journal-code/status/change' ,'Admin\JournalController@statusChange');
        Route::resource('journal-code', 'Admin\JournalController');
        Route::get('journal-code/edit/{id}','Admin\JournalController@edit');


    // Sub Account type
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
     Route::post('/sub-account-type/status-change' ,'SubAccountTypeController@statusChange');
        Route::resource('sub-account-type', 'SubAccountTypeController');
    });

    // ACCOOUNT MASTER
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/account/status-change' ,'AccountController@statusChange');
        Route::resource('account', 'AccountController');
    });

    // Table Settings 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/table-settings/status-change' ,'TableSettingController@statusChange');
        Route::post('/saveTableDetails','TableSettingController@tableSave');
        Route::post('/editTableDetails','TableSettingController@updateTableSettings');
        Route::resource('table-settings', 'TableSettingController');

    });

    // Token Settings 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/token-settings/status-change' ,'TokenSettingController@statusChange');
        Route::post('/saveTokenDetails','TokenSettingController@tokenSave');
        Route::post('/updateTokenDetails','TokenSettingController@updateTokenSettings');
        Route::resource('token-settings', 'TokenSettingController');

    });

    // Order Type 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/order-type/status-change' ,'OrderTypeController@statusChange');
        Route::post('/saveOrderTypeDetails','OrderTypeController@orderTypeSave');
        Route::post('/updateOrderTypeDetails','OrderTypeController@updateorderType');
        Route::resource('order-type', 'OrderTypeController');

    });

    //Ingredient 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/ingredient/status-change' ,'IngredientController@statusChange');
        Route::post('/saveIngredientDetails','IngredientController@ingredientSave');
        Route::post('/updateIngredientDetails','IngredientController@updateIngredient');
        Route::resource('ingredient', 'IngredientController');

    });

    //Ingredient 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/ingredient/status-change' ,'ItemIngredientController@statusChange');
        Route::post('/ingredient/delete' ,'ItemIngredientController@deleteIngredient');
        Route::get('/item-ingredient/{id}/editItemIngredient' ,'ItemIngredientController@editItemIngredient');
        Route::post('/update/item-ingredient','ItemIngredientController@updateItemIngredient');
        Route::get('/item-ingredient/get-stock','ItemIngredientController@getStock');
        Route::resource('item-ingredient', 'ItemIngredientController');

    });
     
    // SUPPLIER MASTER
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/supplier/status-change' ,'SupplierController@statusChange');
        Route::resource('supplier', 'SupplierController');
    });
     
      //PROFILE
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::resource('profile', 'ProfileController');
    });

    // AREA CODE
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/area-code/status-change' ,'AreaCodeController@statusChange');
        Route::resource('area-code', 'AreaCodeController');
    });

    // COST CENTER
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/cost-center/status-change' ,'CostCenterController@statusChange');
        Route::resource('cost-center', 'CostCenterController');
    });

    // SALES MAN
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::post('/sales-man/status-change' ,'SalesManController@statusChange');
        Route::resource('sales-man', 'SalesManController');
    });

    //STOCK ENQUIRY
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::get('/stock-enquiry/details', 'StockEnquiryController@getDetails');
        Route::resource('stock-enquiry', 'StockEnquiryController');
    });
  
    //CUSTOMER RECIEPT 
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::resource('customer-reciept', 'CustomerRecieptController');
    });

    // SALES MODULE
    Route::group(['middleware'=>'checkLogin'],function(){
        // SALES
        Route::get('view-invoice','Admin\InvoiceController@viewInvoice')->name('view-invoice');
        Route::get('edit-invoice','Admin\InvoiceController@editInvoice')->name('edit-invoice');
        Route::post('update-invoice','Admin\InvoiceController@updateInvoice')->name('update-invoice');
        Route::get('productList','Admin\InvoiceController@productList');
        Route::get('removeItem','Admin\InvoiceController@removeItem');
        Route::get('fetchItemDetails','Admin\InvoiceController@getItemDetails');
        Route::get('fetchItemUnits','\Admin\InvoiceController@getItemUnits');
        Route::get('create-invoice','Admin\InvoiceController@createInvoice');
        Route::get('purchase-history','Admin\InvoiceController@purchaseHistory');
        Route::get('product-details','Admin\InvoiceController@productDetails');
        Route::get('getCustomerDetails','Admin\InvoiceController@getCustomerDetails')->name('getCustomerDetails');
        Route::post('save-invoice','Admin\InvoiceController@saveInvoice')->name('saveInvoice');
        Route::get('getInvoiceDetails','Admin\InvoiceController@getInvoiceDetails')->name('getInvoiceDetails');
        Route::get('editInvoiceDetails','Admin\InvoiceController@editInvoiceDetails')->name('editInvoiceDetails');
        Route::post('deleteInvoice','Admin\InvoiceController@deleteInvoice')->name('deleteInvoice');
        Route::post('saveItem','Admin\InvoiceController@saveItem')->name('saveItem');

        /*Route::get('create-journal',function(){
            echo "string";
        });*/
                  
        // Restaurant sales
        Route::get('restaurant-invoice','Admin\RestaurantController@index');
        // Ajax requests
        Route::get('getTables','Admin\RestaurantController@getTables');
        Route::post('loadItems','Admin\RestaurantController@loadItems');
        Route::post('getItemDetails','Admin\RestaurantController@getItemDetails');
        Route::post('getItemAddons','Admin\RestaurantController@getItemAddons');
        Route::post('bookTable','Admin\RestaurantController@bookTable');
        Route::post('releaseTable','Admin\RestaurantController@releaseTable');
        Route::post('releaseTableData','Admin\RestaurantController@releaseTableData');
        Route::post('getItemDetailsByBarcode','Admin\RestaurantController@getItemsByBarCode');

        // QUOTATION
    Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::get('view-quotation','QuotationController@viewQuotation')->name('view-quotation');
        Route::get('edit-quotation','QuotationController@editQuotation')->name('edit-quotation');
        Route::post('update-quotation','QuotationController@updateQuotation')->name('update-quotation');
        Route::get('productList','QuotationController@productList');
        Route::get('removeItem','QuotationController@removeItem');
        Route::get('getItemDetails','QuotationController@getItemDetails');
        Route::get('create-quotation','QuotationController@createQuotation');
        Route::get('getCustomerDetails','QuotationController@getCustomerDetails')->name('getCustomerDetails');
        Route::post('save-quotation','QuotationController@saveQuotation')->name('saveQuotation');
        Route::get('getQuotationDetails','QuotationController@getQuotationDetails')->name('getQuotationDetails');
        Route::get('editQuotationDetails','QuotationController@editQuotationDetails')->name('editQuotationDetails');
        Route::post('deleteQuotation','QuotationController@deleteQuotation')->name('deleteQuotation');
        Route::resource('quotation', 'QuotationController');
    });

    // Damage
     Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
        Route::get('view-damage','DamageController@viewDamage')->name('view-damage');
        Route::get('edit-damage','DamageController@editDamage')->name('edit-damage');
        Route::post('update-damage','DamageController@updateDamage')->name('update-damage');
        Route::get('productList','DamageController@productList');
        Route::get('removeItem','DamageController@removeItem');
        Route::get('getItemDetails','DamageController@getItemDetails');
        Route::get('create-damage','DamageController@createDamage');
        Route::get('getCustomerDetails','DamageController@getCustomerDetails')->name('getCustomerDetails');
        Route::post('save-damage','DamageController@saveDamage')->name('saveDamage');
        Route::get('getDamageDetails','DamageController@getDamageDetails')->name('getDamageDetails');
        Route::get('editDamageDetails','DamageController@editDamageDetails')->name('editDamageDetails');
        Route::post('deleteDamage','DamageController@deleteDamage')->name('deleteDamage');
        Route::resource('damage', 'DamageController');
    });
});
});



 Route::group(['prefix'=>'','as'=>'','namespace'=>'Admin'],function(){
  Route::get('view-invoice','InvoiceController@viewInvoice')->name('view-invoice');
        Route::get('edit-invoice','InvoiceController@editInvoice')->name('edit-invoice');
        Route::post('update-invoice','InvoiceController@updateInvoice')->name('update-invoice');
        Route::get('productList','InvoiceController@productList');
        Route::get('removeItem','InvoiceController@removeItem');
        Route::get('fetchItemDetails','InvoiceController@getItemDetails');
        Route::get('fetchItemUnits','InvoiceController@getItemUnits');
        Route::get('create-account','InvoiceController@createInvoice');
        Route::get('purchase-history','InvoiceController@purchaseHistory');
        Route::get('product-details','InvoiceController@productDetails');
        Route::get('getCustomerDetails','InvoiceController@getCustomerDetails')->name('getCustomerDetails');
        Route::post('save-invoice','InvoiceController@saveInvoice')->name('saveInvoice');
        Route::get('getInvoiceDetails','InvoiceController@getInvoiceDetails')->name('getInvoiceDetails');
        Route::get('editInvoiceDetails','InvoiceController@editInvoiceDetails')->name('editInvoiceDetails');
        Route::post('deleteInvoice','InvoiceController@deleteInvoice')->name('deleteInvoice');
 Route::post('saveItem','InvoiceController@saveItem')->name('saveItem');
     });


 
