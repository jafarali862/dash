 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
    {{ Html::style('plugins/select2/select2.min.css') }}
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Item Group</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form action="{{ route("item-groups.store") }}" method="POST"  id="quickForm">
              @csrf
                <div class="form-row">
                    <div class="col-md-12 mb-3 field">
                    <label for="">English Name *</label>
                    <input type="text" class="form-control" placeholder="English Name..." name="english_description" value="{{ old('english_description', isset($itemGroup) ? $itemGroup->english_description : '') }}">
                     @if($errors->has('english_description'))
                        <span for="english_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_description') }}
                        </span> 
                     @endif
                    </div>
                </div>  
                <div class="form-row">
                    <div class="col-md-12 mb-3 field">
                    <label for="">Arabic Name *</label>
                    <input type="text" class="form-control" placeholder="Arabic Name..." name="arabic_description" value="{{ old('arabic_description', isset($itemGroup) ? $itemGroup->arabic_description : '') }}">
                     @if($errors->has('arabic_description'))
                        <span for="arabic_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_description') }}
                        </span> 
                     @endif
                    </div>
                </div>                                                         
                <div class="form-row">
                  <div class="col-md-12 col-lg-12 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Group Type</label>
                    {!! Form::select('group_type', $groupType ,null,['placeholder' => '--Select Group Type--','class' => 'form-control basic select2 group_type','required']); !!}

                      @if($errors->has('group_type'))
                        <span for="group_type" class="error ml-2 text-danger">
                          {{ $errors->first('group_type') }}
                        </span> 
                     @endif
                  </div>
                </div>

               <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                    <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                    <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
{{-- end --}}
<script>

// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
      english_description: {
        required: true,
        maxlength: 200
      },
      arabic_description: {
        required: true,
        maxlength: 200
      },
      group_type: {
        required: true,
      }
    },
    messages: {
      english_description: {
        required: "Please enter english name !..",
        maxlength: "Maximum 200 charectors only allowed !.."
      },
      arabic_description: {
        required: "Please enter arabic name !..",
        maxlength: "Maximum 200 charectors only allowed !.."
      },
      group_type: {
        required: "Please select group type",
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });

function back()
{
    window.location="{!!  route('item-groups.index') !!}"
}

</script>
@endsection
