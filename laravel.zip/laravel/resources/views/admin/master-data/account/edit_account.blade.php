@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection
 @section('content')
 <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-10 col-lg-10 col-sm-10 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Edit Account</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
          <form action="{{ route("account.update", [$edit_account->id]) }}" method="POST" enctype="multipart/quickForm" id="editaccount" name="editaccount">
              @csrf
              @method('PUT')
                <div class="form-row">
                  <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Sub Account Type</label>
                
                  <select class="form-control" name="sub_accnt_type_id">
                  <option value="">--select--</option>
                    @foreach($sub_account_type as $key=>$data)
                    <option value="{{ $data->id }}" @if($edit_account->sub_accnt_type_id == $data->id)? selected @endif >{{ $data->sub_accnt_name }}</option>
                    @endforeach                    
                  </select>

                  </div>
                  <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">English Description</label>
                    <textarea class="form-control" value="{{ $edit_account->english_desptn }}" placeholder="English Description" name="english_desptn" required>{{ $edit_account->english_desptn }}</textarea>
                  </div>
                </div>     
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">Opening Balance</label>
                    <input type="number" class="form-control" placeholder="Opening Balance" value="{{ $edit_account->open_balance }}" name="open_balance">
                  </div>
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Balance Start Date</label>
                    <input type="date" class="form-control" placeholder="Balance Start Date" value="{{ $edit_account->balance_start_date }}" name="balance_start_date">
                  </div>
                 
                </div><br>                                                  
                <div class="modal-footer md-button">
                <input type="text" class="form-control" value="{{ $edit_account->is_active }}" hidden name="status">
                <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button class="btn btn-outline-success">Update</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
 @endsection
 @section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script src="{{asset('plugins/select2/custom-select2.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPTS FILE  -->
{{-- end --}}
<script>

function back()
{
    window.location="{!!  route('account.index') !!}"
}
// FORM SUBMIT WITH VALIDATION
  // Validate popup
  $('#editaccount').validate({
    ignore: [],
    rules: {
        english_desptn: {
        required: true,
        maxlength: 1000
      }
      sub_accnt_type_id: {
        required: true,
        maxlength: 1000
      }
    },
    messages: {
        english_desptn: {
        required: "Please enter english description !..",
        maxlength: "Maximum 1000 charectors only allowed !.."
      }
      sub_accnt_type_id: {
        required: "Please select sub account type !..",
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });
</script>
@endsection