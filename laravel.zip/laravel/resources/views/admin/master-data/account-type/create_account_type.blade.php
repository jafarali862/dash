@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection
 @section('content')
  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Account Type</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form action="{{ route('account-type.store') }}" method="POST"  id="quickForm">
              @csrf
                <div class="form-row">
                  <div class="col-md-12 mb-2 field">
                    <label for="validationCustom02">English Description</label>
                    <input type="text" class="form-control" placeholder="English Description" name="english_desptn" required>
                    <input type="text" class="form-control" hidden name="status" value="1">
                  </div>
                  <div class="col-md-6 mb-2 field">
                    <label for="validationCustomUsername">Default Type &nbsp;:&nbsp;</label>
                    <label class="new-control new-radio radio-classic-primary">
                    <input id="validationCustomUsername" type="radio" class="new-control-input" checked name="type" value="Payment">
                    <span class="new-control-indicator"></span>Payment
                    </label>
                    <label class="new-control new-radio radio-classic-primary">
                    <input id="validationCustomUsername" type="radio" class="new-control-input" name="type" value="Reciept">
                    <span class="new-control-indicator"></span>Reciept                       
                   </label>
                  </div>
                </div>                                                           
                <div class="modal-footer md-button">
                  <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                  <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection
@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
{{-- end --}}
<script>
function back()
{
    window.location="{!!  route('account-type.index') !!}"
}
// FORM SUBMIT WITH VALIDATION
  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
        english_desptn: {
        required: true,
        maxlength: 1000
      }
    },
    messages: {
        english_desptn: {
        required: "Please enter english description !..",
        maxlength: "Maximum 1000 charectors only allowed !.."
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });
    @if(Session::has('message'))
    // var type = "{{ Session::get('alert-type', 'info') }}";
    // switch(type){
    //     case 'info':
    //         toastr.info("{{ Session::get('message') }}");
    //         break;

    //     case 'warning':
    //         toastr.warning("{{ Session::get('message') }}");
    //         break;

    //     case 'success':
    //         toastr.success("{{ Session::get('message') }}");
    //         break;

    //     case 'error':
    //         toastr.error("{{ Session::get('message') }}");
    //         break;
    // }
  @endif
</script>

@endsection