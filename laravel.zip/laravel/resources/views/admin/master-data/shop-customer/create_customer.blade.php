@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection
 @section('content')
 <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-10 col-lg-10 col-sm-10 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Customer</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form  action="{{ route('shop-customer.store') }}" method="post" id="createcustomer" name="createcustomer">
              @csrf
                 <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">ID</label>
                  <input type="text" class="form-control" placeholder="ID" value="{{ $cust_id }}" readonly="">
              
                  </div>
                   <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Own Code</label>
                    <input type="text" class="form-control" placeholder="Own Code" id="own_code" name="own_code" >
                  </div>
                </div>   

                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Customer Name</label>
                  <input type="text" class="form-control" placeholder="Customer Name" name="cust_name" value="{{ old('cust_name') }}" required/>
              
                  </div>
                   <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">Mobile</label>
                    <input type="number" class="form-control" placeholder="Mobile" name="mobile">
                  </div>
                </div>     
                <div class="form-row">
               
                <div class="col-md-12 mb-12 field">
                  <label for="validationCustom02">Address</label>
                    <textarea class="form-control" placeholder="Address" name="english_addrs"></textarea>
                  </div>
                 
                 
                </div>    
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">E-mail</label>
                    <input type="email" class="form-control" placeholder="E-mail" name="email">
                  </div>
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Fax</label>
                    <input type="text" class="form-control" placeholder="Fax" name="fax">
                  </div>
                 
                </div>  
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">VAT Number</label>
                    <input type="number" class="form-control" placeholder="VAT Number" name="vat_no" >
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Area Code</label>
                    {!! Form::select('area_code_id', $areacode ,null,['placeholder' => '--Select Area Code--','class' => 'form-control basic select2 item_group_id']); !!}

                  </div>
                 
                </div>
               <div class="form-row">
                
                
                  <div class="col-md-12 mb-12 field">
                    <label for="validationCustom02">Sales Man</label>
                    {!! Form::select('sales_man_id', $saleaman ,null,['placeholder' => '--Select Sales Man--','class' => 'form-control basic select2 item_group_id']); !!}

                  </div>
                 
                </div>
                 <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Cost Center</label>
                   {!! Form::select('cost_center_id', $costcenter ,null,['placeholder' => '--Select Cost Center--','class' => 'form-control basic select2 item_group_id']); !!}
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Credit Limit</label>
                    <input type="Number" class="form-control" placeholder="Credit Limit" name="credit_limit">
                  </div>
                 
                </div>
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Supplier Name Link</label>
                    {!! Form::select('supplier_id', $supplier ,null,['placeholder' => '--Select Supplier--','class' => 'form-control basic select2 item_group_id']); !!}

                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Visit Day & Date</label>
                    <input type="date" class="form-control date"  name="vist_day" placeholder="Sunday/Monday">
                  </div>
                 
                </div>
                <br>                                                  
                <div class="modal-footer md-button">
                <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                  <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                  
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
 @endsection
 @section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script src="{{asset('plugins/select2/custom-select2.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPTS FILE  -->
{{-- end --}}
<script>
  $(document).ready(function() {
      //Initialize Select2 Elements
    $('.select2').select2()
     
});
  $(function() {
     $("#own_code").focus();
   });
  // FORM SUBMIT WITH VALIDATION
  // Validate popup
  $('#createcustomer').validate({
    ignore: [],
    rules: {
      cust_name: {
        required: true,
        maxlength: 1000
      }
    },
    messages: {
      cust_name: {
        required: "Please enter customer name !..",
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
   

function back()
{
    window.location="{!!  route('shop-customer.index') !!}"
}

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });
    @if(Session::has('message'))
    var type = "{{ Session::get('alert-type', 'info') }}";
    switch(type){
        case 'info':
            toastr.info("{{ Session::get('message') }}");
            break;

        case 'warning':
            toastr.warning("{{ Session::get('message') }}");
            break;

        case 'success':
            toastr.success("{{ Session::get('message') }}");
            break;

        case 'error':
            toastr.error("{{ Session::get('message') }}");
            break;
    }
  @endif
</script>

@endsection