 <div id="create_customer" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Customer</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
         
          <div class="modal-body">
          {{-- <div id="content" class="main-content w-50"> --}}
            <form  action="{{ route('shop-customer.store') }}" method="post" id="createcustomer" name="createcustomer">
              @csrf
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Customer Name</label>
                  <input type="text" class="form-control" placeholder="Customer Name" id="cust_name" name="cust_name" value="{{ old('cust_name') }}" required/>
              
                  </div>
                  <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">English Description</label>
                    <textarea class="form-control" placeholder="English Description" name="english_desptn" ></textarea>
                  </div>
                </div>     
                <div class="form-row">
               
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Address</label>
                    <textarea class="form-control" placeholder="Address" name="english_addrs"></textarea>
                  </div>
                  <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">Mobile</label>
                    <input type="number" class="form-control" placeholder="Customer Mobile" id="mobile" name="mobile"  required>
                  </div>
                 
                </div>    
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">E-mail</label>
                    <input type="email" class="form-control" placeholder="E-mail" name="email">
                  </div>
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Fax</label>
                    <input type="text" class="form-control" placeholder="Fax" name="fax">
                  </div>
                 
                </div>  
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">VAT Number</label>
                    <input type="number" class="form-control" placeholder="VAT Number" name="vat_no" >
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Area Code</label>
                    <input type="number" class="form-control" placeholder="Area Code" name="area_code">
                  </div>
                 
                </div>
               <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Own Code</label>
                    <input type="number" class="form-control" placeholder="Own Code" name="own_code" >
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Sales Man</label>
                    <input type="text" class="form-control" placeholder="Sales Man" name="sales_man">
                  </div>
                 
                </div>
                 <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Cost Center</label>
                    <input type="text" class="form-control" placeholder="Cost Center" name="cost_center" >
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Credit Limit</label>
                    <input type="Number" class="form-control" placeholder="Credit Limit" name="credit_limit" >
                  </div>
                 
                </div>
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Supplier Name Link</label>
                    <input type="text" class="form-control" placeholder="Supplier Name Link" name="supplier_name" >
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Day Of Visit</label>
                    <input type="date" class="form-control" placeholder="Day Of Visit" name="vist_day" >
                  </div>
                 
                </div>
               
            </form>
          {{-- </div> --}}
          </div>
          <div class="modal-footer">
              <button class="btn" data-dismiss="modal">cancel</button>
              <button type="submit" class="btn btn-primary" onclick="saveCustomer()" id="save_customer">Save</button>
              <button  class="btn btn-primary"  id="save_customer_please_wait"><i class="fa fa-refresh fa-spin"></i>Saving..</button>
          </div>
      
        </div>
      </div>
    </div>