@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection
 @section('content')
 <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-10 col-lg-10 col-sm-10 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Edit Customer</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
          <form action="{{ route("shop-customer.update", [$edit_customer->id]) }}" method="POST" enctype="multipart/quickForm" id="editcustomer" name="editcustomer">
              @csrf
              @method('PUT')
               <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">ID</label>
                  <input type="text" class="form-control" placeholder="ID" value="{{ $edit_customer->id }}" readonly="">
              
                  </div>
                   <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Own Code</label>
                    <input type="text" class="form-control" placeholder="Own Code" id="own_code" name="own_code" value="{{ $edit_customer->own_code }}">
                  </div>
                </div>    
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">Customer Name</label>
                  <input type="text" class="form-control" placeholder="Customer Name" name="cust_name" value="{{$edit_customer->cust_name}}" required/>
              
                  </div>
                 <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">Mobile</label>
                    <input type="number" class="form-control" placeholder="Mobile" name="mobile" value="{{$edit_customer->mobile}}" required>
                    <input type="number" class="form-control" hidden  name="status" value="{{$edit_customer->status}}">
                  </div>
                </div>     
                <div class="form-row">
               
                <div class="col-md-12 mb-12 field">
                  <label for="validationCustom02">Address</label>
                    <textarea class="form-control" placeholder="Address" name="english_addrs" value="{{$edit_customer->english_addrs}}" required>{{$edit_customer->english_addrs}}</textarea>
                  </div>
                  
                 
                </div>    
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                <label for="validationCustom02">E-mail</label>
                    <input type="email" class="form-control" placeholder="E-mail" name="email" value="{{$edit_customer->email }}" required>
                  </div>
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Fax</label>
                    <input type="text" class="form-control" placeholder="Fax" name="fax" value="{{$edit_customer->fax}}">
                  </div>
                 
                </div>  
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">VAT Number</label>
                    <input type="number" class="form-control" placeholder="VAT Number" name="vat_no" value="{{$edit_customer->vat_no}}" required>
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Area Code</label>
                    {!! Form::select('area_code_id', $areacode ,$edit_customer->area_code_id,['placeholder' => '--Select Area Code--','class' => 'form-control basic select2 item_group_id']); !!}
                   
                  </div>
                 
                </div>
                <div class="form-row">
                  <div class="col-md-12 mb-12 field">
                    <label for="validationCustom02">Sales Man</label>
                    {!! Form::select('sales_man_id', $saleaman ,$edit_customer->sales_man_id,['placeholder' => '--Select Sales Man--','class' => 'form-control basic select2 item_group_id']); !!}
                    
                  </div>
                 
                </div>
                 <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Cost Center</label>
                   {!! Form::select('cost_center_id', $costcenter, $edit_customer->cost_center_id,['placeholder' => '--Select Cost Center--','class' => 'form-control basic select2 item_group_id']); !!}

                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Credit Limit</label>
                    <input type="Number" class="form-control" placeholder="Credit Limit" name="credit_limit" required value="{{$edit_customer->credit_limit}}">
                  </div>
                 
                </div>
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Supplier Name Link</label>
                    {!! Form::select('supplier_id', $supplier ,$edit_customer->supplier_id,['placeholder' => '--Select Supplier--','class' => 'form-control basic select2 item_group_id']); !!}
                  </div>
                
                  <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Day & Date</label>
                    <input type="date" class="form-control" name="vist_day" required value="{{$edit_customer->vist_date}}">
                  </div>
                 
                </div>
                <br>                                                  
                <div class="modal-footer md-button">
                  <input type="hidden" name="status" value="{{$edit_customer->is_active}}">
                  <input type="hidden" name="is_regular_cust" value="{{$edit_customer->is_regular_cust}}">
                  <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button class="btn btn-outline-success">Update</button>
                 
                  
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
 @endsection
 @section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script src="{{asset('plugins/select2/custom-select2.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPTS FILE  -->
{{-- end --}}
<script>
 $(function() {
     $("#own_code").focus();
   });
function back()
{
    window.location="{!!  route('shop-customer.index') !!}"
}
// FORM SUBMIT WITH VALIDATION
  // Validate popup
  $('#editcustomer').validate({
    ignore: [],
    rules: {
       
      english_addrs: {
        required: true,
        maxlength: 1000
      },
      cust_name: {
        required: true,
        maxlength: 1000
      },
      
      mobile: {
        required: true,
        maxlength: 10,
        minlength: 10
      },
     
      email: {
        required: true,
        
      },
      vat_no: {
        required: true,
      },
      credit_limit:{
        required: true,
      },
      vist_day:{
        required: true,
      }
    },
    messages: {
        
      english_addrs: {
        required: "Please enter address !..",
        maxlength: "Maximum 1000 charectors only allowed !.."
      },
      cust_name: {
        required: "Please enter customer name !..",
      },
     
      mobile: {
        required: "Please enter mobile number !..",
        minlength: "Minimum length 10 !..",
        maxlength: "Maximum length 10 !.."
      },
      
      email: {
        required: "Please enter email !..",
      },
      vat_no: {
        required: "Please enter VAT number !..",
       
      },
      credit_limit:{
        required: "please enter credit limit !.."
      },
      vist_day:{
        required: "please mark a vist day !.."
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });
    @if(Session::has('message'))
    var type = "{{ Session::get('alert-type', 'info') }}";
    switch(type){
        case 'info':
            toastr.info("{{ Session::get('message') }}");
            break;

        case 'warning':
            toastr.warning("{{ Session::get('message') }}");
            break;

        case 'success':
            toastr.success("{{ Session::get('message') }}");
            break;

        case 'error':
            toastr.error("{{ Session::get('message') }}");
            break;
    }
  @endif
</script>

@endsection