 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
   {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
   {{ Html::style('plugins/animate/animate.css') }}
   {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Unit</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
              <form action="{{ route("item-units.update", [$itemUnit->id]) }}" method="POST" enctype="multipart/form-data" id="quickForm">
                @csrf
                @method('PUT')
                <input type="hidden" name="item_unit_id" value="{{ $itemUnit->id }}">
                <div class="form-row">
                  <div class="col-md-12 mb-2 field">
                    <label for="validationCustom01">Short Description</label>
                    <input type="text" class="form-control" placeholder="Short Description" name="short_description" value="{{ old('short_description', isset($itemUnit) ? $itemUnit->short_description : '') }}">
                    @if($errors->has('short_description'))
                        <span for="short_description" class="error ml-2 text-danger">
                          {{ $errors->first('short_description') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-12 mb-2 field">
                    <label for="validationCustom02">English Description</label>
                    <input type="text" class="form-control" placeholder="English Description" name="english_description" value="{{ old('english_description', isset($itemUnit) ? $itemUnit->english_description : '') }}">
                    @if($errors->has('short_description'))
                        <span for="short_description" class="error ml-2 text-danger">
                          {{ $errors->first('short_description') }}
                        </span> 
                     @endif
                  </div>
                  {{-- <div class="col-md-6 mb-2 field">
                    <label for="validationCustom03">Quantity</label>
                    <input type="number" class="form-control" placeholder="Quantity" name="quantity" value="{{ old('quantity', isset($itemUnit) ? $itemUnit->quantity : '') }}">
                    @if($errors->has('quantity'))
                        <span for="quantity" class="error ml-2 text-danger">
                          {{ $errors->first('quantity') }}
                        </span> 
                     @endif
                  </div> --}}
                 {{--  <div class="col-md-12 mb-12 field">
                      <div class="n-chk mt-3">
                          <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                            <input type="checkbox" class="new-control-input" id="is_active" name="is_active" {{ $itemUnit->is_active == 1? 'checked':'' }}>
                            <span class="new-control-indicator"></span><span class="new-chk-content">Active ?</span>
                          </label>
                      </div>
                    </div> --}}
                </div>                                                           
                <div class="modal-footer md-button">
                  <button class="btn btn-outline-success" type="submit">Update</button>
                  <button class="btn btn-outline-danger btnCancel" onclick="history.back()">Cancel</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
{{-- end --}}
<script>

// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
      short_description: {
        required: true,
        maxlength: 200
      },
      english_description: {
        required: true,
        maxlength: 1000
      },
      // quantity: {
      //   required: true,
      //   maxlength: 9
      // }
    },
    messages: {
      short_description: {
        required: "Please enter short description !..",
        maxlength: "Maximum 200 charectors only allowed !.."
      },
      english_description: {
        required: "Please enter english description !..",
        maxlength: "Maximum 1000 charectors only allowed !.."
      },
      // quantity: {
      //   required: "Please enter quantity !..",
      //   maxlength: "Maximum 9 numbers only allowed !.."
      // }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });

</script>
@endsection

