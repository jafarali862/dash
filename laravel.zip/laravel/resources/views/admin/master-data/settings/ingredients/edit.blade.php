 <div id="edit_ingredient_pop_up" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Edit Ingredient</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         {{-- <div id="content" class="main-content w-50"> --}}
         <form  method="post" id="edit_ingredient" name="editingredient">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Ingredient <span style="color:red">*</span></label>
               <input type="text" class="form-control" placeholder="Ingredient" id="edit_ingredient_name" name="ingredient_name" value="{{ old('ingredient') }}" required />

             </div>
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Min Stock <span style="color:red">*</span></label>
               <input type="number" class="form-control" placeholder="Min Stock" id="edit_min_stock" name=" min_stock" value="{{ old('min_stock') }}" required />
               <input type="hidden" name="ingredient_id" id="edit_ingredient_id">
               <input type="hidden" name="status" id="status">
             </div>
           </div>
         </form>
         {{-- </div> --}}
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="editIngredient()" id="edit_ingredient_btn">Update</button>
         <button class="btn btn-primary" id="edit_ingredient_please_wait"><i class="fa fa-refresh fa-spin"></i>Updating..</button>
       </div>

     </div>
   </div>
 </div>