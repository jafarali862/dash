 <div id="create_order_type" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Add Order Type</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         {{-- <div id="content" class="main-content w-50"> --}}
         <form  method="post" id="createordertype" name="createordertype">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Order Type</label>
               <input type="text" class="form-control" placeholder="Order Type" id="order_type" name="order_type" value="{{ old('order_type') }}" required />

             </div>
           </div>
         </form>
         {{-- </div> --}}
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="saveOrderType()" id="save_order_type">Save</button>
         <button class="btn btn-primary" id="save_order_type_please_wait"><i class="fa fa-refresh fa-spin"></i>Saving..</button>
       </div>

     </div>
   </div>
 </div>