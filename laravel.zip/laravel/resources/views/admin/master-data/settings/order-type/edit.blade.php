 <div id="edit_order_type_modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Edit Order Type</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         {{-- <div id="content" class="main-content w-50"> --}}
         <form  method="post" id="editordertype" name="editordertype">
           @csrf
           <div class="form-row">
            <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Order Type</label>
               <input type="text" class="form-control" placeholder="Order Type" id="edit_order_type" name="edit_order_type" value="{{ old('order_type') }}" required />
               <input type="hidden" name="order_type_id" id="edit_order_type_id">
               <input type="hidden" name="status" id="status">
             </div>
           </div>
         </form>
         {{-- </div> --}}
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="editOrderType()" id="edit_order_type_btn">Update</button>
         <button class="btn btn-primary" id="edit_order_type_please_wait"><i class="fa fa-refresh fa-spin"></i>Updating..</button>
       </div>

     </div>
   </div>
 </div>
 