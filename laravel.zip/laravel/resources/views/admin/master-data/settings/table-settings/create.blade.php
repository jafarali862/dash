 <div id="create_table_settings" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Add Tables</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         {{-- <div id="content" class="main-content w-50"> --}}
         <form action="{{ route('table-settings.store') }}" method="post" id="createtable" name="createtable">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Name</label>
               <input type="text" class="form-control" placeholder="Name" id="table_name" name="table_name" value="{{ old('table_name') }}" required />

             </div>
           </div>
         </form>
         {{-- </div> --}}
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="saveTable()" id="save_table">Save</button>
         <button class="btn btn-primary" id="save_table_please_wait"><i class="fa fa-refresh fa-spin"></i>Saving..</button>
       </div>

     </div>
   </div>
 </div>