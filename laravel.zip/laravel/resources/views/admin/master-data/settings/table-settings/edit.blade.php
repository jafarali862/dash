 <div id="edit_table_settings" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Edit Table</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
       <div class="modal-body">
         <form method="post" id="edittable" name="edittable">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Name</label>
               <input type="text" class="form-control" placeholder="Name" id="edit_table_name" name="table_name" required />
               <input type="hidden" name="table_id" id="edit_table_id">
               <input type="hidden" name="status" id="status">
             </div>
           </div>
         </form>
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="editTableData()" id="edit_table">Update</button>
         <button class="btn btn-primary" style="display: none;" id="edit_table_please_wait"><i class="fa fa-refresh fa-spin"></i>Updating..</button>
       </div>

     </div>
   </div>
 </div>