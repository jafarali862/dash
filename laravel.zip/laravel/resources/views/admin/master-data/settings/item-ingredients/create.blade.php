 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
   {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
   {{ Html::style('plugins/animate/animate.css') }}
   {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
   {{ Html::style('plugins/select2/select2.min.css') }}
   <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }
 </style>
 @endsection

 @section('content')
  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Item Ingredients</h4>
            </div>
          </div>
          <div id="content" class="main-content">
            <form action="{{ route("item-ingredient.store") }}" method="POST"  id="item_ingredient_form" enctype="multipart/form-data">
              @csrf
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Item</label>
                    {!! Form::select('item_id', $items ,null,['placeholder' => '--Select Item--','class' => 'form-control basic select2 item_group_id','required']); !!}
                      @if($errors->has('item_id'))
                        <span for="item_group_id" class="error ml-2 text-danger">
                          {{ $errors->first('item_id') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="col-md-2 col-lg-2 col-2 pb-0 layout-spacing field" style="margin-left: 67%;">
                    <a id="add_row" style="cursor:pointer;color:green;"><i data-feather="plus"></i></a>
                    <a id="delete_row" style="cursor:pointer;color:red;"><i data-feather="trash"></i></i></a>
                  </div>  
              <div class="item_unit_div">  
                <div class="form-row layout-spacing pb-3 div-unit">
                  <div class="col-md-6 col-lg-6 col-12 field" data-value="0" id="unit-0">
                    <label for="validationCustom02">Ingredients</label>
                    {!! Form::select('ingredient_id[]', $ingredients ,null,['placeholder' => '--Select Ingredients--','class' => 'form-control basic select2 ingredient','required']); !!}

                      @if($errors->has('ingredient_id'))
                        <span for="item_unit" class="error ml-2 text-danger">
                          {{ $errors->first('ingredient_id') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-12 pb-0 layout-spacing field">
                    <label for="validationCustom03">Qty Used</label>
                    <input type="number" class="form-control qty_used" placeholder="Qty Used" name="qty_used[]" required>
                     @if($errors->has('qty_used'))
                        <span for="qty_used" class="error ml-2 text-danger">
                          {{ $errors->first('qty_used') }}
                        </span> 
                     @endif
                  </div>
                </div>
              </div>
             <br>
               <div class="modal-footer md-button">
                <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                  <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
</div>
 <input type="hidden" name="counter" id="counter">
@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>

<script>
$(document).ready(function() {
      //Initialize Select2 Elements
    $('.select2').select2()
});

function back()
{
    window.location="{!!  route('item-ingredient.index') !!}"
}

// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#item_ingredient_form').validate({
    ignore: [],
    rules: {
      item_id: {
        required : true ,
      },
      ingredient_id: {
        required: true,
      },
      qty_used: {
        required: true,
      }
    },
    messages: {
      item_id: {
        requiredSelect : "Please select item !",
      },
      ingredient_id: {
        required: "Please select ingredient",
      },
      qty_used: {
        required: "Please enter qty !",
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

 $(".select2").select2().change(function() {
    $(this).valid();
  });


// add row
  $(document).on('click', '#add_row', function(event) {
          event.preventDefault();
          /* Act on the event */

            var currentRow = $('.item_unit_div');
            var val = currentRow.find(".qty_used").val(); 
           
            if(val > 0)
            {
              temp = $("#counter").val()
              var indexNo = $("#counter").val(++temp);


             $(".item_unit_div").append('<div class="form-row layout-spacing pb-3 div-unit"><div class="col-md-6 col-lg-6 col-12  field" data-value="'+$("#counter").val()+'" id="unit-'+$("#counter").val()+'"><label for="validationCustom02">Ingredients</label>{!! Form::select('ingredient_id[]', $ingredients ,null,['placeholder' => '--Select Ingredient--','class' => 'form-control basic select2 ingredient','required']); !!} @if($errors->has('ingredient_id'))<span for="ingredient_id" class="error ml-2 text-danger">{{ $errors->first('ingredient_id') }}</span>@endif</div><div class="col-md-6 col-lg-6 col-12 pb-0 layout-spacing field"><label for="validationCustom03">Qty Used</label><input type="number" class="form-control qty_used" placeholder="Qty Used" name="qty_used[]" required>@if($errors->has('qty_used'))<span for="qty_used" class="error ml-2 text-danger">{{ $errors->first('qty_used') }}</span> @endif</div></div></div>')

            // $('select').selectpicker();
            $('.select2').select2()
            }
            else
            {
              toastr.error("Please fill up values..!"); 
            }
    });


// checking value already added
  $(document).on('change', '.ingredient', function(event) {
    event.preventDefault();
      var selected = $(this);
      var myOption = $(this).val();
      // var value = $(this).closest( "div").data('value')
      // var e = myOption;

       var s =0;
        $.each($(".ingredient option:selected"), function(){
           var myselect = $(this).val();
            if(myselect==myOption){
              s += 1;
            }
        });

        if(s>1){
          toastr.error("This ingredient added already..!"); 
          selected.val(null).trigger('change.select2');
          selected.select2('data', null, false);;
        }
    });

// delete row
  $("#delete_row").click(function(){
    if($(".div-unit").length == 1){
      toastr.error("One Ingredient required..!"); 
      return false;
    }else{
      $( ".item_unit_div .form-row").last().remove();
    }
    });

</script>
@endsection

