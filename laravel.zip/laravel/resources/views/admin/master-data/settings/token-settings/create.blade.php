 <div id="create_token_settings" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Add Token Settings</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         {{-- <div id="content" class="main-content w-50"> --}}
         <form  method="post" id="createtoken" name="createtoken">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Token Start Number <span style="color:red">*</span></label>
               <input type="text" class="form-control" placeholder="Start Number" id="token_start_no" name="token_start_no" value="{{ old('token_start_no') }}" required />

             </div>
              <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Start Time <span style="color:red">*</span></label>
                <input type="time" class="form-control" id="start_time" name="start_time" value="{{ old('start_time') }}" required />

             </div>
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">End Time <span style="color:red">*</span></label>
                <input type="time" class="form-control" placeholder="Start Number" id="end_time" name="end_time" value="{{ old('end_time') }}" required />

             </div>
           </div>
         </form>
         {{-- </div> --}}
       </div>
       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="saveToken()" id="save_token">Save</button>
         <button class="btn btn-primary" id="save_token_please_wait"><i class="fa fa-refresh fa-spin"></i>Saving..</button>
       </div>

     </div>
   </div>
 </div>
 