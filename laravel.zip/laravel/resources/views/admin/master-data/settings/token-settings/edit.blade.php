 <div id="edit_token_settings" class="modal fade" role="dialog">
   <div class="modal-dialog">
     <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Edit Token Settings</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>

       <div class="modal-body">
         <form  method="post" id="edittoken" name="edittoken">
           @csrf
           <div class="form-row">
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Token Start Number <span style="color:red">*</span></label>
               <input type="text" class="form-control" placeholder="Start Number" id="edit_token_start_no" name="token_start_no" value="{{ old('token_start_no') }}" required />
             </div>
              <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">Start Time <span style="color:red">*</span></label>
                <input type="time" class="form-control" id="edit_start_time" name="edit_start_time" value="{{ old('start_time') }}" required />
             </div>
             <div class="col-md-12 mb-12 field">
               <label for="validationCustom02">End Time <span style="color:red">*</span></label>
                <input type="time" class="form-control" placeholder="Start Number" id="edit_end_time" name="end_time" value="{{ old('end_time') }}" required />
               <input type="hidden" name="token_id" id="edit_token_id">
               <input type="hidden" name="status" id="status">
             </div>
           </div>
         </form>
       </div>

       <div class="modal-footer">
         <button class="btn" data-dismiss="modal">cancel</button>
         <button type="submit" class="btn btn-primary" onclick="editTokenData()" id="edit_token">Update
         </button>
         <button class="btn btn-primary" id="edit_token_please_wait"><i class="fa fa-refresh fa-spin"></i>Updating..</button>
       </div>

     </div>
   </div>
 </div>
 