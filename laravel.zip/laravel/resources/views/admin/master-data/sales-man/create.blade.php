
 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
    {{ Html::style('plugins/select2/select2.min.css') }}
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Sales Man</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form action="{{ route("sales-man.store") }}" method="POST"  id="salesman">
              @csrf
                <div class="form-row">
                    <div class="col-md-12 mb-3 field">
                    <label for="">Name *</label>
                    <input type="text" class="form-control" placeholder="Name..." name="name" id="name" required="">
                    </div>
                </div>    
                 <div class="form-row">
                    <div class="col-md-12 mb-3 field">
                    <label for="">Address</label>
                   <textarea class="form-control" name="address" placeholder="Address.." id="Address"></textarea>
                    </div>
                </div>                                                          
               <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                    <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                    <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
{{-- end --}}
<script>
 $(function() {
     $("#name").focus();
   });
// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#salesman').validate({
    ignore: [],
    rules: {
      name: {
        required: true,
        maxlength: 200
      },
    },
    messages: {
      name: {
        required: "Please enter name !..",
        maxlength: "Maximum 200 charectors only allowed !.."
      },

    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

function back()
{
    window.location="{!!  route('sales-man.index') !!}"
}

</script>
@endsection
