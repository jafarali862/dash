
 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
    {{ Html::style('plugins/select2/select2.min.css') }}
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Edit Cost Center</h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form action="{{ route("cost-center.update", [$edit_cost_center->id]) }}" method="POST" enctype="multipart/quickForm">
              @csrf
              @method('PUT')
             
                <div class="form-row">
                    <div class="col-md-12 mb-3 field">
                    <label for="">Name *</label>
                    <input type="text" class="form-control" placeholder="Name..." name="name" id="name" required="" value={{ $edit_cost_center->name }}>
                    </div>
                    <input type="text" class="form-control" value="{{ $edit_cost_center->is_active }}" hidden name="status">
                </div>                                                          
               <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                    <button class="btn btn-outline-success" name="update" value="update">Update</button>
                   
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
{{-- end --}}
<script>
$(function() {
     $("#name").focus();
   });
// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#editareaCode').validate({
    ignore: [],
    rules: {
      name: {
        required: true,
        maxlength: 200
      }
    },
    messages: {
      name: {
        required: "Please enter name !..",
        maxlength: "Maximum 200 charectors only allowed !.."
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

function back()
{
    window.location="{!!  route('cost-center.index') !!}"
}

</script>
@endsection
