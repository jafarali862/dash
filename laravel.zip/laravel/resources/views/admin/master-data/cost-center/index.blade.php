@extends('layouts.app')
@section('style')
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
    <!-- END GLOBAL MANDATORY STYLES -->
     <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
    <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
     <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
@endsection
@section('content')
  <div id="content" class="main-content">

            <div class="layout-px-spacing">
                <div class="row layout-top-spacing" id="cancel-row">
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="widget-content widget-content-area br-6">
                            <div class="row">
                              <div class="col-xl-9 col-lg-9 col-md-8 col-sm-8">
                                <h4>Cost Center</h4>
                              </div>
                              <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 text-right">
                                <a class="btn btn-outline-primary btn-rounded mb-2" href="{{ route("cost-center.create") }}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Cost Center</a>
                              </div>
                            </div>
                            <div class="table-responsive mb-4 mt-4">
                                <table id="costcenterTable" class="table table-hover non-hover" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Sl No</th>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>                            
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            @section('script')
                 <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
                  <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
                  <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
                  <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
                  <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
                  <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
                  <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
                  <!--  BEGIN CUSTOM SCRIPT FILE  -->
                  <script src="{{asset('assets/js/forms/bootstrap_validation/bs_validation_script.js')}}"></script>
                  {{-- end --}}
                  <script>

//  DataTable initialize
  $('#costcenterTable').DataTable({
    responsive: true,
    autoWidth: true,
    processing: true,
    serverSide: true,
    lengthMenu: [3, 10, 20, 50],
    pageLength: 5,
    dom: '<"row"<"col-md-12"<"row"<"col-md-6"B><"col-md-6"f> > ><"col-md-12"rt> <"col-md-12"<"row"<"col-md-5"i><"col-md-7"p>>> >',
    buttons: {
      buttons: [
        { extend: 'copy', className: 'btn' },
        { extend: 'csv', className: 'btn',exportOptions: {
                  orthogonal: 'sort',
                  columns: [0,1,2]
              }
        },
        { extend: 'excel', className: 'btn' ,exportOptions: {
                  orthogonal: 'sort',
                  columns: [0,1,2]
              }
        },
        { extend: 'print', className: 'btn',exportOptions: {
                  orthogonal: 'sort',
                  columns: [0,1,2]
              }
        }
      ]
    },
     ajax: '{!!  route('cost-center.show','cost-center') !!}',
     fnRowCallback : function(nRow, aData, iDisplayIndex){
                 var oSettings = this.fnSettings();
                 var s = String(oSettings._iDisplayStart+iDisplayIndex +1);
                 var d= '0'.substr(0, 2 - s.length) + s ;                           
                  $("td:first", nRow).html(d);
                return nRow;
        },
    oLanguage: {
      oPaginate: { 
            sPrevious: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
            sNext: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' 
          },
      sInfo: "Showing page _PAGE_ of _PAGES_",
      sSearch: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
      sSearchPlaceholder: "Search...",
      sLengthMenu: "Results :  _MENU_",
    },
    columnDefs: [{
                  targets:[2],
                   render: function(data, type, row, meta){
                      if(type === 'sort'){
                         var $input = $(data).find('input[type="checkbox"]');
                         data = ($input.prop('checked')) ? "Active" : "Inactive";
                      }
                       
                      return data;    
                   }
              }],
     columns: [
              {data: 'id'},
              {data: 'name'},
              {data: 'status'},
              {data: 'action_button', orderable: false, searchable: false },  
        ],
  });
  function  changeStatus(val,cost_center_id)
  {
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    if(val){
           val = 1;
       }else{
           val = 0;
        }
        $.ajax({
                    url: '/cost-center/status-change',
                    type: 'POST',
                    data: {_token: CSRF_TOKEN, val : val, costcenter_id : cost_center_id ,doAction:'updateStatus'},
                    dataType: 'JSON',
                    success: function (data) { 
                      toastr.success("Status changed sucessfully..!"); 

                      $('#accountTypeTable').DataTable().ajax.reload();
                     
                    }
                }); 
      }
      $(document).on('click', '.btnEdit', function () 
        {
          
            var costcenter_id = $(this).data('cost_center_id'); 
            window.location='/cost-center/'+costcenter_id+'/edit';
       
        });
        $(document).on('click', '.btnDelete', function ()
        {
        if(confirm('Do you Want To Delete ?'))             
        { 
      var costcenter_id = $(this).data('cost_center_id'); 
      $.ajaxSetup({ 
              headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
        });
      $.ajax(
          {  
              url: '{!! route('cost-center.index') !!}'+'/'+costcenter_id,
              type: 'DELETE',
              dataType: 'JSON',
              success: function (result) 
              { 
                    if(result=="deleted")
                    {
                      $('#costcenterTable').DataTable().ajax.reload();  
                      toastr.success("Cost Center deleted sucessfully..!");             
                    }              
              },
              error:function(result)
              {
                console.log("It failed"+JSON.stringify(result));  
              }
            });

        }
        else
          {

              return;
          }
        });
     
</script>
    <!-- END PAGE LEVEL CUSTOM SCRIPTS -->
      @endsection
@endsection
