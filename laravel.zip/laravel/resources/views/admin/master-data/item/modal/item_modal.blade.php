<div id="create_item_modal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Item</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
         
          <div class="modal-body">
          {{-- <div id="content" class="main-content w-50"> --}}
            <form  action="{{ route('saveItem') }}" method="post" id="createItem" name="createItem">
              @csrf
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Item Group</label>
                    {!! Form::select('item_group_id', $itemGroup ,null,['placeholder' => '--Select Group--','class' => 'form-control basic select2 item_group_id']); !!}

                      @if($errors->has('item_group_id'))
                        <span for="item_group_id" class="error ml-2 text-danger">
                          {{ $errors->first('item_group_id') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Select Item Image</label>
                     <input type="file" class="form-control" name="item_image" accept=".jpeg,.jpg,.png">
                  </div>
                  
                </div>  
                <div class="form-row">
                	<div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">English Name</label>
                    <input type="text" class="form-control" placeholder="English Name" name="english_short_description">
                    @if($errors->has('english_short_description'))
                        <span for="english_short_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_short_description') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">English Description</label>
                     <textarea id="english_description" name="english_description" class="form-control " 
                          >{{ old('english_description')}}</textarea>
                    @if($errors->has('english_description'))
                        <span for="english_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_description') }}
                        </span> 
                     @endif
                  </div>
                </div>  
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Arabic Name</label>
                    <input type="text" class="form-control" placeholder="Arabic Name" name="arabic_short_description">
                    @if($errors->has('arabic_short_description'))
                        <span for="arabic_short_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_short_description') }}
                        </span> 
                     @endif
                  </div>
           
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Arabic Description</label>
                     <textarea id="arabic_description" name="arabic_description" class="form-control " 
                          >{{ old('arabic_description')}}</textarea>
                    @if($errors->has('arabic_description'))
                        <span for="arabic_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3 div-unit">
                  <div class="col-md-6 col-lg-6 col-12 field" data-value="0" id="unit-0">
                    <label for="validationCustom02">Item Unit</label>
                    {!! Form::select('item_unit', $itemUnit ,null,['placeholder' => '--Select Unit--','class' => 'form-control basic select2 item_unit']); !!}

                      @if($errors->has('item_unit'))
                        <span for="item_unit" class="error ml-2 text-danger">
                          {{ $errors->first('item_unit') }}
                        </span> 
                     @endif
                  </div>
          
                   <div class="col-md-6 col-lg-6 col-12 pb-0 layout-spacing field">
                    <label for="validationCustom03">Minimum Stock</label>
                    <input type="number" class="form-control" placeholder="Min Stock" name="minimum_quantity">
                     @if($errors->has('minimum_quantity'))
                        <span for="minimum_quantity" class="error ml-2 text-danger">
                          {{ $errors->first('minimum_quantity') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3 div-unit">
                  <div class="col-md-4">
                    <label for="validationCustom03">Cost</label>
                    <input type="number" class="form-control" placeholder="Cost" name="cost">
                    @if($errors->has('cost'))
                        <span for="cost" class="error ml-2 text-danger">
                          {{ $errors->first('cost') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-4">
                    <label for="validationCustom03">Price</label>
                    <input type="number" class="form-control" placeholder="Price" name="price">
                    @if($errors->has('price'))
                        <span for="price" class="error ml-2 text-danger">
                          {{ $errors->first('price') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-4">
                    <label for="validationCustom03">Quantity</label>
                    <input type="number" class="form-control" placeholder="Quantity" name="quantity">
                    @if($errors->has('quantity'))
                        <span for="quantity" class="error ml-2 text-danger">
                          {{ $errors->first('quantity') }}
                        </span> 
                     @endif
                  </div>
                     
                </div>
              <div class="form-row layout-spacing">
                <div class="col-md-5 col-lg-5 col-5 pb-0 layout-spacing field">
                  <label for="validationCustom03">Vat</label>
                    <input type="number" class="form-control" placeholder="Vat" name="vat">
                    @if($errors->has('vat'))
                        <span for="vat" class="error ml-2 text-danger">
                          {{ $errors->first('vat') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-2 col-lg-2 col-2 pb-0 layout-spacing field">
                    <div class="n-chk mt-5">
                        <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                          <input type="checkbox" class="new-control-input" id="zero_vat" name="zero_vat">
                          <span class="new-control-indicator"></span><span class="new-chk-content">Zero Vat</span>
                        </label>
                      </div>
                  </div>
                  <div class="col-md-5 col-lg-5 col-5 pb-0 layout-spacing field">
                  <label for="validationCustom03">Opening Stock</label>
                    <input type="number" class="form-control" placeholder="Opening Stock" name="opening_stock">
                    @if($errors->has('opening_stock'))
                          <span for="opening_stock" class="error ml-2 text-danger">
                            {{ $errors->first('opening_stock') }}
                          </span> 
                       @endif
                  </div>
                </div> 
              
   
            </form>
          </div>
          <div class="modal-footer">
              <button class="btn" data-dismiss="modal">cancel</button>
              <button type="submit" class="btn btn-primary" onclick="saveItem()" id="save_item">Save</button>
              <button  class="btn btn-primary"  id="save_item_please_wait"><i class="fa fa-refresh fa-spin"></i>Saving..</button>
          </div>
      
        </div>
      </div>
    </div>