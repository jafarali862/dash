 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
    {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
   {{ Html::style('plugins/animate/animate.css') }}
   {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
   {{ Html::style('plugins/select2/select2.min.css') }}
  {{-- summernote --}}
  {{ Html::style('plugins/summernote/summernote-bs4.css') }}

 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }

  
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add Item</h4>
            </div>
          </div>
          <div id="content" class="main-content">
            <form action="{{ route("items.store") }}" method="POST"  id="quickForm" enctype="multipart/form-data">
              @csrf
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Item Group</label>
                    {!! Form::select('item_group_id', $itemGroup ,null,['placeholder' => '--Select Group--','class' => 'form-control basic select2 item_group_id','required']); !!}

                      @if($errors->has('item_group_id'))
                        <span for="item_group_id" class="error ml-2 text-danger">
                          {{ $errors->first('item_group_id') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">English Name</label>
                    <input type="text" class="form-control" placeholder="English Name" name="english_short_description" required>
                    @if($errors->has('english_short_description'))
                        <span for="english_short_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_short_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">English Description</label>
                     <textarea id="english_description" name="english_description" class="form-control " required
                          >{{ old('english_description')}}</textarea>
                    @if($errors->has('english_description'))
                        <span for="english_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Arabic Name</label>
                    <input type="text" class="form-control" placeholder="Arabic Name" name="arabic_short_description" required>
                    @if($errors->has('arabic_short_description'))
                        <span for="arabic_short_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_short_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                 <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Arabic Description</label>
                     <textarea id="arabic_description" name="arabic_description" class="form-control " required
                          >{{ old('arabic_description')}}</textarea>
                    @if($errors->has('arabic_description'))
                        <span for="arabic_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                 <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Select Item Image</label>
                     <input type="file" class="form-control" name="item_image" accept=".jpeg,.jpg,.png">
                  </div>
                </div>
                
              <div class="item_unit_div card p-2">    
                <div class="form-row layout-spacing pb-3 div-unit">
                  <div class="col-md-6 col-lg-6 col-12 field" data-value="0" id="unit-0">
                    <label for="validationCustom02">Item Unit</label>
                    {!! Form::select('item_unit[]', $itemUnit ,null,['placeholder' => '--Select Unit--','class' => 'form-control basic select2 item_unit','required']); !!}

                      @if($errors->has('item_unit'))
                        <span for="item_unit" class="error ml-2 text-danger">
                          {{ $errors->first('item_unit') }}
                        </span> 
                     @endif
                  </div>
          
                   <div class="col-md-6 col-lg-6 col-12 pb-0 layout-spacing field">
                    <label for="validationCustom03">Minimum Stock</label>
                    <input type="number" class="form-control" placeholder="Min Stock" name="minimum_quantity[]" required>
                     @if($errors->has('minimum_quantity'))
                        <span for="minimum_quantity" class="error ml-2 text-danger">
                          {{ $errors->first('minimum_quantity') }}
                        </span> 
                     @endif
                  </div>
                <div class="col-md-1 col-lg-1 col-12 field mt-4">
                   <label>Quantity</label>
                 </div>
                   <div class="col-md-8 col-lg-8 col-12 pb-0 layout-spacing field mt-3">
                    <input type="number" class="form-control quantity" placeholder="Quantity" name="quantity[]" data-value='0' id='qua-0'>
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3 div-unit">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Cost</label>
                    <input type="number" class="form-control" placeholder="Cost" name="cost[]" required>
                    @if($errors->has('cost'))
                        <span for="cost" class="error ml-2 text-danger">
                          {{ $errors->first('cost') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <label for="validationCustom03">Price</label>
                    <input type="number" class="form-control" placeholder="Price" name="price[]" required>
                    @if($errors->has('price'))
                        <span for="price" class="error ml-2 text-danger">
                          {{ $errors->first('price') }}
                        </span> 
                     @endif
                  </div>
                     
                </div>
              </div>
              <div class="row text-right mt-3">
                 <div class="col-md-12">
                  <button id="add_row" class="btn btn-default pull-left">Add</button>
                  <button type="button" id='delete_row' class="pull-right btn btn-default">remove</button>
                 </div>
                </div>
              <div class="form-row layout-spacing">
                <div class="col-md-8 col-lg-8 col-8 pb-0 layout-spacing field">
                  <label for="validationCustom03">Vat</label>
                    <input type="number" class="form-control" placeholder="Vat" name="vat">
                    @if($errors->has('vat'))
                        <span for="vat" class="error ml-2 text-danger">
                          {{ $errors->first('vat') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-4 col-lg-4 col-4 pb-0 layout-spacing field">
                    <div class="n-chk mt-5">
                        <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                          <input type="checkbox" class="new-control-input" id="zero_vat" name="zero_vat">
                          <span class="new-control-indicator"></span><span class="new-chk-content">Zero Vat</span>
                        </label>
                      </div>
                  </div>
                </div> 
                <div class="form-row layout-spacing">
                  <div class="col-md-8 col-lg-8 col-8 pb-0 field">
                    <label for="validationCustom03">Opening Stock</label>
                      <input type="number" class="form-control" placeholder="Opening Stock" name="opening_stock">
                      @if($errors->has('opening_stock'))
                          <span for="opening_stock" class="error ml-2 text-danger">
                            {{ $errors->first('opening_stock') }}
                          </span> 
                       @endif
                    </div>
                    <div class="col-md-4 col-lg-4 col-4 pb-0 layout-spacing field">
                    </div>
                </div>                                                     
                <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                    <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                    <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
</div>
 <input type="hidden" name="counter" id="counter">
@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<!-- Summernote -->
{{ Html::script('plugins/summernote/summernote-bs4.min.js')}}
{{-- end --}}
<script>

$(document).ready(function() {
      // Summernote
    $('#english_description').summernote()
    $('#arabic_description').summernote()

      //Initialize Select2 Elements
    $('.select2').select2()
     
});




function back()
{
    window.location="{!!  route('items.index') !!}"
}


// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
      item_group_id: {
        required : true ,
      },
      english_description: {
        required: true,
        maxlength: 1000
      },
      arabic_description: {
        required: true,
        maxlength: 1000
      },
      item_unit: {
        required: true,
      },
       cost: {
        required: true,
        maxlength: 9
      },
      price: {
        required: true,
        maxlength: 9
      },
      quantity: {
        required: true,
        maxlength: 9
      },
      minimum_quantity: {
        required: true,
        maxlength: 9
      },
      vat: {
        maxlength: 2
      },
      opening_stock: {
        maxlength: 9
      }
    },
    messages: {
      item_group_id: {
        requiredSelect : "Please select item group !",
      },
      english_description: {
        required: "Please enter english description",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
      arabic_description: {
        required: "Please enter arabic description !",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
       item_unit: {
        required: "Please select item unit !"
      },
       cost: {
        required: "Please enter cost !",
        maxlength: "Maximum 9 numbers only allowed !"
      },
      price: {
        required: "Please enter price !",
        maxlength: "Maximum 9 numbers only allowed !"
      },
      quantity: {
        required: "Please enter quantity !",
        maxlength: "Maximum 9 numbers only allowed !"
      },
      minimum_quantity: {
        required: "Please enter minimum stock !",
        maxlength: "Maximum 9 numbers only allowed !"
      },
      vat: {
        maxlength: "Maximum 3 numbers only allowed !"
      },
      opening_stock: {
        maxlength: "Maximum 9 numbers only allowed !"
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });

 $(".select2").select2().change(function() {
    $(this).valid();
  });


  $(document).on('click', '#add_row', function(event) {
          event.preventDefault();
          /* Act on the event */

            var currentRow=$('.item_unit_div');
            var totalVal= currentRow.find(".quantity").val(); 
            var selectVal= currentRow.find(".item_unit").val(); 

            if(totalVal > 0)
            {
              temp = $("#counter").val()
            var indexNo = $("#counter").val(++temp);


            $(".item_unit_div").append('<div class="form-row layout-spacing pb-3 div-unit"><div class="col-md-6 col-lg-6 col-12  field" data-value="'+$("#counter").val()+'" id="unit-'+$("#counter").val()+'"><label for="validationCustom02">Item Unit</label>{!! Form::select('item_unit[]', $itemUnit ,null,['placeholder' => '--Select Unit--','class' => 'form-control basic select2 item_unit','required']); !!} @if($errors->has('item_unit'))<span for="item_unit" class="error ml-2 text-danger">{{ $errors->first('item_unit') }}</span>@endif</div><div class="col-md-6 col-lg-6 col-12 pb-0 layout-spacing field"><label for="validationCustom03">Minimum Stock</label><input type="number" class="form-control" placeholder="Min Stock" name="minimum_quantity[]" required>@if($errors->has('minimum_quantity'))<span for="minimum_quantity" class="error ml-2 text-danger">{{ $errors->first('minimum_quantity') }}</span> @endif</div><div class="col-md-1 col-lg-1 col-12 field mt-4"><label>Quantity</label></div><div class="col-md-8 col-lg-8 col-12 pb-0 layout-spacing field mt-3"><input type="number" class="form-control quantity" placeholder="Quantity" name="quantity[]" data-value="'+$("#counter").val()+'" id="qua-'+$("#counter").val()+'"></div></div><div class="form-row layout-spacing pb-3 div-unit"><div class="col-md-6 col-lg-6 col-6 field"><label for="validationCustom03">Cost</label><input type="number" class="form-control" placeholder="Cost" name="cost[]" required>@if($errors->has('cost'))<span for="cost" class="error ml-2 text-danger">{{ $errors->first('cost') }}</span>@endif</div><div class="col-md-6 col-lg-6 col-6 pb-0 field"><label for="validationCustom03">Price</label><input type="number" class="form-control" placeholder="Price" name="price[]" required>@if($errors->has('price'))<span for="price" class="error ml-2 text-danger">{{ $errors->first('price') }}</span>@endif</div></div>')

            // $('select').selectpicker();
            $('.select2').select2()
            }
            else
            {
              alert("please fill up the values")
            }

          
    });


  $(document).on('change', '.item_unit', function(event) {
    event.preventDefault();
      var selected = $(this);
      var myOption=$(this).val();
      // var value = $(this).closest( "div").data('value')
      // var e = myOption;

       var s =0;
        $.each($(".item_unit option:selected"), function(){
           var myselect = $(this).val();
            if(myselect==myOption){
              s += 1;
            }
        });
       

        if(s>1){
          alert('This Unit as been added already, try new..') 
          selected.val(null).trigger('change.select2');
          selected.select2('data', null, false);;
        }
        // else{
        //    fillQuantity(value,e)
        // }
    });

  $("#delete_row").click(function(){
    if($(".div-unit").length == 2){
      alert('One unit must required')
      return false;
    }else{
      $( ".item_unit_div .form-row").last().remove();
      $( ".item_unit_div .form-row").last().remove();
    }
      
    });

</script>
@endsection

