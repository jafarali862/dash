<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>POS | Genius Solutions</title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
    <link href="{{asset('pos_assets/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{asset('pos_assets/font-awesome-4.7.0/css/font-awesome.min.css')}}">
    <!-- END GLOBAL MANDATORY STYLES -->
    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="{{asset('pos_assets/assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
    <link href="{{asset('pos_assets/salescss.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('pos_assets/plugins/toastr/toastr.min.css')}}" rel="stylesheet" type="text/css" />

    <!--  END CUSTOM STYLE FILE  -->
</head>

<body>
@include('admin.master-data.shop-customer.modal.shop_customer_modal') 
@include('admin.master-data.item.modal.item_modal')
   <!--  BEGIN NAVBAR  -->

   <!--  END NAVBAR  -->

   <!--  BEGIN MAIN CONTAINER  -->
   <div class="main-container" id="container">

      <div class="overlay"></div>
      <div class="search-overlay"></div>

      <!--  BEGIN TOPBAR  -->
      <!--  END TOPBAR  -->

      <!--  BEGIN CONTENT AREA  -->
      <div id="content" class="main-content">
         <section class="sales">
            <div class="fluid">
               <div class="container-xs">
                  <div class="row">
                     <div class="col-md-9 left-col">
                        <div class="row">
                           <div class="col-lg-12">
                              <form>
                                 <div class="form-row">
                                    <div class="form-group col-md-4">
                                       <input type="text" class="form-control" id="barcode" name="barcode" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                       <label for="barcode">Barcode</label>
                                    </div>
                                    <div class="form-group col-md-4">
                                       <div class="number-quatity row ">
                                          <span class="minus col-md-2 ">-</span>
                                          <input type="text" class="form-control  col-md-8" id="quantity" name="quantity" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                          <span class="plus  col-md-2">+</span>
                                       </div>
                                       <label for="quantity">Quantity</label>
                                    </div>
                                    <div class="form-group col-md-4">
                                       <input type="text" class="form-control" id="price" name="price" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                       <label for="quantity">Price</label>
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                        <hr>
                        <div class="row invosectn">
                           <div class="col-lg-12">
                              <div class="row">
                                 <div class="col-md-4">
                                    <div class="text-left">
                                       <table>
                                          <tr>
                                             <th><span>Invoice No:</span></th>
                                             <td><span><input type="text" class="form-control" id="no" name="no" placeholder="Invoice No" readonly="" value="{{$invoiceId}}" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></span></td>
                                          </tr>
                                          <tr>
                                             <th><span>Customer Name:</span></th>
                                             <td>
                                              {!! Form::select('customer', $customers, old('customer'),['class' => 'form-control selectpicker','data-size'=>"10",'id'=>'customer','name'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
                                             </td>
                                          </tr>
                                       </table>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="text-center">
                                       <h3>Sales Invoice</h3>
                                       <small class="heading heading-double-icon center-block">
                                          <span>&nbsp;</span><i class="fa fa-star-o" aria-hidden="true"></i><span>&nbsp;</span>
                                       </small>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="text-right">
                                       <table>
                                          <tr>
                                             <th><span>Date:</span></th>
                                             <td><span><input type="date" class="form-control" id="date" name="date" value="{{$today_date}}"></span></td>
                                          </tr>
                                          <tr>
                                             <th><span>Type:</span></th>
                                             <td>
                                                <span>
                                                   <div class="n-chk">
                                                      <label class="new-control new-radio radio-primary" style="margin-top: 10px !important;">
                                                         <input type="radio" class="new-control-input" name="custom-radio-1" checked>
                                                         <span class="new-control-indicator"></span>Cash
                                                         <input type="radio" class="new-control-input" name="custom-radio-1">
                                                         <span class="new-control-indicator"></span>Card
                                                         <input type="radio" class="new-control-input" name="custom-radio-1">
                                                         <span class="new-control-indicator"></span>credit

                                                      </label>
                                                   </div>
                                                </span>
                                             </td>
                                          </tr>
                                       </table>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <hr>
                        <div class="table-wrapper">
                           <table class="table" id="tab_logic">
                              <thead>
                                 <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Unit</th>
                                    <th scope="col">Quanity</th>
                                    <th scope="col">Rate</th>
                                    <th scope="col">Total</th>
                                 </tr>
                              </thead>
                              <tbody id="table_body">
                                 <tr>
                                    <td scope="row">1</td>
                                    <td>
                            
                                      {!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect basic','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}
                                    </td>
                                    <td class="unit-tab">
                                       <select class="form-control  basic ">
                                          <option selected="selected">1</option>
                                          <option>2</option>
                                          <option>3</option>
                                       </select>
                                    </td>
                                    <td>
                                       <div class="number-quatity row ">
                                          <span class="minus col-md-2 ">-</span>
                                          <input type="text" class="form-control  col-md-8" id="quantitytab" name="quantitytab" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                          <span class="plus  col-md-2">+</span></div>
                                    </td>
                                    <td><input type="text" class="form-control-tab" id="rate" name="rate" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></td>
                                    <td><input type="text" class="form-control-tab" id="totaltab" name="totaltab" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></td>
                                    <td>
                                       <a style="cursor: pointer;" id="add_row" class="add-tab" title="Delete" data-toggle="tooltip"><i class="fa fa-plus-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;<a style="cursor: pointer;" id="delete_row" class="delete-tab" title="Delete" onclick="deleteRow(this)" data-toggle="tooltip"><i class="fa fa-trash-o" aria-hidden="true"></i></a> 
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                        <div class="row lastbtn">
                           <div class="col-lg-12">
                              <div class="item-button">
                                 <button class="btn btn-primary mb-2">General Items</button>
                                 <button class="btn btn-primary mb-2">Fruits</button>
                                 <button class="btn btn-primary mb-2">Vegetables</button>
                                 <button class="btn btn-primary mb-2">Bakery</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 right-col">
                        <form>
                           <div class="form-group row right-tender">
                              <label for="total" class="col-sm-6 col-form-label">Total</label>
                              <div class="col-sm-6">
                                 <input type="text" class="form-control total" id="total" name="total" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="discount" class="col-sm-6 col-form-label popup" style="display: none;">Discount</label>
                              <div class="col-sm-6 popups " style="display: none;">
                                 <input type="text" class="form-control" id="discount" name="discount" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="net" class="col-sm-6 col-form-label">Net</label>
                              <div class="col-sm-6">
                                 <input type="text" class="form-control" id="net" name="net" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="vat" class="col-sm-6 col-form-label">Vat</label>
                              <div class="col-sm-6">
                                 <input type="text" class="form-control" id="vat" name="vat" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="netamount" class="col-sm-6 col-form-label popupd" style="display: none;">Net Amount</label>
                              <div class="col-sm-6 popupdf " style="display: none;">
                                 <input type="text" class="form-control" id="netamount" name="netamount" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="paidcash" class="col-sm-6 col-form-label popuppc" style="display: none;">Paid Cash</label>
                              <div class="col-sm-6 popuppcf " style="display: none;">
                                 <input type="text" class="form-control" id="paidcash" name="paidcash" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="paidcard" class="col-sm-6 col-form-label popuppcd" style="display: none;">Paid Card</label>
                              <div class="col-sm-6 popuppcdf " style="display: none;">
                                 <input type="text" class="form-control" id="paidcard" name="paidcard" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                              <!--</div>-->
                              <!--<div class="form-group row">-->
                              <label for="balanceamount" class="col-sm-6 col-form-label popupba" style="display: none;">Balance Amount</label>
                              <div class="col-sm-6 popupbaf " style="display: none;">
                                 <input type="text" class="form-control" id="balanceamount" name="balanceamount" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                              </div>
                            <input type="hidden" id="counter" value="1">
                           </div>
                        </form>
                        <div class="row">
                           <div class="col-lg-12 right-tender1 ">
                              <div class="container-cal">
                                 <div class="tastierino">
                                    <div class="tasti">
                                       <div class="num num1"><input type="button" value="1" onclick="print(this)" class="cal-but"> </div>
                                       <div class="num num2"><input type="button" value="2" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num3"><input type="button" value="3" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num4"><input type="button" value="4" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num5"><input type="button" value="5" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num6"><input type="button" value="6" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num7"><input type="button" value="7" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num8"><input type="button" value="8" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num9"><input type="button" value="9" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num9"><input type="button" value="." onclick="print(this)" class="cal-but"></div>
                                       <div class="num num0"><input type="button" value="0" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num9"><input type="button" value="C" id="del" class="cal-but" onclick="deleteLast()"> </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-lg-12 ">
                                    <div class="item-button">
                                       <button class="btn btn-success mb-2"><i class="fa fa-print" aria-hidden="true"></i> Print</button>
                                       <button class="btn btn-success mb-2"><i class="fa fa-floppy-o" aria-hidden="true"></i> Save</button>
                                       <a class="closes"><i class="fa fa-times" aria-hidden="true"></i></a>
                                       <div class="item-button icon-last">
                                          <a href="#"><i class="fa fa-barcode" aria-hidden="true"></i></a>
                                          <button class="btn btn-dark mb-2" onclick="displaypopup()">Tender</button>
                                          <a href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class=" row right-tender2">
                           <div class="col-lg-12 ">
                              <div class="item-button popuppr">
                                 <button class="btn btn-info mb-2">Return</button>
                                 <button class="btn btn-info mb-2">Hold</button>
                                 <button class="btn btn-info mb-2">View</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <div class="footer-wrapper" style="display: none;">
            <div class="footer-section f-section-1">
               <p class="">© 2020 Genius Solutions
                  <a target="_blank" href="https://designreset.com">DesignReset</a>, All rights reserved.</p>
            </div>
            <div class="footer-section f-section-2">
               <p class="">Designed and Developed By Epage Designers</p>
            </div>
         </div>
      </div>
      <!--  END CONTENT AREA  -->

   </div>
   <!-- END MAIN CONTAINER -->

   <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
   <script src="{{asset('pos_assets/assets/js/libs/jquery-3.1.1.min.js')}}"></script>
   <script src="{{asset('pos_assets/bootstrap/js/popper.min.js')}}"></script>
   <script src="{{asset('pos_assets/bootstrap/js/bootstrap.min.js')}}"></script>
   <script src="{{asset('pos_assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
   <script src="{{asset('pos_assets/assets/js/app.js')}}"></script>
   <script src="{{asset('pos_assets/plugins/toastr/toastr.min.js')}}"></script>
   <script>
      $(document).ready(function() {         
         $('#customer').selectpicker({
          noneResultsText: '<a href="" class="btn btn-outline-primary _addMore" data-toggle="modal" data-target="#create_customer"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Customer </a>'
        }); 
        $('#Products').selectpicker({
          noneResultsText: '<a href="" class="btn btn-outline-primary _addMore" data-toggle="modal" data-target="#create_item_modal"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Product </a>'
        });
      });
      $(document).on('click', '#add_row', function(event) {
          event.preventDefault();
          /* Act on the event */

          var currentRow=$('#tab_logic tr:last');

            var totalVal = document.getElementById("total").value;
            var selectVal= currentRow.find(".basic").val(); 

            // if(totalVal > 0 && selectVal)
            // {
            var products = <?php echo json_encode($products); ?>;
            var product = "";
            for (i=0; i< products.length; i++)
            {
               product = '<option value="">'+products[i]['english_short_description']+'</option>';
            }
            temp = $("#counter").val()
            var indexNo = $("#counter").val(++temp);

            $("#table_body").append('<tr><td scope="row">'+$("#counter").val()+'</td><td>{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect basic','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}</td><td class="unit-tab">{!! Form::select('unit[]', $units, old('Unit'),['class' => 'selectpicker form-control unit','required','data-size'=>"10",'id'=>'Unit','data-live-search'=>"true",'title'=>'Select Unit']) !!}</td><td><div class="number-quatity row "><span class="minus col-md-2 ">-</span><input type="text" class="form-control  col-md-8" id="quantitytab" name="quantitytab" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"><span class="plus  col-md-2">+</span></div></td><td><input type="text" class="form-control-tab" id="rate" name="rate" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></td><td><input type="text" class="form-control-tab" id="totaltab" name="totaltab" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></td><td><a style="cursor: pointer;" id="add_row" class="add-tab" title="Delete" data-toggle="tooltip"><i class="fa fa-plus-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;<a style="cursor: pointer;" class="delete-tab" id="delete_row" title="Delete" data-toggle="tooltip" onclick="deleteRow(this)"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td></tr>')

            // }
            // else
            // {
            //   alert("please fill up the values")
            // }

          
        });

      // DELETE ROW
      function deleteRow(row)
      {
        temp = $("#counter").val()
        if(temp > 1)
        {
           var i=row.parentNode.parentNode.rowIndex;
           document.getElementById('tab_logic').deleteRow(i);
           $("#counter").val(--temp)
           toastr.success("One item removed..!");
        }else{
           toastr.error("Atleast one item required for billing..!");
        }
      }
      function displaypopup() {
        $('.popup').toggle();
        $('.popups').toggle();
        $('.popupd').toggle();
        $('.popupdf').toggle();
        $('.popuppc').toggle();
        $('.popuppcf').toggle();
        $('.popuppcd').toggle();
        $('.popuppcdf').toggle();
        $('.popupba').toggle();
        $('.popupbaf').toggle();
      }

   </script>
   <script src="{{asset('pos_assets/plugins/highlight/highlight.pack.js')}}"></script>
    <script src="{{asset('pos_assets/assets/js/custom.js')}}"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <!--  BEGIN CUSTOM SCRIPTS FILE  -->
    <script src="{{asset('pos_assets/assets/js/scrollspyNav.js')}}"></script>
   
    <script src="{{asset('plugins/select2/select2.min.js')}}"></script>
    <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>
    <!--  BEGIN CUSTOM SCRIPTS FILE  -->
</body>

</html>