@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->
 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
 </style>
 @endsection
 @section('content')
 <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-10 col-lg-10 col-sm-10 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>@if($type == 'bank' || $type== 'bank-payment' || $type== 'cash' || $type== 'cash-receipt')
             {{$type}}
                 @endif
              </h4>
            </div>
          </div>
          <div id="content" class="main-content w-50">
            <form  action="{{isset($edit_account) ? route('account-transactions.update', [$edit_account->id]) : route('account-transactions.store')}}" method="post" id="createaccount" name="createaccount">
              @csrf
              <input type="hidden" name="type" value="{{$type}}">
              @if(isset($edit_account))
                @method('PUT')
              @endif
                <div class="form-row">
                <div class="col-md-6 mb-6 field">
                  <label for="validationCustom02">ID</label>
                  <input type="text" class="form-control" placeholder="ID" value="{{ isset($edit_account) ? '#'.$edit_account->id : @$cust_id }}" readonly="">            
                  </div>
                 
                  <div class="col-md-6 mb-6 field">
                   @if($type == 'bank' || $type== 'bank-payment' || $type== 'cash' || $type== 'cash-receipt')     
                    <label for="validationCustom02">Doc Date</label>
                    <input type="date" class="form-control date"  name="doc_date" placeholder="Sunday/Monday" value="{{old('doc_date',isset($edit_account)? $edit_account->doc_date : '')}}" required/>
                  </div>

                </div>  

                  <div class="form-row">

                   <div class="col-md-6 mb-6 field">                
                    <label for="validationCustom02">Account Type</label>
                  {!! Form::select('account_id', $areacode ,@$edit_account->account_id,['placeholder' => '--Select Account type --','class' => 'form-control basic select2 item_group_id','required'=>'']); !!}

                  </div>

                    <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Account</label>
                   {!! Form::select('user_id', $saleaman ,@$edit_account->user_id,['placeholder' => '--Select Account --','class' => 'form-control basic select2 item_group_id','required'=>'']); !!}

                  </div>
                  </div> 

                  <div class="form-row">
                   <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Amounts</label>
                    <input type="number" class="form-control" placeholder="Amount"name="amount" id="amount" value="{{old('amount',isset($edit_account)? $edit_account->amount : '')}}" required/>
                  </div>         
              
                     <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Reference</label>
                    <input type="text" class="form-control" placeholder="Reference" name="remarks" value="{{old('remarks',isset($edit_account)? $edit_account->remarks : '')}}" required/>
                  </div>              
                </div>

                <div class="form-row">        
                <div class="col-md-12 mb-12 field">
                  <label for="validationCustom02">Description</label>
                    <input type="text" class="form-control" value="{{old('description',isset($edit_account)? $edit_account->description : '')}}" placeholder="Description" name="description" required/>
                  </div>
                    @endif
                 
                </div>  

                  <div class="form-row">      
                  @if($type == 'bank' || $type== 'bank-payment')
                    <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Bank</label>
                  {!! Form::select('bank_id', $bankcode ,@$edit_account->bank_id,['placeholder' => '--Select Bank --','class' => 'form-control basic select2 item_group_id','required'=>'']); !!}
                  </div>
                
                   <div class="col-md-6 mb-6 field">
                    <label for="validationCustom02">Cheque No</label>
                    <input type="number" class="form-control" placeholder="Cheque No" 
                    name="cheque_no" value="{{old('cheque_no',isset($edit_account)? $edit_account->cheque_no : '')}}" required/>
                      @endif
                 
                    </div> 
                </div>  
            
                </div>
                <br>                                                  
                <div class="modal-footer md-button">
                <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                  <button type="submit" class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                  <button type="submit" class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                  
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
 @endsection
 @section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script src="{{asset('plugins/select2/custom-select2.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPTS FILE  -->
{{-- end --}}
<script>
  $(document).ready(function() {
      //Initialize Select2 Elements
    $('.select2').select2()
     
});
  $(function() {
     $("#own_code").focus();
   });
  // FORM SUBMIT WITH VALIDATION
  // Validate popup
  $('#createaccount').validate({
    ignore: [],
    rules: {
      cust_name: {
        required: true,
        maxlength: 1000
      }
    },

    messages: {
      account_id: {
        required: "Please select account",
      },
      user_id: {
        required: "Please select account type",
      },
      remarks: {
        required: "Please enter references !..",
      },
      doc_date: {
        required: "Please select document_date !..",
      },
      amount: {
        required: "Please enter amount !..",
      },
      description: {
        required: "Please enter descriptions !..",
      },
       bank_id: {
        required: "Please select bank !..",
      },  
      cheque_no: {
        required: "Please enter cheque_no !..",
      }    
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
   

function back()
{
  window.location="{!!  url('account-transactions/show/'.$type) !!}"
}

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });
    @if(Session::has('message'))
    var type = "{{ Session::get('alert-type', 'info') }}";
    switch(type){
        case 'info':
            toastr.info("{{ Session::get('message') }}");
            break;

        case 'warning':
            toastr.warning("{{ Session::get('message') }}");
            break;

        case 'success':
            toastr.success("{{ Session::get('message') }}");
            break;

        case 'error':
            toastr.error("{{ Session::get('message') }}");
            break;
    }
  @endif
</script>

@endsection