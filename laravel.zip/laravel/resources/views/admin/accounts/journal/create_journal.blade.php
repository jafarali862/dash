@extends('layouts.app')
@section('style')
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/flatpickr/flatpickr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->

<style type="text/css">
  #tab_logic .form-control[readonly],#tab_logic_total .form-control[readonly] {
    border: 0;
    background: transparent;
    box-shadow: none;
    padding: 0 10px;
    font-size: 15px;
  }
  .form-control{font-size: 12px !important;}
  .bootstrap-select.btn-group > .dropdown-toggle {font-size: 12px !important;}
  .list-group-item{padding:2%!important;}
  .pricesummary{margin-top: 3%;border: 1px solid black;padding:0.7%;}
  .spaceTop{margin-top: 6%;}
  .gTotal{margin-top: 5.5%;}
  .vertical-line{
        display: inline-block;
        border-left: 1px solid #ccc;
        margin: 0 10px;
        height: 40px;
    }
    /*.unit{pointer-events: none;}*/
    .hideStock{display: none;}

    ._addMore{width: 100%;}

    /* Add a right margin to each icon */
    .fa {
      margin-left: -12px;
      margin-right: 8px;
    }
 .btn-outline-primary:hover {
    color: #f9f9f9 !important;
}
</style>
@endsection
@section('content')
{!! Form::open(['route' => 'saveJournal']) !!}

 
<input type="hidden" value="{{@$edit_journal->id}}" name="journal_id">

<div id="content" class="main-content">
  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-md-12">
              <div class="row">

                <div class="col-md-5">
                  <div class="form-group row mb-4">
                    <label for="" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">JV.No</label>
                    <div class="col-xl-8 col-lg-7 col-sm-7 input-group-sm">
                      <input type="text" class="form-control" id="" placeholder="JV Number" name="" readonly="" value="{{$journalId}}">
                    </div>
                 
                    
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input id="basicFlatpickr" value="{{@$edit_journal->doc_date}}" class="form-control flatpickr flatpickr-input active" type="date" id="doc_date" placeholder="Select Date.." name="doc_date" required>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-3">
                  <div class="form-group row mb-4">             
                    <label for="validationCustom02" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Cost Center</label>
                      <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                     {!! Form::select('cost_id', $costcode ,@$edit_journal->cost_id,['placeholder' => '--Select Cost Center --','class' => 'form-control basic select2 item_group_id','required'=>'']); !!}
                     
                    </div>  


                  </div>
                </div>
              </div>
       
                
              </div>
            </div>
          </div>

          <div class="container-fluid">
            <div class="row clearfix">
              <div class="col-md-12 table-responsive">
                <table class="table" id="tab_logic">
                  <thead>
                    <tr>
                      <th class="text-center"> Account # </th>
                      <th class="text-center"> Account Type </th>
                      <th class="text-center"> Name of Account</th>
                      <th class="text-center"> Particulars </th>
                      <th class="text-center"> Debit </th>
                      <th class="text-center"> Credit </th>
                     
                    </tr>
                  </thead>
                  <tbody id="table_body">
                    @if(isset($journalDetails))
                      @foreach($journalDetails as $key => $details)
                      <tr>
                        <td>{{ $key+1 }}</td>
                        <td>
                    {!! Form::select('account_id[]', $areacode, old('account_id',$details->account_id),['class' => 'selectpicker form-control account_id','required'=>'xdg','data-size'=>"10",'id'=>'account_id','data-live-search'=>"true",'title'=>'Select Account Type']) !!}
                
                        </td>
                        <td>               

                           {!! Form::select('user_id[]', $saleaman, old('user_id',$details->user_id),['class' => 'selectpicker form-control user_id','required','data-size'=>"10",'id'=>'user_id','data-live-search'=>"true",'title'=>'Select Account']) !!}
                        </td>
                        <td>
                          <input type="text" name='particular[]' placeholder='Particulars' class="form-control price testing" value="{{old('particular',$details->particular)}}"   step="0.00" min="0"/>
                        </td>
                        <td>
                          <input type="number" name='debit[]' placeholder='Debit' class="form-control debit"  value="{{old('debit',$details->debit)}}" step="any" min="0" required/>
                        </td>
                        <td>
                          <input type="number"  value="{{old('credit',$details->credit)}}" name='credit[]' placeholder='Credit' class="form-control credit" step="any" min="0" required/>
                        </td>
                  
                      </tr>
                      @endforeach
                    @else
                    <tr>
                      <td>1 ###</td>
                      <!-- <td class="code">###</td> -->
                      <td>
                  {!! Form::select('account_id[]', $areacode, old('account_id'),['class' => 'selectpicker form-control account_id','required'=>'','data-size'=>"10",'id'=>'account_id','data-live-search'=>"true",'title'=>'Select Account Type']) !!}
              
                      </td>
                      <td>               

                         {!! Form::select('user_id[]', $saleaman, old('user_id'),['class' => 'selectpicker form-control user_id','required','data-size'=>"10",'id'=>'user_id','data-live-search'=>"true",'title'=>'Select Account']) !!}
                      </td>
                      <td>
                        <input type="text" name='particular[]' placeholder='Particulars' class="form-control price testing" value="{{old('particular')}}"   step="0.00" min="0" required/>
                      </td>
                      <td>
                        <input type="number" name='debit[]' placeholder='Debit' class="form-control debit"  value="{{old('debit')}}" step="any" min="0" required/>
                      </td>
                      <td>
                        <input type="number"  value="{{old('credit')}}" name='credit[]' placeholder='Credit' class="form-control credit" step="any" required/>
                      </td>
                
                    </tr>
                    @endif
                  </tbody>
                </table>
              </div>
            </div>
           
            <div class="row pricesummary">
              <div class="col-md-2">
                <div class="row">
                  <div class="col-md-12">
                   
                  </div>
                </div>
              </div>
             
              
              <div class="col-md-3">
                <div class="row" style="margin-top: 2%;">
                  <div class="col-md-12">
                    <input type="submit" class="btn btn-success btn-sm" name="btn_value" value="save">
                    <input type="submit" class="btn btn-success btn-sm" name="btn_value" value="save & new">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

{{ Form::close() }}



 
    @endsection
    @section('script')
    <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
    <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
    <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
    <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
    <!--  BEGIN CUSTOM SCRIPT FILE  -->
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('plugins/flatpickr/flatpickr.js')}}"></script>
    <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>
    <script src="{{asset('plugins/select2/select2.min.js')}}"></script>
    {{-- <script src="{{asset('plugins/select2/custom-select2.js')}}"></script> --}} 

    <script>
       $(function() {
          $("#customer").focus();
         });  
      $(document).ready(function(){
            $('#customer_text').hide();
            $('#save_customer_please_wait').hide();
            $('#save_item_please_wait').hide();
            var datePicker = $("#basicFlatpickr").flatpickr({
              altFormat: "F j, Y",
              dateFormat: "Y-m-d",
              defaultDate: "today",
            });
            @if(isset($edit_journal))
              datePicker.setDate('{{$edit_journal->doc_date}}');
            @endif

      });
  </script>
    @endsection

