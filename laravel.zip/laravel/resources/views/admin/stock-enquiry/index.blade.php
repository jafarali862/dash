 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
    {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
   {{ Html::style('plugins/animate/animate.css') }}
   {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
   {{ Html::style('plugins/select2/select2.min.css') }}
  {{-- summernote --}}
  {{ Html::style('plugins/summernote/summernote-bs4.css') }}

 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }

/* Add a right margin to each icon */
.fa {
  margin-left: -12px;
  margin-right: 8px;
}
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Stock Enquiry</h4>
            </div>
          </div>
          <div class="main-content">
              <div class="form-row">
                <div class="col-md-1 col-lg-1 col-12 pb-3 layout-spacing field">
                </div>
                <div class="col-md-5 col-lg-5 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Select Items</label>
                    {!! Form::select('item_id', $items ,null,['placeholder' => '--Select Items--','class' => 'form-control basic select2 item_group_id','data-size'=>"10",'required','id' => 'item_id']); !!}
                 </div>
                 <div class="col-md-2 col-lg-2 col-12 pb-3 layout-spacing field">
                  <button style="margin-top: 26%;" onclick="getDetails()" class="btn btn-warning mb-4 mr-2 btn-sm" id="showBtn">Show Details</button>
                  <button id="hiddenBtn" style="margin-top: 26%;"class="btn btn-warning mb-4 mr-2 btn-sm"><i class="fa fa-refresh fa-spin"></i>please wait..</button>
                 </div>
              </div>
          </div>
        </div>
      </div>
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing" id="detailDiv">
        <div class="widget-content widget-content-area br-6">
           <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h5>--Details Of Item--</h5>
            </div>
          </div>
          <div class="main-content show">
              {{-- <div class="row item_code">
              </div> --}}
          </div>
        </div>
      </div>
    </div>
</div>
@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script>
$(document).ready(function() {
  
      //Initialize Select2 Elements
    $('.select2').select2()
    $('#detailDiv').hide();
    $('#loadingIcon').hide();
    $('#hiddenBtn').hide();
});
 function getDetails()
 {
    var item_id = document.getElementById('item_id').value;

    if(item_id)
    {
      $('#hiddenBtn').show();
      $('#showBtn').hide();
    }else{
       toastr.error("please select items..!");
    }
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $.ajax({
                    url: '/stock-enquiry/details',
                    type: 'GET',
                    data: {_token: CSRF_TOKEN, itemid : item_id ,doAction:'getDetails'},
                    dataType: 'JSON',
                    success: function (data) { 
                       $('#detailDiv').show();
                       $(".show").html(data.items);
                       // $(".item_code").html(data.item_code);
                       $('#hiddenBtn').hide();
                       $('#showBtn').show();
                      
                    }
                }); 
 }
</script>
@endsection

