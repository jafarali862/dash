@extends('layouts.app')
@section('style')
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/flatpickr/flatpickr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->

<style type="text/css">
	#tab_logic .form-control[readonly],#tab_logic_total .form-control[readonly] {
		border: 0;
		background: transparent;
		box-shadow: none;
		padding: 0 10px;
		font-size: 15px;
	}
	.form-control{font-size: 12px !important;}
	.bootstrap-select.btn-group > .dropdown-toggle {font-size: 12px !important;}
	.list-group-item{padding:2%!important;}
	.pricesummary{margin-top: 3%;border: 1px solid black;padding:0.7%;}
	.spaceTop{margin-top: 6%;}
	.gTotal{margin-top: 5.5%;}
	.vertical-line{
        display: inline-block;
        border-left: 1px solid #ccc;
        margin: 0 10px;
        height: 40px;
    }
    /*.unit{pointer-events: none;}*/
    .hideStock{display: none;}

    ._addMore{width: 100%;}

    /* Add a right margin to each icon */
    .fa {
      margin-left: -12px;
      margin-right: 8px;
    }
 .btn-outline-primary:hover {
    color: #f9f9f9 !important;
}
</style>
@endsection
@section('content')
@include('admin.master-data.shop-customer.modal.shop_customer_modal') 
@include('admin.master-data.item.modal.item_modal')
 {!! Form::open(['route' => 'saveInvoice']) !!}
<div id="content" class="main-content">
	<div class="layout-px-spacing">
		<div class="row layout-top-spacing" id="cancel-row">
			<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
				<div class="widget-content widget-content-area br-6">
					<div class="row">
						<div class="col-md-12">
							<div class="row">

								<div class="col-md-5">
									<div class="form-group row mb-4">
										<label for="" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Invoice.No</label>
										<div class="col-xl-8 col-lg-7 col-sm-7 input-group-sm">
											<input type="text" class="form-control" id="" placeholder="Inoice Number" name="" readonly="" value="{{$invoiceId}}">
										</div>
										<div class="col-xl-2 col-lg-3 col-sm-3 input-group-sm">
											<a   href="{{ url('view-invoice') }}"><i style="color:#2196f3;" data-feather="eye"></i><span class="icon-name"></a>
											
											<a  href="{{ url('edit-invoice') }}"><i style="color:#8dbf42;" data-feather="edit-3"></i><span class="icon-name"></a>
											
										</div>
										
									</div>
								</div>

								<div class="col-md-4">
									<div class="form-group row mb-4 ">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input id="basicFlatpickr" value="" class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date.." name="date" required>
										</div>
									</div>
								</div>
								
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="number_2" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Cnt.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="number" class="form-control" id="number_2" placeholder="Number" name="number_2">
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-5">
									<div class="form-group row mb-4">
                                        <label for="" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Customer</label>
										<div class="col-xl-10 col-lg-9 col-sm-9 input-group-sm" id="customer_search">
											{!! Form::select('customer', $customers, old('customer'),['class' => 'selectpicker form-control','data-size'=>"10",'id'=>'customer','name'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
										</div>
										<div class="col-xl-10 col-lg-9 col-sm-9 input-group-sm" id="customer_text">
										   <input type="text" class="form-control" id="customertext" placeholder="Customer Name" required name="customer_text">
									     </div>
									</div>
								</div>
								<div class="col-md-1">
									<div class="form-check pl-0 input-group-sm">
										<div class="custom-control custom-checkbox checkbox-info">
											<input type="checkbox" class="custom-control-input " id="gridCheck" name="any" onclick="showCustomer()">
											<label class="custom-control-label" for="gridCheck">Any</label>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="custom-control custom-radio custom-control-inline">
										<input type="radio" id="customRadioInline1" name="cash_or_card" class="custom-control-input" value="cash" checked="" required>
										<label class="custom-control-label" for="customRadioInline1">Cash</label>
									</div>
									<div class="custom-control custom-radio custom-control-inline">
										<input type="radio" id="customRadioInline2" name="cash_or_card" class="custom-control-input" value="card">
										<label class="custom-control-label" for="customRadioInline2">Card</label>
									</div>
									<div class="custom-control custom-radio custom-control-inline">
										<input type="radio" id="customRadioInline3" name="credit" class="custom-control-input" value="credit">
										<label class="custom-control-label" for="customRadioInline3">Credit</label>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="po_no" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">PO.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="po_no" placeholder="PO.No" required name="po_no">
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="phone_no" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Mob</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="number" class="form-control" id="phone_no" placeholder="Phone Number" name="phone_no" required>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Del.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="del_no" placeholder="Del.No" name="del_no" required>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<div class="col-md-12 input-group-sm">
											<input type="text" class="form-control" id="remark1" placeholder="Remark 1" name="remark">
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<div class="col-md-12 input-group-sm">
											<input type="text" class="form-control" id="remark2" placeholder="Remark 2" name="remark2">
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>

					<div class="container-fluid">
						<div class="row clearfix">
							<div class="col-md-12 table-responsive">
								<table class="table" id="tab_logic">
									<thead>
										<tr>
											<th class="text-center"> # </th>
											<th class="text-center"> Code </th>
											<th class="text-center"> Product </th>
											<th class="text-center" style="width: 13%;"> Unit </th>
											<th class="text-center" style="width: 10%;"> Price </th>
											<th class="text-center" style="width: 10%;"> Quantity </th>
											<th class="text-center hideStock" style="width: 10%;"> Stock </th>
											<th class="text-center" style="width: 10%;"> InvCost </th>
											<th class="text-center" style="width: 10%;"> Vat </th>
											<th class="text-center" style="width: 10%;"> Total </th>
										</tr>
									</thead>
									<tbody id="table_body">
										<tr>
											<td>1</td>
											<td class="code">###</td>
											<td>
												{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}
											</td>
											<td>
												{!! Form::select('unit[]', $units, old('Unit'),['class' => 'selectpicker form-control unit','required','data-size'=>"10",'id'=>'Unit','data-live-search'=>"true",'title'=>'Select Unit']) !!}
											</td>
											<td>
												<input type="number" name='price[]' placeholder=' Price' class="form-control price testing" step="0.00" min="0"/>
											</td>
											<td>
												<input type="number" name='qty[]' placeholder='Qty' class="form-control qty" step="0" min="0"/>
											</td>
											<td class="hideStock">
												<input type="number" name='Stock[]' placeholder='Stock' class="form-control stock" value="0" readonly/>
											</td>
											<td>
												<input type="number" name='invCost[]' placeholder='InvCost' class="form-control cost" value="0" readonly/>
											</td>
											<td>
												<input type="number" name='vat[]' placeholder='0.00' class="form-control vat" readonly/>
											</td>
											<td>
												<input type="number" name='total[]' placeholder='0.00' class="form-control total" readonly/>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<div class="row clearfix">
							<div class="col-md-12">
								<button id="add_row" class="btn btn-default pull-left">Add Row</button>
								<button type="button" id='delete_row' class="pull-right btn btn-default">Delete Row</button>
							</div>
						</div>

						<div class="row pricesummary">
							<div class="col-md-2">
								<div class="row">
									<div class="col-md-12">
										<input type="number" class="form-control" name="discount" placeholder="Discount %" id="disount" />
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="row spaceTop">
									<div class="col-md-6"><p>Sub Total</p></div>
									<div class="col-md-6"><p class="sub_total"></p></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-2">
								<div class="row spaceTop">
									<div class="col-md-6"><p>VAT</p></div>
									<div class="col-md-6"><p id="vat_val"></p></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-2">
								<div class="row gTotal">
									<div class="col-md-4"><h6>Total</h6></div>
									<div class="col-md-8"><h6 id="total_amount"></h6></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-3">
								<div class="row" style="margin-top: 2%;">
									<div class="col-md-12">
										<input type="submit" class="btn btn-success btn-sm" name="btn_value" value="save">
										<input type="submit" class="btn btn-success btn-sm" name="btn_value" value="save & new">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="counter" value="1">
<input type="hidden" id="sub_total" value="0" name="sub_total">
<input type="hidden" id="grant_total" value="0" name="grant_total">
{{ Form::close() }}

 <div class="modal" id="purchaseHistoryModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Purchase History</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th class="text-center"> Invoice Id </th>
											<th class="text-center"> Code </th>
											<th class="text-center"> Price </th>
											<th class="text-center"> InvCost </th>
											<th class="text-center"> Quantity </th>
											<th class="text-center"> Purchased On </th>
										</tr>
									</thead>
									<tbody id="purchase_history_table">
										
									</tbody>
								</table>
							</div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
   <div class="modal" id="productDetailModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Product Detail</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 table-responsive">
					<table class="table">
						<thead>
							<tr>
							   <th class="text-center"> Cost </th>
							   <th class="text-center"> Price </th>
							   <th class="text-center"> Quty </th>
							   <th class="text-center"> Stock </th>
							  
							   
							</tr>
						</thead>
					<tbody id="product_detail">	
					</tbody>
				</table>
		   + </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
    @endsection
    @section('script')
    <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
    <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
    <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
    <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
    <!--  BEGIN CUSTOM SCRIPT FILE  -->
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('plugins/flatpickr/flatpickr.js')}}"></script>
    <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>
    <script src="{{asset('plugins/select2/select2.min.js')}}"></script>
    {{-- <script src="{{asset('plugins/select2/custom-select2.js')}}"></script> --}}	

    <script>
    	 $(function() {
          $("#customer").focus();
         });
    	function showCustomer() {
         var valueofany = document.getElementById("gridCheck");
         var cust_text = document.getElementById("customer_text");

           if (valueofany.checked == true){
             	$("#customertext").focus();
                cust_text.style.display = "block";
                customer_search.style.display = "none";
             } else {
                cust_text.style.display = "none";
                customer_search.style.display = "block";
             }
         }
        function saveItem()
		{
			
			$('#save_item_please_wait').show();
			$('#save_item').hide();
			$("#save_item_please_wait").attr("disabled", "disabled");
			var customerdata = $('#createItem').serialize();
			$.ajax({
					type: 'POST',
					url: '{{URL::to('saveItem')}}', 
					data : customerdata,
					success: function (data) {
						if(data.status == 200)
						{
							$('#save_item_please_wait').hide();
			                $('#save_item').show();
							 toastr.success("Item added sucessfully..!");
							 document.getElementById('createItem').reset();
							 $('#create_item_modal').modal('hide');
								$('select[id=Products]').each(function(){
								$(this).append($('<option>', { 
								value: data.id,
								text : data.item_name 
								}));
								});

							$CurrentSelectBox.val(data.id) 	
							$CurrentSelectBox.closest('tr').find('.code').text(data.id)

							$ele4 = $CurrentSelectBox.closest('td').parent().find('#Unit')
							$ele4.find('option').remove()

							$ele4.append($('<option>', { 
								value: data.unit,
								text : data.unit_name 
								}));
							$('.selectpicker').selectpicker('refresh');
							$ele4.val(data.unit)
							$CurrentSelectBox.closest('td').parent().find('.price').val(data.price)
							$CurrentSelectBox.closest('td').parent().find('.stock').val(data.minimum_stock)
							$CurrentSelectBox.closest('td').parent().find('.cost').val(data.cost)
							$CurrentSelectBox.closest('td').parent().find('.vat').val(data.vat)
						
							$('.selectpicker').selectpicker('refresh');						 
							
						}else{
                            toastr.error("something went wrong.try again..!");
						}
					}
				});
		}

		function saveCustomer()
		{
			if(document.getElementById('cust_name').value == '' && document.getElementById('mobile').value == '')
			{
               toastr.error("Please enter customer name..!");
               toastr.error("Please enter customer mobile..!");
			}
			else{
			$('#save_customer_please_wait').show();
			$("#save_customer_please_wait").attr("disabled", "disabled");
			$('#save_customer').hide();
			var customerdata = $('#createcustomer').serialize();
			$.ajax({
					type: 'POST',
					url: '{{URL::to('saveCustomerDetails')}}', 
					data : customerdata,
					success: function (data) {
						if(data.status == 200)
						{
							 toastr.success("Customer added sucessfully..!");
							 document.getElementById('createcustomer').reset();
							 $('#save_customer_please_wait').hide();
							 $('#save_customer').show();
							 $('#create_customer').modal('hide');
							 $("#save_customer").html("Save");
							
							 $('#customer').append($('<option>', { 
								value: data.id,
								text : data.cust_name 
								}));
							 $('#customer').val(data.id)
                             $('.selectpicker').selectpicker('refresh');
							 
							
						}else{
                            toastr.error("something went wrong.try again..!");
						}
					}
				});
		  }
		}

    	$(document).ready(function(){
    		    $('#customer_text').hide();
    		    $('#save_customer_please_wait').hide();
    		    $('#save_item_please_wait').hide();
				$("#basicFlatpickr").flatpickr({
					altFormat: "F j, Y",
					dateFormat: "Y-m-d",
					defaultDate: "today",
				}); 

				$('#customer').selectpicker({
					noneResultsText: '<a href="" class="btn btn-outline-primary _addMore" data-toggle="modal" data-target="#create_customer"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Customer </a>'
				}); 

				$('#Products').selectpicker({
					noneResultsText: '<a href="" class="btn btn-outline-primary _addMore" data-toggle="modal" data-target="#create_item_modal"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Product </a>'
				});

			$("#delete_row").click(function(){
				temp = $("#counter").val()
				if(temp > 1)
				{
					$('#tab_logic tr:last').remove()
					$("#counter").val(--temp)
					calc();
				}
				else{
					alert("Mininum 1 item required to bill");
				}
    			
    		});


    		$(document).on('click', '#add_row', function(event) {
    			event.preventDefault();
    			/* Act on the event */

    			var currentRow=$('#tab_logic tr:last');
        		var totalVal= currentRow.find(".total").val(); 
        		var selectVal= currentRow.find(".selectpicker").val(); 

        		if(totalVal > 0 && selectVal)
        		{
        			temp = $("#counter").val()
    				var indexNo = $("#counter").val(++temp);

    				$("#table_body").append('<tr><td>'+$("#counter").val()+'</td><td class="code">###</td><td>{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}</td><td>{!! Form::select('unit[]', $units, old('Unit'),['class' => 'selectpicker form-control unit','required','data-size'=>"10",'id'=>'Unit','data-live-search'=>"true",'title'=>'Select Unit']) !!}</td><td><input type="number" name="price[]"" placeholder="Price" class="form-control price" step="0.00" min="0"/></td><td><input type="number" name="qty[]"" placeholder="Qty" class="form-control qty" step="0" min="0"/></td><td class="hideStock"><input type="number" name="Stock[]"" placeholder="Stock" class="form-control stock" value="0" readonly/></td><td><input type="number" name="invCost[]"" placeholder="InvCost" class="form-control cost" value="0"readonly/></td><td><input type="number" name="vat[]"" placeholder="0.00" class="form-control vat" readonly/></td><td><input type="number" name="total[]" placeholder="0.00" class="form-control total" readonly/></td></tr>')

    				// $('select').selectpicker();
    				$('.productSelect').selectpicker({
					noneResultsText: '<a href="" class="btn btn-outline-primary _addMore" data-toggle="modal" data-target="#create_item_modal"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Product </a>'
				});
    				$('select').selectpicker();
        		}
        		else
        		{
        			alert("please fill up the values")
        		}

    			
    		});
    	});

    	function calc()
    	{
    		$('#tab_logic tbody tr').each(function(i, element) {
    			var html = $(this).html();

    			var qty = $(this).find('.qty').val();
    			var price = $(this).find('.price').val();
    			var stock = $(this).find('.stock').val();
    			var vat = $(this).find('.vat').val();

    			$(this).find('.total').val(qty*price+qty*vat);

    			if(+qty > +stock)
    				{
    					alert("Insufficient stock")
    					$(this).find('.qty').val('')
    					$(this).find('.total').val('')
    				}

    			calc_total();
    		});
    	}

    	function calc_total()
    	{
    		total=0;
    		$('.total').each(function() {
    			total += parseInt($(this).val());

    		});

    		vat = 0;
    		$('.vat').each(function(index, element){
    		vat += $(this).val() * parseInt($(this).closest('td').parent().find('.qty').val())
				});

    		if(!(isNaN(vat)))
    		{
    			$("#vat_val").html("Rs "+vat)
    		}
    		
    		$("#total_amount").text("Rs "+total)
    		$("#sub_total").val(total)
    		$(".sub_total").html("Rs "+total)
    		$("#grant_total").val(total)
    	}

    	$("#disount").on('keyup', function(event) {
    		/* Act on the event */

    			if($("#sub_total").val() > 0 && $(this).val().length > 0 && $(this).val() > 0)
				{
				
				var final = $("#sub_total").val() - ($("#sub_total").val()*$(this).val()/100);
				if(!(isNaN(final)))
				{
					$("#total_amount").text("Rs "+final)
					$("#grant_total").val(final)	
				}
				
				}
 
    		else
    		{
    			$("#total_amount").text("Rs "+$("#sub_total").val())
    			$("#grant_total").val($("#sub_total").val())
    		}
    	});

			$(document).on('change', '.selectpicker', function(event) {
				event.preventDefault();
				/* Act on the event */
				$CurrentSelectBox = $(this);
				var selected = $(this);
				var myOption = $(this).val();



				switch($(this).attr('id')) {
				
				case "customer":
                    
                    if($(this).val()==0)
					{
						$('#create_customer').modal('show');

						selected.val('default');
						selected.selectpicker("refresh");
					}
					else
					{
					$.ajax({
						type: 'get',
						url: '{{URL::to('getCustomerDetails')}}', 
						data :{ 'customer_id' : $(this).val()},
						success: function (data) {
							if(data.status == 200)
							{
								$("#phone_no").val(data.customer.mobile)
							}
						}
					  });
                    }
				break;

				case "Products":
					$(this).closest('tr').find('.code').text($(this).val())
					$ele4 = $(this).closest('td').parent().find('#Unit')
					$ele1 = selected.closest('td').parent().find('.price').val('')
					$ele2 = selected.closest('td').parent().find('.stock').val('')
					$ele3 = selected.closest('td').parent().find('.cost').val('')
					$ele5 = selected.closest('td').parent().find('.vat').val('')
					$ele6 = selected.closest('td').parent().find('.qty').val('')
					$ele4.find('option').remove()
					selected.selectpicker("refresh");

					if($(this).val()==0)
					{
						$("#create_item_modal").modal('show')
						selected.val('default');
						selected.selectpicker("refresh");
					}
					else
					{
					$.ajax({
						type: 'get',
						url: '{{URL::to('fetchItemUnits')}}',
						data :{ 'itemId' : $(this).val()},
						success: function (data) {
							if(data.status == 200)
							{
								$.each(data.units, function (i, item) {
								$ele4.append($('<option>', { 
								value: i,
								text : item 
								}));
								$(".selectpicker").selectpicker("refresh");
								});
							}
							else
							{
								alert("Entry not found!!")
							}	
						}
					});
				}
				break;

				case "Unit":

				$ele1 = selected.closest('td').parent().find('.price')
				$ele2 = selected.closest('td').parent().find('.stock')
				$ele3 = selected.closest('td').parent().find('.cost')
				$ele5 = selected.closest('td').parent().find('.vat')
				productId = selected.closest('td').parent().find('#Products').val()
				
					
				$.ajax({
						type: 'get',
						url: '{{URL::to('fetchItemDetails')}}',
						data :{ 'unitId' : $(this).val(),'Product':productId},
						success: function (data) {
							if(data.status == 200)
							{
								$ele1.val(data.price)
								$ele2.val(data.stock)
								$ele3.val(data.cost)
								$ele5.val(data.vat)
							}
							else
							{
								alert("Entry not found, Please input the price manually !!")
							}	
						}
					});
				
				break;


				default:
				// code block
				}


				
			});


    		$('#tab_logic tbody').on('keyup change',function(){
    			calc();
    		});

    		$('#tax').on('keyup change',function(){
    			calc_total();
    		});

			$(document).keyup(function(event) { 

				var code = event.keyCode || event.which;

				if(code == 120) { 
				
				var currentRow=$('#tab_logic tr:last');
				var selectVal= currentRow.find(".selectpicker").val(); 

				if($("#customer").val() && selectVal)
				{
					$.ajax({
						type: 'get',
						url: '{{URL::to('purchase-history')}}',
						data :{ 'customerId' : $("#customer").val(),'Item' : selectVal},
						success: function (data) {
							$("#purchase_history_table").html('')
							$("#purchase_history_table").html(data)
							$("#purchaseHistoryModal").modal('show')
						}
					});
				}
				else
				{
					toastr.error("Select a customer and an product..!");
				}
			}
			else if(code == 121) { 
				
				var currentRow=$('#tab_logic tr:last');
				var selectVal= currentRow.find(".selectpicker").val(); 
                var selectUnit = currentRow.find("#Unit").val()
              
				if(selectVal && selectUnit)
				{
					$.ajax({
						type: 'get',
						url: '{{URL::to('product-details')}}',
						data :{'Item' : selectVal, 'unit': selectUnit},
						success: function (data) {
							$("#product_detail").html('')
							$("#product_detail").html(data)
							$("#productDetailModal").modal('show')
						}
					});
				}
				else
				{
					toastr.error("Select an product..!");
				}
			}
			});

    </script>
    @endsection

