@extends('layouts.app')
@section('style')
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/flatpickr/flatpickr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/select2/select2.min.css')}}">
<!--  END CUSTOM STYLE FILE  -->
@endsection
<style type="text/css">
	#tab_logic .form-control[readonly],#tab_logic_total .form-control[readonly] {
		border: 0;
		background: transparent;
		box-shadow: none;
		padding: 0 10px;
		font-size: 15px;
	}
	.form-control{font-size: 12px !important;}
	.bootstrap-select.btn-group > .dropdown-toggle {font-size: 12px !important;}
	.list-group-item{padding:2%!important;}
	.pricesummary{margin-top: 3%;border: 1px solid black;padding:0.7%;}
	.spaceTop{margin-top: 6%;}
	.gTotal{margin-top: 5.5%;}
	.vertical-line{
        display: inline-block;
        border-left: 1px solid #ccc;
        margin: 0 10px;
        height: 40px;
    }
</style>
@section('content')
 {!! Form::open(['route' => 'saveInvoice']) !!}
<div id="content" class="main-content">
	<div class="layout-px-spacing">
		<div class="row layout-top-spacing" id="cancel-row">
			<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
				<div class="widget-content widget-content-area br-6">
					<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-5">
									<div class="form-group row mb-4 ">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input id="basicFlatpickr" value="" class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date.." name="date" required>
										</div>
									</div>
								</div>
								{{-- <div class="col-md-4">
									<div class="form-group row mb-4">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input id="basicFlatpickr" value="2019-09-04" class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date..">
										</div>
									</div>
								</div> --}}
								<div class="col-md-4">
									<div class="form-group row mb-4">
										<label for="number_2" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Cnt.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="number_2" placeholder="Number" name="number_2">
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-5">
									<div class="form-group row mb-4 ">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Customer</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											{!! Form::select('customer', $customers, old('customer'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
										</div>
									</div>
								</div>
								<div class="col-md-1">
									<div class="form-check pl-0 input-group-sm">
										<div class="custom-control custom-checkbox checkbox-info">
											<input type="checkbox" class="custom-control-input " id="gridCheck" name="any">
											<label class="custom-control-label" for="gridCheck">Any</label>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="custom-control custom-radio custom-control-inline">
										<input type="radio" id="customRadioInline1" name="cash_or_card" class="custom-control-input" value="cash" required>
										<label class="custom-control-label" for="customRadioInline1">Cash</label>
									</div>
									<div class="custom-control custom-radio custom-control-inline">
										<input type="radio" id="customRadioInline2" name="cash_or_card" class="custom-control-input" value="card" required>
										<label class="custom-control-label" for="customRadioInline2">Card</label>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="po_no" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">PO.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="po_no" placeholder="PO.No" required name="po_no">
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-5">
									<div class="form-group row mb-4">
										<label for="phone_no" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Phone.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="phone_no" placeholder="Number" name="phone_no" required>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row mb-4">
										<label for="remark" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Remark</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="remark" placeholder="Remark" name="remark">
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group row mb-4">
										<label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Del.No</label>
										<div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
											<input type="text" class="form-control" id="del_no" placeholder="Del.No" name="del_no" required>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="container-fluid">
						<div class="row clearfix">
							<div class="col-md-12 table-responsive">
								<table class="table" id="tab_logic">
									<thead>
										<tr>
											<th class="text-center"> # </th>
											<th class="text-center"> Product </th>
											<th class="text-center" style="width: 12%;"> Unit </th>
											<th class="text-center" style="width: 14%;"> Price </th>
											<th class="text-center" style="width: 12%;"> Qty </th>
											<th class="text-center" style="width: 12%;"> Stock </th>
											<th class="text-center" style="width: 12%;"> InvCost </th>
											<th class="text-center" style="width: 12%;"> Total </th>
										</tr>
									</thead>
									<tbody id="table_body">
										<tr>
											<td>1</td>
											<td>
												{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}
											</td>
											<td>
												{{-- {!! Form::select('Unit', $units, old('Unit'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'Unit','data-live-search'=>"true",'title'=>'Select Unit']) !!} --}}

												<input type="text" class="form-control unit" readonly id="unit" name="unit[]" value="">
											</td>
											<td>
												<input type="number" name='price[]' placeholder=' Unit Price' class="form-control price testing" step="0.00" min="0"/>
											</td>
											<td>
												<input type="number" name='qty[]' placeholder='Quantity' class="form-control qty" step="0" min="0"/>
											</td>
											<td>
												<input type="number" name='Stock[]' placeholder='Stock' class="form-control stock" value="0" readonly/>
											</td>
											<td>
												<input type="number" name='invCost[]' placeholder='InvCost' class="form-control cost" value="0" readonly/>
											</td>
											<td>
												<input type="number" name='total[]' placeholder='0.00' class="form-control total" readonly/>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<div class="row clearfix">
							<div class="col-md-12">
								<button id="add_row" class="btn btn-default pull-left">Add Row</button>
								<button type="button" id='delete_row' class="pull-right btn btn-default">Delete Row</button>
							</div>
						</div>

						<div class="row pricesummary">
							<div class="col-md-2">
								<div class="row">
									<div class="col-md-12"><input type="text" name="remark1" placeholder="Remark 1" class="form-control"></div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="row">
									{{-- <div class="col-md-3"><p>Discount</p></div> --}}
									<div class="col-md-12">
										<input type="number" class="form-control" name="discount" placeholder="Discount %" id="disount" />
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="row spaceTop">
									<div class="col-md-6"><p>Sub Total</p></div>
									<div class="col-md-6"><p>Rs 123</p></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-2">
								<div class="row spaceTop">
									<div class="col-md-6"><p>VAT</p></div>
									<div class="col-md-6"><p>Rs 123</p></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-2">
								<div class="row gTotal">
									<div class="col-md-4"><h6>Total</h6></div>
									<div class="col-md-8"><h6 id="total_amount">Rs 2132211</h6></div>
								</div>
							</div>
							<span class="vertical-line"></span>
							<div class="col-md-1">
								<div class="row spaceTop">
									<div class="col-md-12"><input type="submit" class="btn btn-success btn-sm" name="" value="save"></div>
								</div>
							</div>
						</div>

						{{-- <div class="row mt-4">
							<div class="col-sm-8 col-12 order-sm-0 order-1">
								<div class="inv--payment-info">

								</div>
							</div>
							<div class="col-sm-4 col-12 order-sm-0 order-1">
								<div class="inv--payment-info">
									<ul class="list-group ">
										<li class="list-group-item">
											<div class="row">
												<div class="col-md-6"><p>Sub Total</p></div>
												<div class="col-md-6"><p>Rs 123</p></div>
											</div>
										</li>
										<li class="list-group-item">
											<div class="row">
												<div class="col-md-6"><p>VAT</p></div>
												<div class="col-md-6"><p>Rs 123</p></div>
											</div>
										</li>
										<li class="list-group-item">
											<div class="row">
												<div class="col-md-6"><p>Discount</p></div>
												<div class="col-md-6">
													<input type="number" class="form-control" name="" placeholder="Discount %" id="disount" />
												</div>
											</div>
										</li>
										<li class="list-group-item">
											<div class="row">
												<div class="col-md-6"><h6>Grand Total</h6></div>
												<div class="col-md-6"><h6 id="total_amount">Rs 123</h6></div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div> --}}
{{-- <div class="col-md-4 order-sm-1 order-0 pull-right"> --}}
              {{-- <div class="inv--total-amounts text-sm"> --}}
           
{{-- </div>/ --}}
{{-- </div> --}}
            {{-- <div class="col-sm-7 col-12 order-sm-1 order-0">
              <div class="inv--total-amounts text-sm-right">
                <div class="row">
                  <div class="col-sm-8 col-7">
                    <p class="">Sub Total: </p>
                  </div>
                  <div class="col-sm-4 col-5">
                    <p class="">$13300</p>
                  </div>
                  <div class="col-sm-8 col-7">
                    <p class="">VAT Amount: </p>
                  </div>
                  <div class="col-sm-4 col-5">
                    <p class="">$700</p>
                  </div>
                  <div class="col-sm-8 col-7">
                    <p class=" discount-rate">Discount : <span class="discount-percentage"><input type="number" name=""></span> </p>
                  </div>
                  <div class="col-sm-4 col-5">
                    <p class="">$700</p>
                  </div>
                  <div class="col-sm-8 col-7 grand-total-title">
                    <h5 class="">Grand Total : </h5>
                  </div>
                  <div class="col-sm-4 col-5 grand-total-amount">
                    <h4 class="" id="total_amount"></h4>
                  </div>
                </div>
              </div>
            </div> --}}
        

  
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="counter" value="1">
<input type="hidden" id="sub_total" value="0" name="sub_total">
<input type="hidden" id="grant_total" value="0" name="grant_total">
{{ Form::close() }}


    @endsection

    @section('script')
    <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
    <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
    <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
    <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
    <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
    <!--  BEGIN CUSTOM SCRIPT FILE  -->
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('plugins/flatpickr/flatpickr.js')}}"></script>
    <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>
    <script src="{{asset('plugins/select2/select2.min.js')}}"></script>
    {{-- <script src="{{asset('plugins/select2/custom-select2.js')}}"></script> --}}	

    <script>

    	$(document).ready(function(){

    		// var f1 = flatpickr(document.getElementById('basicFlatpickr'));

				$("#basicFlatpickr").flatpickr({
					altFormat: "F j, Y",
					dateFormat: "Y-m-d",
					defaultDate: "today",
				}); 

			$("#delete_row").click(function(){
    			$('#tab_logic tr:last').remove()
    			temp = $("#counter").val()
    			$("#counter").val(--temp)
    			calc();
    		});


    		$(document).on('click', '#add_row', function(event) {
    			event.preventDefault();
    			/* Act on the event */

    			var currentRow=$('#tab_logic tr:last');
        		var totalVal= currentRow.find(".total").val(); 
        		var selectVal= currentRow.find(".selectpicker").val(); 

        		if(totalVal > 0 && selectVal)
        		{
        			temp = $("#counter").val()
    				var indexNo = $("#counter").val(++temp);

    				$("#table_body").append('<tr><td>'+$("#counter").val()+'</td><td>{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}</td><td><input type="text" class="form-control unit" readonly id="unit" name="unit[]" value=""></td><td><input type="number" name="price[]"" placeholder="Enter Unit Price" class="form-control price" step="0.00" min="0"/></td><td><input type="number" name="qty[]"" placeholder="Enter Qty" class="form-control qty" step="0" min="0"/></td><td><input type="number" name="Stock[]"" placeholder="Stock" class="form-control stock" value="0" readonly/></td><td><input type="number" name="invCost[]"" placeholder="InvCost" class="form-control cost" value="0"readonly/></td><td><input type="number" name="total[]" placeholder="0.00" class="form-control total" readonly/></td></tr>')

    				$('select').selectpicker();
        		}
        		else
        		{
        			alert("please fill up the values")
        		}

    			
    		});
    	});

    	function calc()
    	{
    		$('#tab_logic tbody tr').each(function(i, element) {
    			var html = $(this).html();

    			var qty = $(this).find('.qty').val();
    			var price = $(this).find('.price').val();
    			var stock = $(this).find('.stock').val();

    			$(this).find('.total').val(qty*price);

    			if(+qty > +stock)
    				{
    					alert("Insufficient stock")
    					$(this).find('.qty').val('')
    					$(this).find('.total').val('')
    				}

    			calc_total();
    		});
    	}

    	function calc_total()
    	{
    		total=0;
    		$('.total').each(function() {
    			total += parseInt($(this).val());
    		});

    		$("#total_amount").text("Rs "+total)
    		$("#sub_total").val(total)
    		$("#grant_total").val(total)
    		// $('#sub_total').val(total.toFixed(2));
    		// tax_sum=total/100*$('#tax').val();
    		// $('#tax_amount').val(tax_sum.toFixed(2));
    		// $('#total_amount').val((tax_sum+total).toFixed(2));
    		// $('#total_amount').html((tax_sum+total).toFixed(2));
    	}

    	$("#disount").on('keyup', function(event) {
    		/* Act on the event */

    			if($("#sub_total").val() > 0 && $(this).val().length > 0 && $(this).val() > 0)
				{
				// var discount = $(this).val()/100;
				var final = $("#sub_total").val() - ($("#sub_total").val()*$(this).val()/100);
				if(!(isNaN(final)))
				{
					$("#total_amount").text("Rs "+final)
					$("#grant_total").val(final)	
				}
				
				}
 
    		else
    		{
    			$("#total_amount").text("Rs "+$("#sub_total").val())
    			$("#grant_total").val($("#sub_total").val())
    		}
    	});

			// $(document).on('changed.bs.select', '#customer', function(event) {

			

			// });

			$(document).on('change', '.selectpicker', function(event) {
				event.preventDefault();
				/* Act on the event */
				if($(this).attr('id') == 'customer')
				{
						$.ajax({
						type: 'get',
						url: '{{URL::to('getCustomerDetails')}}', 
						data :{ 'customer_id' : $(this).val()},
						success: function (data) {
							if(data.status == 200)
							{
								$("#phone_no").val(data.customer.mobile)
							}
						}
					});
				}
				else
				{

				var selected = $(this);
				var myOption=$(this).val();

				$ele1 = $(this).closest('td').parent().find('.price')
				$ele2 = $(this).closest('td').parent().find('.stock')
				$ele3 = $(this).closest('td').parent().find('.cost')
				$ele4 = $(this).closest('td').parent().find('.unit')

				var s =0;
				$('#tab_logic tbody tr .productSelect').each(function(index, element){
					var myselect = $(this).val();
					if(myselect==myOption){
						s += 1;
					}
				});
				if(s>1){
					alert('This item as been added already, try new..') 
					selected.val('default');
					selected.selectpicker("refresh");
					$inputBox.val('')
				}

				else{
					$.ajax({
						type: 'get',
						url: '{{URL::to('getItemCost')}}',
						data :{ 'itemId' : $(this).val()},
						success: function (data) {
							if(data.status == 200)
							{
								$ele1.val(data.price)
								$ele2.val(data.stock)
								$ele3.val(data.cost)
								$ele4.val(data.unit)
							}
							else
							{
								alert("Entry not found, Please input the price manually !!")
								// $inputBox.val(0)
							}	
						}
					});
				}
				}
				
			});


    		$('#tab_logic tbody').on('keyup change',function(){
    			calc();
    		});

    		$('#tax').on('keyup change',function(){
    			calc_total();
    		});


    </script>
    @endsection

