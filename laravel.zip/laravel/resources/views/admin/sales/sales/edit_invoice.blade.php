@extends('layouts.app')
@section('style')
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/flatpickr/flatpickr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{asset('css/tables/table-basic.css')}}">
    {{-- <link href="assets/css/tables/table-basic.css" rel="stylesheet" type="text/css" /> --}}
<style type="text/css">
  .bootstrap-select.btn-group > .dropdown-toggle {font-size: 11px;}
  #tab_logic .form-control[readonly],#tab_logic_total .form-control[readonly] {
    border: 0;
    background: transparent;
    box-shadow: none;
    padding: 0 10px;
    font-size: 15px;
  }
  .form-control{font-size: 12px !important;}
  .bootstrap-select.btn-group > .dropdown-toggle {font-size: 12px !important;}
  .list-group-item{padding:2%!important;}
  .pricesummary{margin-top: 3%;border: 1px solid black;padding:0.7%;}
  .spaceTop{margin-top: 6%;}
  .gTotal{margin-top: 5.5%;}
  .vertical-line{
        display: inline-block;
        border-left: 1px solid #ccc;
        margin: 0 10px;
        height: 40px;
    }
  .removeRow{cursor: pointer;}
  .add_del{display: none;}
  .old_qty{display: none;}
  /*.unit{pointer-events: none;}*/
  .hideStock{display: none;}
</style>
<!--  END CUSTOM STYLE FILE  -->
@endsection
@section('content')
 {!! Form::open(['route' => 'update-invoice']) !!}
<div id="content" class="main-content">

  <div class="layout-px-spacing">
    <a href="{{ url('create-invoice') }}"><i style="margin-top: 15px;" data-feather="arrow-left"></i><span class="icon-name"></span></a>
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-5">
                  <div class="form-group row mb-4 ">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Invoice.No</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      {!! Form::select('invoices', $invoices, old('invoices'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'invoices_list','data-live-search'=>"true",'title'=>'Select Invoice']) !!}
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input id="basicFlatpickr" class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date.." name="date" id="date">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Cnt.No</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input type="text" class="form-control" id="cnt_no" placeholder="Phone Number" name="number_2">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-5">
                  <div class="form-group row mb-4 ">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Customer</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      {!! Form::select('customers', $customers, old('customers'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
                    </div>
                  </div>
                </div>
                <div class="col-md-1">
                  <div class="form-check pl-0 input-group-sm">
                    <div class="custom-control custom-checkbox checkbox-info">
                      <input type="checkbox" class="custom-control-input " id="gridCheck">
                      <label class="custom-control-label" for="gridCheck">Any</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="customRadioInline1" name="cash_or_card" class="custom-control-input" value="cash" required>
                    <label class="custom-control-label" for="customRadioInline1">Cash</label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="customRadioInline2" name="cash_or_card" class="custom-control-input" value="card" required>
                    <label class="custom-control-label" for="customRadioInline2">Card</label>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">PO.No</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input type="text" class="form-control" id="po_no" name="po_no" placeholder="PO.No">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Mob</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input type="text" class="form-control" id="phone_no" name
                      ="phone_no" placeholder="Phone Number">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Del.No</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input type="text" class="form-control" id="del_no" name = "del_no" placeholder="Del.No">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    {{-- <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Remark</label> --}}
                    <div class="col-md-12 input-group-sm">
                      <input type="text" class="form-control" name="remark1" id="remark1" placeholder="Remark 1">
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    {{-- <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Remark</label> --}}
                    <div class="col-md-12 input-group-sm">
                      <input type="text" class="form-control" name="remark1" id="remark2" placeholder="Remark 2">
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
          <div class="row inv--product-table-section add_del">
            <div class="col-12">
              <div class="table-responsive">
                <table class="table" id="tab_logic">
                  <thead>
                    <tr>
                      <th class="text-center"> # </th>
                      <th class="text-center"> Code </th>
                      <th class="text-center"> Product </th>
                      <th class="text-center" style="width: 16%;"> Unit </th>
                      <th class="text-center" style="width: 10%;"> Price </th>
                      <th class="text-center" style="width: 10%;"> Quantity </th>
                      <th class="text-center" style="display: none;"> Quantity </th>
                      <th class="text-center hideStock"> Stock </th>
                      <th class="text-center" style="width: 10%;"> InvCost </th>
                      <th class="text-center" style="width: 10%;"> Vat </th>
                      <th class="text-center" style="width: 12%;"> Total </th>
                    </tr>
                  </thead>        
                  <tbody id="table_body">
                   
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="row clearfix add_del">
              <div class="col-md-12">
                <button id="add_row" class="btn btn-default pull-left">Add Row</button>
                <button type="button" id='delete_row' class="pull-right btn btn-default">Delete Row</button>
              </div>
            </div>

            <div class="row pricesummary add_del">
              {{-- <div class="col-md-2">
                <div class="row">
                  <div class="col-md-12"><input type="text" name="remark2" placeholder="Remark 2" class="form-control" id="remark2"></div>
                </div>
              </div> --}}
              <div class="col-md-2">
                <div class="row">
                  {{-- <div class="col-md-3"><p>Discount</p></div> --}}
                  <div class="col-md-12">
                    <input type="number" class="form-control" name="discount" placeholder="Discount %" id="discount" />
                  </div>
                </div>
              </div>
              <div class="col-md-2">
                <div class="row spaceTop">
                  <div class="col-md-6"><p>Sub Total</p></div>
                  <div class="col-md-6"><p class="sub_total"></p></div>
                </div>
              </div>
              <span class="vertical-line"></span>
              <div class="col-md-2">
                <div class="row spaceTop">
                  <div class="col-md-6"><p>VAT</p></div>
                  <div class="col-md-6"><p id="vat_val"></p></div>
                </div>
              </div>
              <span class="vertical-line"></span>
              <div class="col-md-2">
                <div class="row gTotal">
                  <div class="col-md-4"><h6>Total</h6></div>
                  <div class="col-md-8"><h6 id="total_amount"></h6></div>
                </div>
              </div>
              <span class="vertical-line"></span>
              <div class="col-md-1">
                <div class="row spaceTop">
                  <div class="col-md-12"><input type="submit" class="btn btn-success btn-sm" name="" value="Update"></div>
                </div>
              </div>
            </div>
         {{--  <div class="row mt-4">
            <div class="col-sm-5 col-12 order-sm-0 order-1">
              <div class="inv--payment-info">
                <div class="row">
                  <div class="col-sm-12 col-12">
                    <h6 class=" inv-title">Payment Info:</h6>
                  </div>
                  <div class="col-sm-4 col-12">
                    <p class=" inv-subtitle">Bank Name: </p>
                  </div>
                  <div class="col-sm-8 col-12">
                    <p class="">Bank of America</p>
                  </div>
                  <div class="col-sm-4 col-12">
                    <p class=" inv-subtitle">Account Number : </p>
                  </div>
                  <div class="col-sm-8 col-12">
                    <p class="">1234567890</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-7 col-12 order-sm-1 order-0">
              <div class="inv--total-amounts text-sm-right">
                <div class="row">
                  <div class="col-sm-8 col-7">
                    <p class="sub_total">Sub Total: </p>
                  </div> 
                  <div class="col-sm-4 col-5">
                    <p class="sub_total_amt"></p>
                  </div> 
                  <div class="col-sm-8 col-7">
                    <p class=" discount-rate">Discount : <span class="discount-percentage"></span> </p>
                  </div>
                  <div class="col-sm-4 col-5">
                    <p class="discount_amt"></p>
                  </div>
                  <div class="col-sm-8 col-7 grand-total-title">
                    <h4 class="">Grand Total : </h4>
                  </div>
                  <div class="col-sm-4 col-5 grand-total-amount">
                    <h4 class="grant_total"></h4>
                  </div>
                </div>
              </div>
            </div>
          </div> --}}
        </div>
        </div>
        </div>
        <input type="hidden" id="counter" value="">
        <input type="hidden" id="sub_total" value="0" name="sub_total">
        <input type="hidden" id="grant_total" value="0" name="grant_total">
        <input type="hidden" id="invoice_id" name="invoice_id">

        {{ Form::close() }}

        @endsection

        @section('script')
        <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
        <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
        <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
        <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
        <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
        <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
        <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
        <!--  BEGIN CUSTOM SCRIPT FILE  -->
        <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
        <script src="{{asset('plugins/flatpickr/flatpickr.js')}}"></script>
        <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>

        <script>
          $(document).ready(function($) {
            var f1 = flatpickr(document.getElementById('basicFlatpickr'));


            $(document).on('change', '.selectpicker', function(event) {
               if($(this).attr('id')=='invoices_list')
               {

                $.ajax({
                type: 'get',
                url: '{{URL::to('editInvoiceDetails')}}',
                data :{ 'inv_id' : $(this).val()},
                  success: function (data) 
                  {
                    // console.log(data)/
                    $('#content').find("input[type=text], input[type=number]").val("");
                    $('.add_del').css('display', 'flex');
                    if(data.Invoice.any == 1)
                    {
                      $("#gridCheck").attr('checked', true);
                    }
                    else
                    {
                      $("#gridCheck").attr('checked', false);
                    }

                    if(data.Invoice.cash_or_card == "cash")
                    {
                      $("#customRadioInline1").prop('checked', true);
                    }
                    else
                    {
                      $("#customRadioInline2").prop('checked', true);
                    }
                    $("#customer").val(data.Invoice.customer_id)
                    $("#del_no").val(data.Invoice.del_no)
                    $("#po_no").val(data.Invoice.po_no)
                    $("#phone_no").val(data.Invoice.phone_no)
                    $("#basicFlatpickr").val(data.Invoice.date)
                    $("#remark1").val(data.Invoice.remark1)
                    $("#remark2").val(data.Invoice.remark2)
                    $("#cnt_no").val(data.Invoice.cnt_no)
                    $("#table_body").html(data.Table)
                    $('.discount-percentage').html(data.Invoice.discount+" %")
                    $('.grant_total').html("Rs "+data.Invoice.grant_total)
                    $('.sub_total_amt').html("Rs "+data.Invoice.sub_total)
                    $('.discount_amt').html(data.Invoice.sub_total*(data.Invoice.discount/100))
                    $('.selectpicker').selectpicker('refresh')
                    $('.sub_total').html(data.Invoice.sub_total)
                    $("#counter").val(data.Counter)
                    $("#total_amount").html(data.Invoice.grant_total)
                    $("#sub_total").val(data.Invoice.grant_total)
                    $("#grant_total").val(data.Invoice.grant_total)
                    $("#invoice_id").val(data.Invoice.id)
                    $("#date").val(data.Invoice.date)
                    $("#discount").val(data.Invoice.discount)
                    $("#vat_val").html(data.Vat)
                  }
              });
              }
            });
          });

        </script>
          <script>

      $(document).ready(function(){

        // var f1 = flatpickr(document.getElementById('basicFlatpickr'));

        $("#basicFlatpickr").flatpickr({
          altFormat: "F j, Y",
          dateFormat: "Y-m-d",
          defaultDate: "today",
        }); 

      $("#delete_row").click(function(){
        temp = $("#counter").val()
        if(temp > 1)
        {
          $('#tab_logic tr:last').remove()
          $("#counter").val(--temp)
          calc();
        }
        else{
          alert("Mininum 1 item required to bill");
        }
          
        });


        $(document).on('click', '#add_row', function(event) {
          event.preventDefault();
          /* Act on the event */

            var currentRow=$('#tab_logic tr:last');
            var totalVal= currentRow.find(".total").val(); 
            var selectVal= currentRow.find(".selectpicker").val(); 
            var rowCount = $('#tab_logic tr').length;
            // console.log(totalVal+"----"+selectVal)
            if(totalVal > 0 && selectVal || rowCount==1)
            {
              temp = $("#counter").val()
              var indexNo = $("#counter").val(++temp);

            $("#table_body").append('<tr><td>'+$("#counter").val()+'</td><td class="code">###</td><td>{!! Form::select('Products[]', $products, old('Products'),['class' => 'selectpicker form-control productSelect','required','data-size'=>"10",'id'=>'Products','data-live-search'=>"true",'title'=>'Select Products']) !!}</td><td>{!! Form::select('unit[]', $units, old('Unit'),['class' => 'selectpicker form-control unit','required','data-size'=>"10",'id'=>'Unit','data-live-search'=>"true",'title'=>'Select Unit']) !!}</td><td><input type="number" name="price[]"" placeholder="Price" class="form-control price" step="0.00" min="0"/></td><td><input type="number" name="qty[]"" placeholder="Qty" class="form-control qty" step="0" min="0"/></td><td class="old_qty"><input type="number" name="old_qty[]"" placeholder="Qty" class="form-control old_qty" value="0" /></td><td class="hideStock"><input type="number" name="Stock[]"" placeholder="Stock" class="form-control stock" value="0" readonly/></td><td><input type="number" name="invCost[]"" placeholder="InvCost" class="form-control cost" value="0"readonly/></td><td><input type="number" name="vat[]"" placeholder="0.00" class="form-control vat" readonly/></td><td><input type="number" name="total[]" placeholder="0.00" class="form-control total" readonly/></td><td class="text-center removeRow" data-flag=0><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 icon"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></td></tr>')

            $('select').selectpicker();
            }
            else
            {
              alert("please fill up the values")
            }

          
        });
      });

      function calc()
      {
        $('#tab_logic tbody tr').each(function(i, element) {
          var html = $(this).html();

          var qty = $(this).find('.qty').val();
          var price = $(this).find('.price').val();
          var stock = $(this).find('.stock').val();

          $(this).find('.total').val(qty*price);

          if(+qty > +stock)
            {
              alert("Insufficient stock")
              $(this).find('.qty').val('')
              $(this).find('.total').val('')
            }

          calc_total();
        });
      }

      function calc_total()
      {
        total=0;
        $('.total').each(function() {
          total += parseInt($(this).val());
        });

        vat = 0;
        $('.vat').each(function(index, element){
        vat += $(this).val() * parseInt($(this).closest('td').parent().find('.qty').val())
        });

        if(!(isNaN(vat)))
        {
          $("#vat_val").html("Rs "+vat)
        }
        
        $("#sub_total").val(total)
        $(".sub_total").html("Rs "+total)

        var disc = $("#discount").val();
        // console.log(disc)
        if(disc > 0)
        {
            sum = total - (total *(disc/100));
            // console.log(sum)
             $("#grant_total").val(sum)
             $("#total_amount").text("Rs "+sum)
        } 
        else{
            $("#grant_total").val(total)
            $("#total_amount").text("Rs "+total)
        }
        
        // $('#sub_total').val(total.toFixed(2));
        // tax_sum=total/100*$('#tax').val();
        // $('#tax_amount').val(tax_sum.toFixed(2));
        // $('#total_amount').val((tax_sum+total).toFixed(2));
        // $('#total_amount').html((tax_sum+total).toFixed(2));
      }

      $("#disount").on('keyup', function(event) {
        /* Act on the event */

          if($("#sub_total").val() > 0 && $(this).val().length > 0 && $(this).val() > 0)
        {
        // var discount = $(this).val()/100;
        var final = $("#sub_total").val() - ($("#sub_total").val()*$(this).val()/100);
        if(!(isNaN(final)))
        {
          $("#total_amount").text("Rs "+final)
          $("#grant_total").val(final)  
        }
        
        }
 
        else
        {
          $("#total_amount").text("Rs "+$("#sub_total").val())
          $("#grant_total").val($("#sub_total").val())
        }
      });

      // $(document).on('changed.bs.select', '#customer', function(event) {

      

      // });

      $(document).on('change', '.selectpicker', function(event) {
        event.preventDefault();
        /* Act on the event */
        var selected = $(this);
        var myOption = $(this).val();



        switch($(this).attr('id')) {
        
        case "customer":

          $.ajax({
            type: 'get',
            url: '{{URL::to('getCustomerDetails')}}', 
            data :{ 'customer_id' : $(this).val()},
            success: function (data) {
              if(data.status == 200)
              {
                $("#phone_no").val(data.customer.mobile)
              }
            }
          });

        break;

        case "Products":
          $(this).closest('tr').find('.code').text($(this).val())
          $ele4 = $(this).closest('td').parent().find('#Unit')
          $ele1 = selected.closest('td').parent().find('.price').val('')
          $ele2 = selected.closest('td').parent().find('.stock').val('')
          $ele3 = selected.closest('td').parent().find('.cost').val('')
          $ele5 = selected.closest('td').parent().find('.vat').val('')
          $ele6 = selected.closest('td').parent().find('.qty').val('')
          $ele4.find('option').remove()
          selected.selectpicker("refresh");

          if($(this).val()==0)
          {
            alert("Insert modal")
            selected.val('default');
            selected.selectpicker("refresh");
          }
          else
          {
          $.ajax({
            type: 'get',
            url: '{{URL::to('fetchItemUnits')}}',
            data :{ 'itemId' : $(this).val()},
            success: function (data) {
              if(data.status == 200)
              {
                $.each(data.units, function (i, item) {
                $ele4.append($('<option>', { 
                value: i,
                text : item 
                }));
                $(".selectpicker").selectpicker("refresh");
                });
              }
              else
              {
                alert("Entry not found!!")
              } 
            }
          });
        }
        break;

        case "Unit":

        $ele1 = selected.closest('td').parent().find('.price')
        $ele2 = selected.closest('td').parent().find('.stock')
        $ele3 = selected.closest('td').parent().find('.cost')
        $ele5 = selected.closest('td').parent().find('.vat')
        $ele6 = selected.closest('td').parent().find('.qty')
        productId = selected.closest('td').parent().find('#Products').val()
        // console.log(productId)

        // var s =0;
        // $('#tab_logic tbody tr .productSelect').each(function(index, element){
        //  var myselect = $(this).val();
        //  if(myselect==myOption){
        //    s += 1;
        //  }
        // });
        // if(s>1){
        //  alert('This item as been added already, try new..') 
        //  selected.val('default');
        //  selected.selectpicker("refresh");
        //  $inputBox.val('')
        // }

        // else{
          
        $.ajax({
            type: 'get',
            url: '{{URL::to('fetchItemDetails')}}',
            data :{ 'unitId' : $(this).val(),'Product':productId},
            success: function (data) {
              if(data.status == 200)
              {
                $ele1.val(data.price)
                $ele2.val(data.stock)
                $ele3.val(data.cost)
                $ele5.val(data.vat)
              }
              else
              {
                alert("Entry not found, Please input the price manually !!")
              } 
            }
          });
          // }
        
        break;


        default:
        // code block
        }


        
      });



        $('#tab_logic tbody').on('keyup change',function(){
          calc();
        });

        $('#tax').on('keyup change',function(){
          calc_total();
        });

        $(document).on('click', '.removeRow', function(event) {
          event.preventDefault();
          /* Act on the event */
          
          row = $(this).parent()
          console.log($(this).parent());
          resp = confirm("Click OK to remove this row");

          if(resp)
          {
            if(row.find('.removeRow').data('flag'))
            {
            $.ajax({
                      type: 'get',
                      url: '{{URL::to('removeItem')}}',
                      data :{ 
                            'itemId' : row.find('.removeRow').data('item'),
                            'unit' : row.find('.removeRow').data('unit'),
                            'qty' : row.find('.removeRow').data('qty'),
                            },
                        success: function (data) {
                        

                      }
                    });
             }
              row.remove()
              $('td:first-child').each(function(i,v) {
                $(this).text(++i);
                $("#counter").val(i)
              });
          }

          // var rowCount = $('#tab_logic tr').length;
          // console.log(rowCount)
          // if(rowCount == 1)
          // {
          //   $('.add_del').css('display', 'none');
          // }
        });

    </script>
        @endsection

