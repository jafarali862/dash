@extends('layouts.app')
@section('style')
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('plugins/flatpickr/flatpickr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bootstrap-select/bootstrap-select.min.css')}}">

<style type="text/css">
  .bootstrap-select.btn-group > .dropdown-toggle {font-size: 11px;}
  .disc{display: none;}
  .removeRow{cursor: pointer;}
  ._showHide{display: none;}
  .show{display: none;}
</style>
<!--  END CUSTOM STYLE FILE  -->
@endsection
@section('content')

<div id="content" class="main-content">

  <div class="layout-px-spacing">
   <div class="show">
    <div class="row">
      <div class="col-2">
         <a href="{{ url('create-damage') }}"><i style="margin-top: 15px;" data-feather="arrow-left"></i><span class="icon-name"></span></a>
      </div>
      <div class="col-2">
      </div>
       <div class="col-1"><br>
       </div>
       <div class="col-2"><br>
        <div class="custom-control custom-checkbox checkbox-info">
            <input type="checkbox" class="custom-control-input " id="gridCheck" name="any">
            <label class="custom-control-label" for="gridCheck">Preview print</label>
        </div>
      </div>
      <div class="col-2"><br>
        <div class="custom-control custom-checkbox checkbox-info1">
            <input type="checkbox" class="custom-control-input " id="gridCheck1" name="">
            <label class="custom-control-label" for="gridCheck1">Print Arabic</label>
        </div>
      </div>
      
       <div class="col-3"><br>
         
          <input type="hidden" value="" id="damage_id" name="damage_id">
          <button  class="btn btn-danger mb-2 btnDelete">Delete</button>
          <button  class="btn btn-warning mb-2">Print</button>
          <a class="btn btn-dark mb-2" href="{{ url('create-damage') }}">Cancel</a>
      </div>
    </div>
  </div>
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-5">
                  <div class="form-group row mb-4 ">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Damage.No</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      {!! Form::select('damages', $damages, old('damages'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'damages','data-live-search'=>"true",'title'=>'Select Damage']) !!}
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Date</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input id="basicFlatpickr" class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date..">
                    </div>
                  </div>
                </div>
      
                <div class="col-md-3">
                  <div class="form-group row mb-4">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Remark</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      <input type="text" class="form-control" id="remark" placeholder="Remark">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-5">
                  <div class="form-group row mb-4 ">
                    <label for="hEmail" class="col-xl-2 col-sm-3 col-sm-2 col-form-label">Customer</label>
                    <div class="col-xl-10 col-lg-9 col-sm-10 input-group-sm">
                      {!! Form::select('customers', $customers, old('customers'),['class' => 'selectpicker form-control','required','data-size'=>"10",'id'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
                    </div>
                  </div>
                </div>
                <div class="col-md-1">
                  <div class="form-check pl-0 input-group-sm">
                    <div class="custom-control custom-checkbox checkbox-info">
                      <input type="checkbox" class="custom-control-input " id="gridCheck">
                      <label class="custom-control-label" for="gridCheck">Any</label>
                    </div>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
          <div class="row inv--product-table-section _showHide">
            <div class="col-12">
              <div class="table-responsive">
                <table class="table">
                  <thead class="">
                    <tr>
                      <th scope="col"> # </th>
                      <th scope="col"> Product </th>
                      <th class="text-right"> Unit </th>
                      <th class="text-right"> Price </th>
                      <th class="text-right"> Qty </th>
                      <th class="text-right"> Stock </th>
                      <th class="text-right"> InvCost </th>
                      <th class="text-right"> Total </th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody id="tbody">
                   
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="row mt-4 _showHide">
            <div class="col-sm-7 col-12 order-sm-1 order-0">
              <div class="inv--total-amounts text-sm-right">
                <div class="row">
                  <div class="col-sm-8 col-7">
                    <p class="sub_total">Sub Total: </p>
                  </div> 
                  <div class="col-sm-4 col-5">
                    <p class="sub_total_amt"></p>
                  </div> 
                  {{-- <div class="col-sm-8 col-7">
                    <p class="">Tax Amount: </p>
                  </div>
                  <div class="col-sm-4 col-5">
                    <p class="">$700</p>
                  </div> --}}
                  <div class="col-sm-8 col-7 disc">
                    <p class=" discount-rate">Discount : <span class="discount-percentage"></span> </p>
                  </div>
                  <div class="col-sm-4 col-5 disc">
                    <p class="discount_amt"></p>
                  </div>
                  <div class="col-sm-8 col-7 grand-total-title">
                    <h4 class="">Grand Total : </h4>
                  </div>
                  <div class="col-sm-4 col-5 grand-total-amount">
                    <h4 class="grant_total"></h4>
                  </div>
                </div>
              </div>
            </div>
         
          </div>

        </div>
        </div>
        </div>

        @endsection

        @section('script')
        <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
        <script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
        <!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
        <script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
        <script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
        <script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
        <script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
        <!--  BEGIN CUSTOM SCRIPT FILE  -->
        <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
        <script src="{{asset('plugins/flatpickr/flatpickr.js')}}"></script>
        <script src="{{asset('plugins/bootstrap-select/bootstrap-select.min.js')}}"></script>

        <script>
          $(document).ready(function($) {
            var f1 = flatpickr(document.getElementById('basicFlatpickr'));


            $(document).on('change', '.selectpicker', function(event) {
               
                $.ajax({
                type: 'get',
                url: '{{URL::to('getDamageDetails')}}',
                data :{ 'inv_id' : $(this).val()},
                  success: function (data) 
                  {
                    console.log(data)
                    $("._showHide").css('display', 'block');
                    $(".show").css('display', 'block');
                    // $('#content').find('input:text').val('');
                    // $('#content').find('input:number').val('');
                    $('#content').find("input[type=text], input[type=number]").val("");

                    if(data.Damage.any == 1)
                    {
                      $("#gridCheck").attr('checked', true);
                    }
                    else
                    {
                      $("#gridCheck").attr('checked', false);
                    }

                    
                    $("#customer").val(data.Damage.customer_id)
                    $("#damage_id").val(data.Damage.id)
                    $("#basicFlatpickr").val(data.Damage.date)
                    $("#remark").val(data.Damage.remark1)
                    $("#tbody").html(data.Table)
                    if(data.Damage.discount > 0)
                    {
                      $(".disc").css('display', 'block');
                    }
                    $('.discount-percentage').html(data.Damage.discount+" %")
                    $('.grant_total').html("Rs "+data.Damage.grant_total)
                    $('.sub_total_amt').html("Rs "+data.Damage.sub_total)
                    $('.discount_amt').html(data.Damage.sub_total*(data.Damage.discount/100))
                    $('.selectpicker').selectpicker('refresh')
                  }
              });

            });

            $(document).on('click', '.removeRow', function(event) {
          event.preventDefault();
          /* Act on the event */
          
          row = $(this).parent()
          console.log($(this).parent());
          resp = confirm("Click OK to remove this row");

          if(resp)
          {
            if(row.find('.removeRow').data('flag'))
            {
            $.ajax({
                      type: 'get',
                      url: '{{URL::to('removeItem')}}',
                      data :{ 
                            'itemId' : row.find('.removeRow').data('item'),
                            'unit' : row.find('.removeRow').data('unit'),
                            'qty' : row.find('.removeRow').data('qty'),
                            },
                        success: function (data) {
                        

                      }
                    });
             }
              row.remove()
              $('td:first-child').each(function(i,v) {
                $(this).text(++i);
                $("#counter").val(i)
              });
          }

          // var rowCount = $('#tab_logic tr').length;
          // console.log(rowCount)
          // if(rowCount == 1)
          // {
          //   $('.add_del').css('display', 'none');
          // }
        });

          });
      $(document).on('click', '.btnDelete', function () {
       if(confirm('Do you Want To Delete ?'))             
        { 
      var damage_id = $("#damage_id").val();
      $.ajaxSetup({ 
              headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
        });
      $.ajax(
          {  
              url: '{!! route('deleteDamage') !!}',
              type: 'POST',
              data:{ id:damage_id },
              dataType: 'JSON',
              success: function (result) 
              { 
                    if(result=="deleted")
                    {
                      location.reload(); 
                      toastr.success("Damage deleted sucessfully..!");            
                    }              
              },
              error:function(result)
              {
                console.log("It failed"+JSON.stringify(result));  
              }
            });

        }
        else
          {

              return;
          }
        });
        </script>
        @endsection

