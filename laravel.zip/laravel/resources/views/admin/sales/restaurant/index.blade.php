<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
   <title>Restaurant | Sales</title>
   <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
   <!-- BEGIN GLOBAL MANDATORY STYLES -->
   <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
   <link href="{{asset('restaurant/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
   <!-- 
    <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" /> -->
   <link rel="stylesheet" href="{{asset('restaurant/font-awesome-4.7.0/css/font-awesome.min.css')}}">
   <!-- END GLOBAL MANDATORY STYLES -->

   <!-- BEGIN PAGE LEVEL PLUGINS -->
   <link href="{{asset('restaurant/plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
   <!-- END PAGE LEVEL PLUGINS -->

   <!--  BEGIN CUSTOM STYLE FILE  -->
   <link href="{{asset('restaurant/assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
   <link href="{{asset('restaurant/assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
   <link href="{{asset('restaurant/retcss.css')}}" rel="stylesheet" type="text/css" />
   <!-- END GLOBAL MANDATORY STYLES -->
   <link rel="stylesheet" type="text/css" href="{{asset('restaurant/plugins/select2/select2.min.css')}}">

   <link href="{{asset('restaurant/assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
   {{ Html::style('plugins/toastr/toastr.min.css') }}
   <!--  END CUSTOM STYLE FILE  -->
</head>

<body class="sidebar-noneoverflow" data-spy="scroll" data-target="#navSection" data-offset="100">

   <!--  BEGIN NAVBAR  -->

   <!--  END NAVBAR  -->

   <!--  BEGIN MAIN CONTAINER  -->
   <div class="main-container" id="container">

      <div class="overlay"></div>
      <div class="search-overlay"></div>

      <!--  BEGIN TOPBAR  -->

      <!--  END TOPBAR  -->
      <!--  END TOPBAR  -->

      <!--  BEGIN CONTENT AREA  -->
      <div id="content" class="main-content">
         <section class="sales">
            <div class="fluid">
               <div class="container-xs">
                  <div class="row">
                     <div class="col-md-4">
                        <div class="row section1">
                           <div class="col-md-12">
                              <div class="item-button section1btn">
                                 <button id="table-selection-btn" class="btn btn-primary mb-2">Table Selection</button>
                                 <button id="table-release-btn" class="btn btn-primary mb-2">Table Release</button>
                                 <button id="addons-btn" class="btn btn-primary mb-2" data-toggle="modal" data-target="#loadAddonsModel">Addons</button>
                              </div>
                           </div>
                           <div class="col-lg-12">
                              <form>
                                 <div class="form-row">
                                    <div class="form-group col-md-3">
                                       <label for="date">Date</label>
                                       <input type="date" class="form-control" id="date" name="date" value="<?= date('Y-m-d', time()); ?>">
                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="inv">INV</label>
                                       <input type="text" class="form-control" id="inv" name="inv" placeholder="" value="{{$invoiceId}}" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="token">Token</label>
                                       <input type="text" class="form-control" id="token" name="token" placeholder="0.00" onkeydown="getItemsByBarCode(this)" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)" value={{ $tokenId[0] }}>
                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="barcode">Barcode</label>
                                       <input type="text" class="form-control barcode" id="barcode" name="barcode" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <div class="form-group col-md-4">
                                       <label for="customer">Customer</label>
                                          {!! Form::select('customer', $customers, old('customer'),['class' => 'form-control select2','data-size'=>"10",'id'=>'customer','name'=>'customer','data-live-search'=>"true",'title'=>'Select Customer']) !!}
                                        
                                    </div>
                                    <div class="form-group col-md-4">
                                       <label for="tel">Telphone</label>
                                       <input type="phone" class="form-control" id="phone_no" name="phone" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <div class="form-group col-md-4">
                                       <label for="barcode">Address</label>
                                       <input type="text" class="form-control" id="address" name="address">
                                    </div>
                                 </div>
                              </form>
                           </div>
                           <div class="col-md-6">
                              <form>
                                 <div class="form-group row billinfo ">
                                    <!--<div class="col-sm-2"></div>-->
                                    <label for="invst" class="col-sm-6">Invoice Status</label>
                                    <div class="col-sm-6">
                                       <input type="text" class="form-control" id="invst" name="invst">
                                    </div>

                                 </div>

                              </form>
                           </div>
                           <div class="col-md-6">
                              <form>
                                 <div class="form-group row billinfo mt-2">
                                    <!--<div class="col-sm-2"></div>-->
                                    <label for="uname" class="col-sm-6">User Name</label>
                                    <label class="text-danger" for="uname" class="col-sm-6">{{Auth::user()->name}}</label>
                                 </div>

                              </form>
                           </div>

                           <div class="col-lg-12">
                              <div class="table-wrapper">
                                 <table class="table" id="invoice-details-table">
                                    <thead>
                                       <tr>
                                          <th scope="col">ID</th>
                                          <th scope="col">Name</th>
                                          <th scope="col">Unit</th>
                                          <th scope="col">Quanity</th>
                                          <th scope="col">Rate</th>
                                          <th scope="col">Total</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       <tr>
                                          <th></th>
                                          <td></td>
                                          <td></td>
                                          <td></td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="container-cal">
                                 <div class="tastierino">
                                    <div class="tasti">
                                       <div class="num num1"><input type="button" value="1" onclick="print(this)" class="cal-but"> </div>
                                       <div class="num num2"><input type="button" value="2" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num3"><input type="button" value="3" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num4"><input type="button" value="4" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num5"><input type="button" value="5" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num6"><input type="button" value="6" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num7"><input type="button" value="7" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num8"><input type="button" value="8" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num9"><input type="button" value="9" onclick="print(this)" class="cal-but"></div><br>
                                       <div class="num num9"><input type="button" value="." onclick="print(this)" class="cal-but"></div>
                                       <div class="num num0"><input type="button" value="0" onclick="print(this)" class="cal-but"></div>
                                       <div class="num num9"><input type="button" value="C" id="del" class="cal-but" onclick="deleteLast()"> </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <form>
                                 <div class="form-group row">
                                    <!--<div class="col-sm-2"></div>-->
                                    <label for="total" class="col-sm-6 col-form-label">Total</label>
                                    <div class=" val col-sm-6 ">
                                       <input type="text" class="form-control" id="total" name="total" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <!--</div>-->
                                    <!--<div class="form-group row">-->
                                    <!--   <div class="col-sm-2"></div>-->
                                    <label for="discount" class="col-sm-6 col-form-label">Dis</label>
                                    <div class=" val col-sm-6 ">
                                       <input type="text" class="form-control" id="discount" name="discount" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <!--</div>-->

                                    <!--<div class="form-group row">-->
                                    <!--   <div class="col-sm-2"></div>-->
                                    <label for="vat" class="col-sm-6 col-form-label">Vat</label>
                                    <div class=" val col-sm-6 ">
                                       <input type="text" class="form-control" id="vat" name="vat" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                    <!--</div>-->
                                    <!--<div class="form-group row">-->
                                    <!--   <div class="col-sm-2"></div>-->
                                    <label for="netamount" class="col-sm-6 col-form-label">GR. Amount</label>
                                    <div class=" val col-sm-6 ">
                                       <input type="text" class="form-control" id="grandamount" name="grandamount" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)">
                                    </div>
                                 </div>

                              </form>
                           </div>
                           <div class="row last">
                              <div class="col-lg-12">
                                 <div class="item-button">
                                    <button class="btn btn-primary mb-2"> Hold</button>
                                    <button class="btn btn-primary mb-2"> Cancel Bill</button>
                                    <button class="btn btn-primary mb-2 close-sales"> Close Sales</button>
                                    <button class="btn btn-primary mb-2" data-toggle="modal" data-target="#exampleModal1"> Pay</button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-8">
                        <div class="row">
                           <div class="category col-md-12">
                              <div class="heading-text">
                                 <h5>Category</h5>
                              </div>
                              <div class="category-wrapper">
                                 <div class="item-button">
                                    @forelse($categories as $category)
                                    <button class="btn btn-success mb-2" id="catgeory{{$category->id}}">{{ $category->english_description }}</button>
                                    @empty
                                    <h5>No categories found</h5>
                                    @endforelse
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="items col-md-12">
                           <div class="heading-text">
                              <h5>Items</h5>
                           </div>
                           <div class="item-wrapper">
                              <div class="item-button">
                                 <div id="loaded-items">

                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-12">
                           <div class="item-button end">

                              <button class="btn btn-primary mb-2"> Item</button>
                              <button class="btn btn-secondary mb-2"> Report</button>
                              <button class="btn btn-info mb-2"> Print</button>
                              <button class="btn btn-success mb-2"> Update</button>
                              <button class="btn btn-danger mb-2">Delete</button>
                           </div>
                        </div>
                         <!--- Addons-->
                         <div>
                           <!-- Modal -->
                           <div class="modal fade" id="loadAddonsModel" tabindex="-1" role="dialog" aria-labelledby="loadAddonsModel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">Select AddOns</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <i class="fa fa-times" aria-hidden="true"></i>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <div id="addon-load-buttons">
                                          
                                       </div>
                                    </div>
                                    <div class="modal-footer">

                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <!--- Table selection modal-->
                        <div>
                           <!-- Modal -->
                           <div class="modal fade" id="loadTableSelectionModel" tabindex="-1" role="dialog" aria-labelledby="loadTableSelectionModel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">Reserve Table</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <i class="fa fa-times" aria-hidden="true"></i>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <div id="table-selection-load-buttons">
                                         @foreach($tables as $table)
                                         @if($table->booked == 'booked')
                                         
                                          <button disabled="" style="background-color: darkorange;" class="btn tableselection" value="{{ $table->id }}">{{ $table->table_name }}(R)</button>&nbsp;&nbsp;
                                         
                                         @else
                                           <button class="btn tableselection" value="{{ $table->id }}">{{ $table->table_name}}</button>&nbsp;&nbsp;
                                         @endif
                                         @endforeach
                                       </div>
                                    </div>
                                    <div class="modal-footer">

                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <!--- Table Release modal-->
                        <div>
                           <!-- Modal -->
                           <div class="modal fade" id="loadTableReleaseModel" tabindex="-1" role="dialog" aria-labelledby="loadTableReleaseModel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">Release Table</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <i class="fa fa-times" aria-hidden="true"></i>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <div id="table-release-load-buttons">
                                         @foreach($tables as $table)
                                         @if($table->booked == 'booked')
                                          <button  style="background-color: darkorange;" class="btn tablerelease" value="{{ $table->id }}">{{ $table->table_name }}(R)</button>&nbsp;&nbsp;
                                         
                                         @else
                                           <button disabled="" class="btn tablerelease" value="{{ $table->id }}">{{ $table->table_name}}</button>&nbsp;&nbsp;
                                         @endif
                                         @endforeach
                                       </div>
                                    </div>
                                    <div class="modal-footer">

                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-----cash-->

                  <div>
                     <!-- Modal -->
                     <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel"></h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                 </button>
                              </div>
                              <div class="modal-body ">
                                 <form>
                                    <div class="row">
                                       <div class="col-md-9 modaltype">
                                          <table class="pop-type">
                                             <tr>
                                                <th class="lastpop"><span>Type:</span></th>
                                                <td>
                                                   <span>
                                                      <div class="n-chk">
                                                         <label class="radio-inline">
                                                            <input type="radio" name="optradiop" checked class="new-control-input modaltypef">Cash
                                                         </label>
                                                         <label class="radio-inline">
                                                            <input type="radio" name="optradiop" class="new-control-input modaltypef">Card
                                                         </label>
                                                         <label class="radio-inline">
                                                            <input type="radio" name="optradiop" class="new-control-input modaltypef">Credit
                                                         </label>

                                                      </div>
                                                   </span>
                                                </td>
                                             </tr>
                                             <tr>
                                                <th class="lastpop"><span>OrderType:</span></th>
                                                <td>
                                                   <span>
                                                      <div class="n-chk">
                                                         @foreach($ordertypes as $ordertype)
                                                         <label class="radio-inline">
                                                            <input type="radio" name="optradio" class="new-control-input modaltypef">{{ $ordertype->order_type }}
                                                         </label>
                                                         @endforeach
                                                      </div>
                                                   </span>
                                                </td>
                                             </tr>

                                          </table>
                                       </div>
                                    </div>


                                    <div class="row">
                                       <div class="col-md-7  modalpay hide">
                                          <table>
                                             <tr>
                                                <th class="lastpop"><span>Customer</span></th>
                                                <td><span><input type="text" class="form-control" id="cash" name="cash" placeholder="Cash"></span></td>
                                             </tr>
                                             <tr>
                                                <th class="lastpop-size"><span>Grand Total</span></th>
                                                <td><span><input type="text" class="form-control lastpop-fsize" id="grandtotal" name="grandtotal" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></span></td>
                                             </tr>
                                             <tr>
                                                <th class="lastpop"><span>Amt paid on acc</span></th>
                                                <td><span><input type="text" class="form-control" id="accpaid" name="accpaid" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></span></td>
                                             </tr>
                                             <tr>
                                                <th class="lastpop-size"><span>Balance</span></th>
                                                <td><span><input type="text" class="form-control lastpop-fsize" id="balance" name="balance" placeholder="0.00" onkeypress="return isNumber(event)" onclick="setCurrentTextBox(this)"></span></td>
                                             </tr>
                                          </table>
                                       </div>
                                       <div class="col-md-5 caltext">
                                          <div class="container-cal pop">
                                             <div class="tastierino pop" id="temp">
                                                <div class="tastipop sq-price" id="tastipop">
                                                   <div class="numpop num1"><input type="button" value="1" onclick="print(this)" class="cal-butpop"> </div>
                                                   <div class="numpop num2"><input type="button" value="2" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num3"><input type="button" value="3" onclick="print(this)" class="cal-butpop"></div><br>
                                                   <div class="numpop num4"><input type="button" value="4" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num5"><input type="button" value="5" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num6"><input type="button" value="6" onclick="print(this)" class="cal-butpop"></div><br>
                                                   <div class="numpop num7"><input type="button" value="7" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num8"><input type="button" value="8" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num9"><input type="button" value="9" onclick="print(this)" class="cal-butpop"></div><br>
                                                   <div class="numpop num9"><input type="button" value="." onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num0"><input type="button" value="0" onclick="print(this)" class="cal-butpop"></div>
                                                   <div class="numpop num9"><input type="button" value="C" id="del" class="cal-butpop" onclick="deleteLast()"> </div>


                                                </div>
                                             </div>
                                             <div class="tastierinop pop">
                                                <div id="calculatorDiv" style="display:none;">
                                                   <input type="text" class="caltext form-control " id="result" onkeypress="return isNumberOrSymbol(event)">
                                                   <div class="numpopc num1"><input type="button" value="1" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num2"><input type="button" value="2" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num3"><input type="button" value="3" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num3"><input type="button" value="+" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num4"><input type="button" value="4" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num5"><input type="button" value="5" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num6"><input type="button" value="6" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num3"><input type="button" value="-" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num7"><input type="button" value="7" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num8"><input type="button" value="8" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num9"><input type="button" value="9" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num3"><input type="button" value="*" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num9"><input type="button" value="." class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num0"><input type="button" value="0" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopc num9"><input type="button" value="C" id="del" class="cal-butpopc" onclick="backdel()"></div>
                                                   <div class="numpopc num3"><input type="button" value="/" class="cal-butpopc" onclick="calculatorFunction(this)"></div>
                                                   <div class="numpopeql num3"><input type="button" value="=" class="cal-butpopeql" onclick="calculateResult()"></div>
                                                </div>


                                             </div>
                                          </div>

                                          <input type="button" id="myButton1" value="Calcu" class="numpopcalc num3" onclick="change();toggleFunction();">
                                          <button type="reset" class="numpopcalc num4">Clear</button>
                                          <button type="button" class="numpopcalc" data-dismiss="modal" aria-label="Close">
                                             <i class="fa fa-times" aria-hidden="true"></i>
                                          </button>
                                       </div>
                                    </div>

                                 </form>
                              </div>
                              <div class="modal-footer">

                                 <button type="button" class="btn btn-primary">Save</button>
                                 <button type="button" class="btn btn-primary">Counter Print</button>
                                 <button type="button" class="btn btn-primary">Counter +KOT Print</button>


                              </div>
                           </div>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
      </div>
   </div>
   </div>
   </div>
   </section>




   <!-- BEGIN GLOBAL MANDATORY STYLES -->
   
   <script src="{{asset('restaurant/assets/js/libs/jquery-3.1.1.min.js')}}"></script>
   <script src="{{asset('restaurant/bootstrap/js/popper.min.js')}}"></script>
   <script src="{{asset('restaurant/bootstrap/js/bootstrap.min.js')}}"></script>
   <script src="{{asset('restaurant/plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
   <script src="{{asset('restaurant/assets/js/app.js')}}"></script>
   {{ Html::script('plugins/toastr/toastr.min.js')}}

   <script>
      function change() // no ';' here
      {
         var elem = document.getElementById("myButton1");
         if (elem.value == "Back") elem.value = "Calcu";
         else elem.value = "Back";
      }

      $(document).ready(function() {
         App.init();
           $('.select2').select2();
      });
   </script>

   <script src="{{asset('restaurant/plugins/highlight/highlight.pack.js')}}"></script>
   <script src="{{asset('restaurant/assets/js/custom.js')}}"></script>
   <!-- END GLOBAL MANDATORY STYLES -->

   <!--  BEGIN CUSTOM SCRIPT FILE  -->
   <script src="{{asset('assets/js/scrollspyNav.js')}}"></script>
   <script type="text/javascript">
      var formSmall = $(".form-small").select2({
         tags: true
      });
      formSmall.data('select2').$container.addClass('form-control-sm')
   </script>
   <script src="{{asset('restaurant/bootstrap/js/popper.min.js')}}"></script>
   <script src="{{asset('restaurant/bootstrap/js/bootstrap.min.js')}}"></script>
   <script>
      $(document).ready(function() {
         App.init();
      });
   </script>
   <script src="{{asset('restaurant/assets/js/custom.js')}}"></script>
   <!-- END GLOBAL MANDATORY SCRIPTS -->
   <!--  BEGIN CUSTOM SCRIPTS FILE  -->
   <script src="{{asset('restaurant/plugins/select2/select2.min.js')}}"></script>
   <script src="{{asset('restaurant/plugins/select2/custom-select2.js')}}"></script>
   <!--  END CUSTOM SCRIPT FILE  -->

   <script>
      $(document).ready(function() {
         deleteCookie('item_id');
         // php loop inside script
         <?php
         if (!$categories->isEmpty()) {
            foreach ($categories as $items) { ?>
               // deleting values from coolie
               deleteCookie('item_id');

               $('#catgeory<?php echo $items->id; ?>').click(function() {
                  loadItems(<?php echo $items->id; ?>);
               });

         <?php }
         } ?>

      $(document).on('change', '.select2', function(event) {
            $.ajax({
                  type: 'get',
                  url: '{{URL::to('getCustomerDetails')}}', 
                  data :{ 'customer_id' : $(this).val()},
                  success: function (data) {
                     if(data.status == 200)
                     {
                        $("#phone_no").val(data.customer.mobile)
                        $("#address").val(data.customer.english_addrs)
                     }
                  }
                 });
         });

// load items function
         function loadItems(category_id) {
            var params = {
               '_token': '{{ csrf_token() }}',
               'category_id': category_id,
            };

            $.ajax({
               url: '{{ url('loadItems') }}',
               method: 'POST',
               //dataType: 'json',
               data: params,
               error: function() {
                  window.location.reload(true);
               },
               success: function(data) {
                  if (data) {
                     $('#loaded-items').html('');
                     var data = JSON.parse(data)
                     var itemdetails = data['loadeditems'];
                     var array = [];
                     // passing the value to html
                     $.each(data, function(k, v) {
                        array.push(v['id']);
                        $('#loaded-items').append('<button id="item' + v['id'] + '" class="btn btn-warning mr-2">' + v['english_description'] + '</button>');
                     });
                     generateClickEventsForItems(array);
                  } else {
                     $('#loaded-items').html('<p class="text-primary">No items found</p>');
                  }
               }
            });
         }

        $('.close-sales').click(function() {
         var r=confirm('Do you want to close ?.if not saved data will lost');
         if(r == true)
           {
            window.location='/';
           }
        });
         function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
         }

         function generateClickEventsForItems(item_ids) {
            $.each(item_ids, function(k, v) {
               document.getElementById('item' + v).addEventListener('click', function() {
                  selectItem(v);
                  setCookie("item_id", v, 1);
               }, false);
            });
         }

         function deleteCookie(cname) {
            document.cookie = cname +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
         }

         function getCookie(cname) {
            var name = cname + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
               var c = ca[i];
               while (c.charAt(0) == ' ') {
                  c = c.substring(1);
               }
               if (c.indexOf(name) == 0) {
                  return c.substring(name.length, c.length);
               }
            }
            return "";
         }

      // get item by scan barcode
      $(document).keyup(function(event) { 

            var code = event.keyCode || event.which;

            if(code == 13){
               var barcode = document.getElementById("barcode").value;
               if(barcode != '')
               {
                   var params = {
                      '_token': '{{ csrf_token() }}',
                      'barcode': barcode,
                   };

                  $.ajax({
                     url: '{{ url('getItemDetailsByBarcode') }}',
                     method: 'POST',
                     //dataType: 'json',
                     data: params,
                     error: function() {
                     console.log('error', params);
                     // window.location.reload(true);
                     },
                    success: function(data) {
                     if (data) {
         
                       var data = JSON.parse(data)
                       if(data.details['id'])
                       {
                         addInvoiceItemRow(data.details['id'], data.details['english_description'],data.unit['short_description'],'',data.unit['price']);
                         document.getElementById('barcode').value = data.details['barcode'];
                       }else{
                        toastr.error("No items releated to this barcode found..!");
                       }
                       
                     }
                   }   
                 });
               }else{
                  toastr.error("Please scan a product..!");
               }
            }
         });
      
      // get products by select items
         function selectItem(item_id) {
            var params = {
               '_token': '{{ csrf_token() }}',
               'item_id': item_id,
            };

            $.ajax({
               url: '{{ url('getItemDetails ') }}',
               method: 'POST',
               //dataType: 'json',
               data: params,
               error: function() {
                  console.log('error', params);
                  // window.location.reload(true);
               },
               success: function(data) {
                  if (data) {
         
                     var data = JSON.parse(data)
                     if(data.details['id'])
                     {
                        addInvoiceItemRow(data.details['id'], data.details['english_description'],data.unit['short_description'],'',data.unit['price']);
                        document.getElementById('barcode').value = data.details['barcode'];
                     }else{
                        toastr.error("No items releated to this barcode found..!");
                     }
                  }
               }
            });
         }

         $('#addons-btn').click(function() {
            $('#loadAddonsModel').modal('show');
            $('#loadAddonsModel').find('#addon-load-buttons').html('');
            var item_id = getCookie("item_id");
            if(!item_id)
            {
               $('#loadAddonsModel').find('#addon-load-buttons').append('<p class="text-warning">Please select an Item first</p>');
            }
            else{
               var addons = loadAddons(item_id);
               // passing the value to html
               var data = JSON.parse(addons)
               if(data.length > 0)
               {
                  $.each(data, function(k, v) {
                  $('#loadAddonsModel').find('#addon-load-buttons').append('<button id="item' + v['id'] + '" class="btn btn-warning mr-2">' + v['add_on_name'] + '</button>');
                  });
               }
               else{
                  $('#loadAddonsModel').find('#addon-load-buttons').append('<p class="text-warning">No addons found for this Item</p>');
               }
            }
         });

         $('#table-selection-btn').click(function() {
            $('#loadTableSelectionModel').modal('show');
         });
          $('#table-release-btn').click(function() {
            $('#loadTableReleaseModel').modal('show');
         });

         function loadAddons(item_id) {
            var params = {
               '_token': '{{ csrf_token() }}',
               'item_id': item_id,
            };

            var addons  = $.ajax({
                        url: '{{ url('getItemAddons') }}',
                        method: 'POST',
                        async: false,
                        data: params,
                        success: function (data) {
                        // nothing needed here
                        }
               }) .responseText ;
            return addons;
         }

// Booking table code

         $(".tableselection").click(function() {
             var params = {
               '_token': '{{ csrf_token() }}',
               'table_id': $(this).val(),
               'value': 'booked',
            };
            $.ajax({
                        url: '{{ url('bookTable') }}',
                        method: 'POST',
                        async: false,
                        data: params,
                        success: function (data) {
                        $('#loadTableSelectionModel').find('#table-selection-load-buttons').html(data.Table);
                        toastr.success("Table Reserved..!");
                        tableRelease(data.single_table_id);
                        }
              })
         });
         function table_book(table_id)
         {
            var params = {
               '_token': '{{ csrf_token() }}',
               'table_id': table_id,
               'value' : null,
            };
            $.ajax({
                        url: '{{ url('bookTable') }}',
                        method: 'POST',
                        async: false,
                        data: params,
                        success: function (data) {
                        $('#loadTableSelectionModel').find('#table-selection-load-buttons').html(data.Table);
                        }
              })
         }
// ends

//Release table code

$(".tablerelease").click(function() {
             var params = {
               '_token': '{{ csrf_token() }}',
               'table_id': $(this).val(),
            };
            $.ajax({
                        url: '{{ url('releaseTable') }}',
                        method: 'POST',
                        async: false,
                        data: params,
                        success: function (data) {
                        $('#loadTableReleaseModel').find('#table-release-load-buttons').html(data.Table);
                        toastr.success("Table Released..!");
                        table_book(data.table_id);
                        }
              })
         });

function tableRelease (table_id)
{
   var params = {
               '_token': '{{ csrf_token() }}',
            };
            $.ajax({
                        url: '{{ url('releaseTableData') }}',
                        method: 'POST',
                        async: false,
                        data: params,
                        success: function (data) {
                        $('#loadTableReleaseModel').find('#table-release-load-buttons').html(data.Table);
                        }
              })
}

// ends
         function loadTables() {
            var tables  = $.ajax({
                        url: '{{ url('getTables') }}',
                        method: 'GET',
                        async: false,
                        success: function (data) {
                        // nothing needed here
                        }
               }) .responseText ;
            return tables;
         }

          // Adding invoice details to table
         function addInvoiceItemRow(id1 = '',name1 = '',unit1 = '',quantity = '',rate1 = '',total = '')
         {
            var myTable = document.getElementById("invoice-details-table");
            var currentIndex = myTable.rows.length;
            var currentRow = myTable.insertRow(1);

            var id = document.createElement("input");
            id.setAttribute("name", "id" + currentIndex);
            id.setAttribute("class", "form-control");
            id.setAttribute("value", id1);

            var name = document.createElement("input");
            name.setAttribute("name", "name" + currentIndex);
            name.setAttribute("class", "form-control");
            name.setAttribute("value", name1);

            var unit = document.createElement("input");
            unit.setAttribute("name", "unit" + currentIndex);
            unit.setAttribute("class", "form-control");
            unit.setAttribute("value", unit1);
            
            var quantity = document.createElement("input");
            quantity.setAttribute("name", "quantity" + currentIndex);
            quantity.setAttribute("class", "form-control qty");

            var rate = document.createElement("input");
            rate.setAttribute("name", "rate" + currentIndex);
            rate.setAttribute("class", "form-control price");
            rate.setAttribute("value", rate1);

            var total = document.createElement("input");
            total.setAttribute("name", "total" + currentIndex);
            total.setAttribute("class", "form-control total");

            var currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(id);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(name);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(unit);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(quantity);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(rate);

            currentCell = currentRow.insertCell(-1);
            currentCell.appendChild(total);
         }

      });
      $('#invoice-details-table tbody').on('keyup change',function(){
         calc();
    		});
      function calc()
    	{
    	   $('#invoice-details-table tbody tr').each(function(i, element) {
    			var html = $(this).html();

    			var qty = $(this).find('.qty').val();
    			var price = $(this).find('.price').val();
    		
    			$(this).find('.total').val(qty*price);

    			// if(+qty > +stock)
    			// 	{
    			// 		alert("Insufficient stock")
    			// 		$(this).find('.qty').val('')
    			// 		$(this).find('.total').val('')
    			// 	}

    			// calc_total();
    		});
    	}
   </script>

</body>

</html>