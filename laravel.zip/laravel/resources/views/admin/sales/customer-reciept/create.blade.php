 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
    {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
    {{ Html::style('plugins/animate/animate.css') }}
    {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
    {{ Html::style('plugins/select2/select2.min.css') }}
    {{-- summernote --}}
    {{ Html::style('plugins/summernote/summernote-bs4.css') }}

 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Customer Reciept</h4>
            </div>
          </div>
          <div class="main-content">
              <div class="form-row">
                <div class="col-md-4 col-lg-4 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Date</label>
                  <input type="date" class="form-control" name="date">
                </div>
                <div class="col-md-4 col-lg-4 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Select Account</label>
                    {!! Form::select('customer_id', $customer ,null,['placeholder' => '--Select Account--','class' => 'form-control basic select2','data-size'=>"10",'required','id' => 'customer_id','name'=> 'customer_id']); !!}
                 </div>
              </div>
              <div class="form-row">
                <div class="col-md-4 col-lg-4 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Amount</label>
                  <input type="number" class="form-control" placeholder="Amount" name="amount" value="0.00">
                </div>
                <div class="col-md-4 col-lg-4 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Invoice Number</label>
                  <input type="number" class="form-control" placeholder="Enter Invoice Number" name="invoice_no" value="">
                 </div>
              </div>
              <div class="form-row">
                <div class="col-md-10 col-lg-10 col-12 pb-3 layout-spacing field">
                  <label for="validationCustom02">Description</label>
                  <textarea class="form-control" placeholder="Enter Description"></textarea>
                </div>
              </div>
               <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="back()">cancel</button>
                    <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                    <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>
          </div>
        </div>
      </div>
    </div>
</div>
@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
<script>
$(document).ready(function() {
      //Initialize Select2 Elements
    $('.select2').select2()
});
</script>
@endsection

