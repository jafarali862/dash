<div class="topbar-nav header navbar" role="banner">
    <nav id="topbar">
        <ul class="navbar-nav theme-brand flex-row  text-center">
            <li class="nav-item theme-logo">
                <a href="index.html">
                    <img src="{{asset('assets/img/90x90.jpg')}}" class="navbar-logo" alt="logo">
                </a>
            </li>
            <li class="nav-item theme-text">
                <a href="index.html" class="nav-link"> CORK </a>
            </li>
        </ul>

        <ul class="list-unstyled menu-categories" id="topAccordion">

            <li class="menu single-menu {{ request()->is('superadmin/dashboard') || request()->is('/') ? 'active' : '' }}">
                <a data-toggle="collapse" aria-expanded="true" class="dropdown-toggle autodroprown" onclick="location.href='{{ route('superadmin.dashboard') }}'">
                    <div class="" style="cursor: pointer;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        <span>Dashboard</span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </a>
                {{-- <ul class="collapse submenu list-unstyled" id="dashboard" data-parent="#topAccordion">
                            <li class="active">
                                <a href="index.html"> Analytics </a>
                            </li>
                            <li>
                                <a href="index2.html"> Sales </a>
                            </li>
                        </ul> --}}
            </li>

            @if(auth()->user()->shop->can('sales'))
            <li class="menu single-menu {{ ($page_name == 'Invoice')? 'active': '' }} && {{ ($page_name == 'quotation')? 'active': '' }}">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="shopping-bag"></i><span class="icon-name">Sales</span>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    <li class="{{ ($page_name == 'Invoice')? 'active': '' }}">
                        <a href="{{ url('create-invoice') }}">Sales</a>
                    </li>

                    @if(auth()->user()->can('sales return'))
                    <li class="">
                        <a href="">Sales Return</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('quotation'))
                    <li class="{{ ($page_name == 'quotation')? 'active': '' }}">
                        <a href="{{ url('create-quotation') }}">Quotation</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('stock enquiry'))
                    <li class="">
                        <a href="">Stock Enquiry</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('damage'))
                    <li class="">
                        <a href="">Damage</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('customer receipt'))
                    <li class="">
                        <a href="">Customer Reciept</a>
                    </li>
                    @endif

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('wms'))
            <li class="menu single-menu">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="truck"></i><span class="icon-name">WMS</span>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">
                    <li class="">
                        <a href=""> Delivery Note </a>
                    </li>

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('purchase'))
            <li class="menu single-menu">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="credit-card"></i><span class="icon-name">Purchase</span>
                    </div>

                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    <li class="">
                        <a href=""> Purchase </a>
                    </li>

                    @if(auth()->user()->can('purchase return'))
                    <li class="">
                        <a href="">Purchase Return</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('supplier payment'))
                    <li class="">
                        <a href="">Supplier Payment</a>
                    </li>
                    @endif

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('master_data'))
            <li class="menu single-menu {{ getHead($page_name) }}">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layout">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="3" y1="9" x2="21" y2="9"></line>
                            <line x1="9" y1="21" x2="9" y2="9"></line>
                        </svg>
                        <span>Master Data</span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    @if(auth()->user()->can('setup'))
                    <li class="sub-sub-submenu-list {{ ($page_name == 'account_type') || ($page_name == 'itemGroup') || ($page_name == 'bank') || ($page_name == 'itemUnit')? 'active': '' }} ">
                        <a href="#datatable" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> Setup <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg> </a>
                        <ul class="collapse list-unstyled sub-submenu" id="datatable" data-parent="#datatable">

                            <li class="{{ ($page_name == 'account_type')? 'active': '' }}">
                                <a href="{!!  route('account-type.index') !!}"> Account Type </a>
                            </li>

                            <li class="{{ ($page_name == 'sub-account-type')? 'active': '' }}">
                                <a href="{!!  route('sub-account-type.index') !!}"> Sub-Account </a>
                            </li>

                            <li class="{{ ($page_name == 'itemGroup')? 'active': '' }}">
                                <a href="{{ route('item-groups.index') }}"> Item Group </a>
                            </li>

                            <li class="{{ ($page_name == 'bank')? 'active': '' }}">
                                <a href="{!! route('bank.index') !!}"> Bank </a>
                            </li>

                            <li class="{{ ($page_name == 'itemUnit')? 'active': '' }}">
                                <a href="{{ route('item-units.index') }}"> Unit of Measure </a>
                            </li>

                        </ul>
                    </li>
                    @endif

                    @if(auth()->user()->can('item'))
                    <li class="{{ ($page_name == 'item')? 'active': ''}}">
                        <a href="{{ route('items.index') }}"> Item </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('customer'))
                    <li class="{{ ($page_name == 'shop_customers')? 'active': ''}}">
                        <a href="{{ route('shop-customer.index')}}">Customer</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('supplier'))
                    <li class="{{ ($page_name == 'supplier')? 'active': ''}}">
                        <a href="{{ route('supplier.index') }}">Supplier</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('accounts master'))
                    <li class="{{ ($page_name == 'account')? 'active': ''}}">
                        <a href="{{ route('account.index') }}">Accounts Master</a>
                    </li>
                    @endif

                    @if(auth()->user()->can('barcode'))
                    <li class="">
                        <a href="#">Barcode</a>
                    </li>
                    @endif
                    <li class="{{ ($page_name == 'area_code')? 'active': ''}}">
                        <a href="#">Area Code</a>
                    </li>
                    <li class="{{ ($page_name == 'account')? 'active': ''}}">
                        <a href="#">Cost Center</a>
                    </li>
                    <li class="{{ ($page_name == 'account')? 'active': ''}}">
                        <a href="#">Sales Man</a>
                    </li>

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('accounts'))
            <li class="menu single-menu">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="dollar-sign"></i><span class="icon-name"> Accounts</span>
                    </div>

                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    @if(auth()->user()->can('cash reciept'))
                    <li class="">
                        <a href="#"> Cash Reciept </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('cash payment'))
                    <li class="">
                        <a href="#"> Cash Payment </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('bank deposit'))
                    <li class="">
                        <a href="#"> Bank Deposit </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('bank payment'))
                    <li class="">
                        <a href="#"> Bank Payment </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('jounal entry'))
                    <li class="">
                        <a href="#"> Journal Entry </a>
                    </li>
                    @endif

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('reports'))
            <li class="menu single-menu">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="database"></i><span class="icon-name">Reports</span>
                    </div>
                </a>

                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    @if(auth()->user()->can('sales report'))
                    <li class="">
                        <a href="#"> Sales </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('purchase report'))
                    <li class="">
                        <a href="#"> Purchase </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('stock report'))
                    <li class="">
                        <a href="#"> Stock </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('pricelist report'))
                    <li class="">
                        <a href="#"> Pricelist </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('inventory report'))
                    <li class="">
                        <a href="#"> Inventory </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('accounts report'))
                    <li class="">
                        <a href="#"> Accounts </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('final accounts report'))
                    <li class="">
                        <a href="#"> Final Accounts </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('vat report with expenses'))
                    <li class="">
                        <a href="#"> Vat Report with Expenses </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('vat report'))
                    <li class="">
                        <a href="#"> Vat Report </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('stock report with damage'))
                    <li class="">
                        <a href="#"> Stock Report With Damage </a>
                    </li>
                    @endif

                </ul>
            </li>
            @endif

            @if(auth()->user()->shop->can('admin'))
            <li class="menu single-menu">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i data-feather="user"></i><span class="icon-name">Admin</span>
                    </div>
                </a>

                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">

                    @if(auth()->user()->can('users'))
                    <li class="">
                        <a href="#"> Users </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('security'))
                    <li class="">
                        <a href="#"> Security </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('admin accounts'))
                    <li class="">
                        <a href="#"> Accounts </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('opening stock'))
                    <li class="">
                        <a href="#"> Opening Stock </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('stock updation'))
                    <li class="">
                        <a href="#"> Stock Updation </a>
                    </li>
                    @endif

                    @if(auth()->user()->can('account updation'))
                    <li class="">
                        <a href="#"> Account Updation </a>
                    </li>
                    @endif

                </ul>
            </li>
            @endif

            <li class="menu single-menu">
                <a href="#more" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                        <span>More</span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </a>
                <ul class="collapse submenu list-unstyled" id="more" data-parent="#topAccordion">
                    <li>
                        <a href="dragndrop_dragula.html">About Us</a>
                    </li>
                </ul>
            </li>

        </ul>
    </nav>
</div>