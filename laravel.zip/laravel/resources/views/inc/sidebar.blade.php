<div class="topbar-nav header navbar" role="banner">
            <nav id="topbar">
                <ul class="navbar-nav theme-brand flex-row  text-center">
                    <li class="nav-item theme-logo">
                        <a href="index.html">
                            <img src="{{asset('assets/img/90x90.jpg')}}" class="navbar-logo" alt="logo">
                        </a>
                    </li>
                    <li class="nav-item theme-text">
                        <a href="index.html" class="nav-link"> CORK </a>
                    </li>
                </ul>

                <ul class="list-unstyled menu-categories" id="topAccordion">

                    <li class="menu single-menu {{ request()->is('superadmin/dashboard') || request()->is('/') ? 'active' : '' }}">
                        <a data-toggle="collapse" aria-expanded="true" class="dropdown-toggle autodroprown" onclick="location.href='{{ route('superadmin.dashboard') }}'">
                            <div class="" style="cursor: pointer;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                                <span>Dashboard</span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </a>
                       {{--  <ul class="collapse submenu list-unstyled" id="dashboard" data-parent="#topAccordion">
                            <li class="active">
                                <a href="index.html"> Analytics </a>
                            </li>
                            <li>
                                <a href="index2.html"> Sales </a>
                            </li>
                        </ul> --}}
                    </li>
                @if(Auth::User()->role == 'super admin' )
                    <li class="menu single-menu {{ ($page_name == 'shopRegistration')? 'active': '' }}">
                        <a href="#app" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                                <span>Shop Management</span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="app" data-parent="#topAccordion">
                            <li class="{{ ($page_name == 'shopRegistration')? 'active': '' }}">
                                <a href="{{ route('shop-register.index') }}"> Registration </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu single-menu {{ ($page_name == 'permissions')? 'active': '' }}">
                        <a href="#app" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                                <span>Permissions Management</span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="app" data-parent="#topAccordion">
                            <li class="">
                                <a href="{{ route('permissions.index') }}"> Shop Admin Permissions </a>
                            </li>
                        </ul>
                    </li>
                @else

                    @if(auth()->user()->can('sales'))
                      <li class="menu single-menu {{ ($page_name == 'Invoice')? 'active': '' }} && {{ ($page_name == 'quotation')? 'active': '' }}">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <i data-feather="shopping-bag"></i><span class="icon-name">Sales</span>
                            </div>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="tables"  data-parent="#topAccordion">
                            <li class="{{ ($page_name == 'Invoice')? 'active': '' }}">
                                <a href="{{ url('create-invoice') }}">Sales</a>
                            </li>

                            <li class="{{ ($page_name == 'restaurant')? 'active': '' }}">
                                <a href="{{ url('restaurant-invoice') }}">Restaurant</a>
                            </li>

                           <li class="">
                               <a href="">Sales Return</a>
                            </li>

                            <li class="{{ ($page_name == 'quotation')? 'active': '' }}">
                                <a href="{{ url('create-quotation') }}">Quotation</a>
                            </li>

                            <li class="">
                               <a href="">Stock Enquiry</a>
                            </li>

                            <li class="">
                               <a href="">Damage</a>
                            </li>

                            <li class="">
                               <a href="">Customer Reciept</a>
                            </li>
                        </ul>
                    </li>
                    @endif

                    @if(auth()->user()->can('wms'))
                     <li class="menu single-menu">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <i data-feather="truck"></i><span class="icon-name">WMS</span>
                            </div>
                            
                        </a>
                        <ul class="collapse submenu list-unstyled" id="tables"  data-parent="#topAccordion">
                            <li class="">
                                <a href=""> Delivery Note </a>
                            </li>
                           
                        </ul>
                    </li>
                    @endif

                    @if(auth()->user()->can('purchase'))
                    <li class="menu single-menu">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <i data-feather="credit-card"></i><span class="icon-name">Purchase</span>
                            </div>
                            
                        </a>
                        <ul class="collapse submenu list-unstyled" id="tables"  data-parent="#topAccordion">
                            <li class="">
                                <a href=""> Purchase </a>
                            </li>
                            <li class="">
                               <a href="">Purchase Return</a>
                            </li>
                            <li class="">
                                <a href="">Supplier Payment</a>
                            </li>
                        </ul>
                    </li>
                    @endif

                    @if(auth()->user()->can('master_data'))
            <li class="menu single-menu {{ getHead($page_name) }}">
                <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layout">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="3" y1="9" x2="21" y2="9"></line>
                            <line x1="9" y1="21" x2="9" y2="9"></line>
                        </svg>
                        <span>Master Data</span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </a>
                <ul class="collapse submenu list-unstyled" id="tables" data-parent="#topAccordion">
                    <li class="sub-sub-submenu-list {{ ($page_name == 'account_type') || ($page_name == 'itemGroup') || ($page_name == 'bank') || ($page_name == 'itemUnit')? 'active': '' }} ">
                        <a href="#datatable" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> Setup <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg> </a>
                        <ul class="collapse list-unstyled sub-submenu" id="datatable" data-parent="#datatable">
                            <li class="{{ ($page_name == 'account_type')? 'active': '' }}">
                                <a href="{!!  route('account-type.index') !!}"> Account Type </a>
                            </li>
                            <li class="{{ ($page_name == 'sub-account-type')? 'active': '' }}">
                                <a href="{!!  route('sub-account-type.index') !!}"> Sub-Account </a>
                            </li>
                            <li class="{{ ($page_name == 'itemGroup')? 'active': '' }}">
                                <a href="{{ route('item-groups.index') }}"> Item Group </a>
                            </li>
                            <li class="{{ ($page_name == 'bank')? 'active': '' }}">
                                <a href="{!! route('bank.index') !!}"> Bank </a>
                            </li>
                            <li class="{{ ($page_name == 'itemUnit')? 'active': '' }}">
                                <a href="{{ route('item-units.index') }}"> Unit of Measure </a>
                            </li>
                        </ul>
                    </li>
                     <li class="sub-sub-submenu-list {{ ($page_name == 'table_settings') || ($page_name == 'token_settings') || ($page_name == 'order_type') || ($page_name == 'ingredient') || ($page_name == 'item_ingredient')? 'active': '' }}">
                        <a href="#datatable" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> Settings <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg> </a>
                        <ul class="collapse list-unstyled sub-submenu" id="datatable" data-parent="#datatable">
                            <li class="{{ ($page_name == 'table_settings')? 'active': ''}}">
                                <a href="{!!  route('table-settings.index') !!}"> Table Settings </a>
                            </li>
                            <li class="{{ ($page_name == 'token_settings')? 'active': ''}}">
                               <a href="{{ route('token-settings.index') }}"> Token Settings </a>
                            </li>
                            <li class="{{ ($page_name == 'order_type')? 'active': ''}}">
                               <a href="{{ route('order-type.index') }}"> Order Type </a>
                            </li>
                            <li class="{{ ($page_name == 'ingredient')? 'active': ''}}">
                               <a href="{{ route('ingredient.index') }}"> Ingredients </a>
                            </li>
                            <li class="{{ ($page_name == 'item_ingredient')? 'active': ''}}">
                               <a href="{{ route('item-ingredient.index') }}"> Item Ingredients </a>
                            </li>
                        </ul>
                    </li>
                    <li class="{{ ($page_name == 'item')? 'active': ''}}">
                        <a href="{{ route('items.index') }}"> Item </a>
                    </li>
                    <li class="{{ ($page_name == 'shop_customers')? 'active': ''}}">
                        <a href="{{ route('shop-customer.index')}}">Customer</a>
                    </li>
                    <li class="{{ ($page_name == 'supplier')? 'active': ''}}">
                        <a href="{{ route('supplier.index') }}">Supplier</a>
                    </li>
                    <li class="{{ ($page_name == 'account')? 'active': ''}}">
                        <a href="{{ route('account.index') }}">Accounts Master</a>
                    </li>
                    <li class="">
                        <a href="#">Barcode</a>
                    </li>
                    <li class="{{ ($page_name == 'area_code')? 'active': ''}}">
                        <a href="{{ route('area-code.index') }}">Area Code</a>
                    </li>
                    <li class="{{ ($page_name == 'cost_center')? 'active': ''}}">
                        <a href="{{ route('cost-center.index') }}">Cost Center</a>
                    </li>
                    <li class="{{ ($page_name == 'sales_man')? 'active': ''}}">
                        <a href="{{ route('sales-man.index') }}">Sales Man</a>
                    </li>

                </ul>
            </li>
            @endif
                    @if(auth()->user()->can('accounts'))
                    <li class="menu single-menu">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <i data-feather="dollar-sign"></i><span class="icon-name"> Accounts</span>
                            </div>
                            
                        </a>
                        <ul class="collapse submenu list-unstyled" id="tables"  data-parent="#topAccordion">
                            <li class="{{ ($page_name == 'cash_account')? 'active': ''}}">
                                <a href="{{ url('account-transactions/show/cash-receipt') }}"> Cash Reciept </a>
                            </li>
                           <li class="{{ ($page_name == 'cash_account')? 'active': ''}}">
                                <a href="{{ url('account-transactions/show/cash') }}"> Cash Payment </a>
                            </li>
                            <li class="{{ ($page_name == 'cash_account')? 'active': ''}}">
                                <a href="{{ url('account-transactions/show/bank')}}"> Bank Deposit </a>
                            </li>
                            <li class="{{ ($page_name == 'cash_account')? 'active': ''}}">
                                <a href="{{ url('account-transactions/show/bank-payment')}}"> Bank Payment </a>
                            </li>
                          <li class="{{ ($page_name == 'Journal')? 'active': '' }}">
                                <a href="{{ url('create-journal') }}">Journal Entry </a>
                            </li>
                        </ul>
                    </li>
                    @endif

                    @if(auth()->user()->can('reports'))
                     <li class="menu single-menu">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                 <i data-feather="database"></i><span class="icon-name">Reports</span>
                            </div>
                            
                        </a>
                        
                    </li>
                    @endif

                    @if(auth()->user()->can('admin'))
                    <li class="menu single-menu">
                        <a href="#tables" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                 <i data-feather="user"></i><span class="icon-name">Admin</span>
                            </div>
                            
                        </a>
                    </li>
                    @endif

                    <li class="menu single-menu">
                        <a href="#more" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                                <span>More</span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="more" data-parent="#topAccordion">
                            <li>
                                <a href="dragndrop_dragula.html">About Us</a>
                            </li>
                        </ul>
                    </li>
                @endif
                </ul>
            </nav>
        </div>