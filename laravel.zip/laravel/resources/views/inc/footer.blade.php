<div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class="">© 2020 <a target="_blank" href="https://designreset.com">Genius Solutions</a>, All rights reserved.</p>
    </div>
    <div class="footer-section f-section-2">
        <p class="">Designed and Developed By<a target="_blank" href="http://www.epagedesigners.in/"><img
         style="height:20px;width:130;px" src="{{asset('assets/img/epage_logo.svg')}}"></a>.</p>
    </div>
</div>