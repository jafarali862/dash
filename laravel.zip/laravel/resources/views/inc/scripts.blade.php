  <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="{{asset('assets/js/libs/jquery-3.1.1.min.js')}}"></script>
    <script src="{{asset('bootstrap/js/popper.min.js')}}"></script>
    <script src="{{asset('bootstrap/js/bootstrap.min.js')}}"></script>
    
    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="{{asset('assets/js/authentication/form-1.js')}}"></script>
 
    <script src="{{asset('assets/js/loader.js')}}"></script>

    <!-- Toastr -->
  {{ Html::script('plugins/toastr/toastr.min.js')}}

    <script src="{{asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
   <script src="{{asset('assets/js/app.js')}}"></script>
   <script src="{{asset('plugins/font-icons/feather/feather.min.js')}}"></script>
   <script type="text/javascript">
        feather.replace();
    </script>
   <script>
    $(document).ready(function() {
       App.init();
    });
   </script>
  