@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/scrollspyNav.css')}}" rel="stylesheet" type="text/css" />
 <!--  END CUSTOM STYLE FILE  -->
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/dropify/dropify.min.css')}}">
 <link href="{{asset('assets/css/users/account-setting.css')}}" rel="stylesheet" type="text/css" />
 <!--  END CUSTOM STYLE FILE  -->
 
 @endsection
 @section('content')
   <div id="content" class="main-content">
            <div class="layout-px-spacing">                
                <form  action="{{ route('profile.update',[$shopdata->id]) }}" class="section general-info"  method="post" id="profile" enctype="multipart/form-data"> 
                 @csrf  
                 @method('PUT') 
                <div class="account-settings-container layout-top-spacing">

                    <div class="account-content">
                        <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                    
                                        <div class="info">
                                            <h6 class="">General Information</h6>
                                            <div class="row">
                                                <div class="col-lg-11 mx-auto">
                                                    <div class="row">
                                                        <div class="col-xl-1 col-lg-9 col-md-4">
                                                        </div>
                                                        <div class="col-xl-2 col-lg-9 col-md-4">
                                                            <div class="upload mt-4 pr-md-4">
                                                                 @if($shopdata->photo)
                                                                 <input type="hidden"  name="image" value="{{ $shopdata->photo }}"/>
                                                                 <input  type="file" id="input-file-max-fs" class="dropify" name="image" data-default-file="/uploads/{{ $shopdata->photo }}" data-max-file-size="2M" />
                                                                 
                                                                @else
                                                                  <input type="file" id="input-file-max-fs" class="dropify" name="image" data-default-file="{{ asset('assets/img/profile.png')}}" data-max-file-size="2M" />
                                                                @endif
                                                                <p class="mt-2"><i class="flaticon-cloud-upload mr-1"></i> Upload Picture</p>
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-9 col-lg-12 col-md-8 mt-md-0 mt-4">
                                                            <div class="form">
                                                                <div class="row">
                                                                    <div class="col-sm-2">
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group">
                                                                            <label for="validationCustom02">Full Name</label>
                    <input type="text" class="form-control" id="name" placeholder="Name" name="name" value="{{ $shopdata->name }}" required>
                                                                        </div>
                                                                    </div>
                                                                  
                                                                </div>
                                                                 <div class="row">
                                                                     <div class="col-sm-2">
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <label class="dob-input">Email (Username)</label>
                                                                       
                                                                        <div class="form-group mr-1">
                                                                                
                                                                           <input disabled="" type="email" class="form-control" placeholder="Email (Username)" id="email" name="email" required value="{{ $shopdata->user->email }}">
                                                                            </div>
                                                                           
                                                                        </div>
                                                                     </div>
                                                                  </div>
                                                              </div>
                                                       </div>
                                                </div>
                                            </div>
                                        </div>
                                  </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                    <form id="about" class="section about">
                                        <div class="info">
                                            <h5 class="">About</h5>
                                            <div class="row">
                                                <div class="col-md-11 mx-auto">
                                                    <div class="form-group">
                                                        <label for="aboutBio">English Description</label>
                                                        <textarea class="form-control" name="eng_description" id="engdesptn" placeholder="English Description" rows="10">{{ $shopdata->eng_description }}</textarea>
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="row">
                                                <div class="col-md-11 mx-auto">
                                                    <div class="form-group">
                                                        <label for="aboutBio">Arabic Description</label>
                                                        <textarea class="form-control" name="arabic_description" id="arabicdesptn" placeholder="Arabic Description" rows="10">{{ $shopdata->arabic_description }}</textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                

                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                             
                                        <div class="info">
                                            <h5 class="">Contact</h5>
                                                         <div class="row">
                                                                 <div class="col-sm-6">
                                                                <div class="form-group">
                                                                   <label for="validationCustom02">Address Line 1</label>
                    <input type="text" class="form-control" name="line_1" placeholder="Address Line 1"  id="address1"  value="{{ $shopdata->line_1 }}">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                  <label for="validationCustom02">Address Line 2</label>
                    <input type="text" class="form-control" placeholder="Address Line 2" name="line_2" id="address2"  value="{{ $shopdata->line_2 }}">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                                 <div class="col-sm-6">
                                                                <div class="form-group">
                                                                   <label for="validationCustom03">City</label>
                    <input type="text" class="form-control city" placeholder="City" name="city"  id="city" value="{{ $shopdata->city }}">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                 <label for="validationCustom03">State</label>
                    <input type="text" class="form-control state" placeholder="State" name="state" id="state"  value="{{ $shopdata->state }}">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                                 <div class="col-sm-6">
                                                                <div class="form-group">
                                                                    <label for="validationCustom03">Country</label>
                    <input type="text" class="form-control" placeholder="Country" name="country" id="country"  required value="{{ $shopdata->country }}">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                 <label for="validationCustom03">Pin</label>
                    <input type="number" class="form-control" placeholder="Pin" name="pin" id="pin"  value="{{ $shopdata->pin }}">
                    <input type="number" class="form-control" hidden name="shop_id" value="{{ $shopdata->id }}">
                                                                </div>
                                                            </div>
                                                        </div>
                                                         <div class="row">
                                                                 <div class="col-sm-6">
                                                                <div class="form-group">
                                                                    <label for="validationCustom03">Primary phone</label>
                    <input type="number" class="form-control" placeholder="Primary phone" name="primary_phone" id="primary_phone"  required value="{{ $shopdata->primary_phone }}">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                   <label for="validationCustom03">Secondary phone</label>
                    <input type="number" class="form-control" name="secondary_phone" placeholder="Secondary phone" id="secondary_phone"  value="{{ $shopdata->secondary_phone }}">
                                                                </div>
                                                            </div>
                                                        </div>
                                        </div>
                                  
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                    
                                        <div class="info">
                                            <h5 class="">Social</h5>
                                            <div class="row">

                                                <div class="col-md-11 mx-auto">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="input-group social-instagram mb-3">
                                                                <div class="input-group-prepend mr-3">
                                                                    <span class="input-group-text" id="instagram"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-instagram"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></span>
                                                                    {{-- <i data-feather="instagram"></i><span class="icon-name"></span> --}}
                                                                </div>
                                                                <input type="text" name="linked_name" class="form-control" placeholder="linkedin name" aria-label="Username" aria-describedby="linkedin" value="{{ $shopdata->linked_url }}">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="input-group social-tweet mb-3">
                                                                <div class="input-group-prepend mr-3">
                                                                    <span class="input-group-text" id="tweet"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-twitter"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg></span>
                                                                </div>
                                                                <input type="text" name="tweet_name" class="form-control" placeholder="Twitter name" aria-label="Username" aria-describedby="tweet" value="{{ $shopdata->tiwtter_url }}">
                                                            </div>
                                                        </div>                                             <div class="col-md-4">
                                                        <div class="input-group social-fb mb-3">
                                                            <div class="input-group-prepend mr-3">
                                                                <span class="input-group-text" id="fb"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></span>
                                                                </div>
                                                                <input type="text" name="fb_name" class="form-control" placeholder="Facebook name" aria-label="Username" aria-describedby="fb" value="{{ $shopdata->fb_url }}">
                                                    </div>
                                                </div>           
                                                    </div>
                                                </div>
                                                    
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="account-settings-footer">
                        
                        <div class="as-footer-container">

                            <button id="multiple-reset" class="btn btn-warning" onclick="ClearFields();">Reset All</button>
                           
                            <button type="submit" id="multiple-messages" class="btn btn-primary">Save</button>

                        </div>
                        
                    </div>
                </div>
                </form>
                </div>
        </div>
 @endsection
 @section('script')
  <!--  BEGIN CUSTOM SCRIPTS FILE  -->
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('plugins/dropify/dropify.min.js')}}"></script>
    <script src="{{asset('plugins/blockui/jquery.blockUI.min.js')}}"></script>
    <!-- <script src="{{asset('plugins/tagInput/tags-input.js')}}"></script> -->
    <script src="{{asset('assets/js/users/account-settings.js')}}"></script>
    <!--  END CUSTOM SCRIPTS FILE  -->
    <script type="text/javascript">
         $('#profile').validate({
    ignore: [],
    rules: {
      name: {
        required : true ,
        maxlength: 200
      },
      email: {
        required : true ,
        maxlength: 200
      },
      eng_description: {
        required: true,
        maxlength: 1000
      },
      arabic_description: {
        // required: true,
        maxlength: 1000
      },
      line_1: {
        required: true,
        maxlength: 1000
      },
      line_2: {
        maxlength: 1000
      },
      city: {
        required: true,
        maxlength: 100
      },
      state: {
        required: true,
        maxlength: 100
      },
      country: {
        required: true,
        maxlength: 100
      },
     
      primary_phone: {
        required: true,
        maxlength: 20
      },
      secondary_phone: {
        maxlength: 20
      },
    },
    messages: {
      name: {
        required : "Please enter name!",
      },
      email: {
        required : "Please enter Email!",
      },
      eng_description: {
        required: "Please enter english description",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
      arabic_description: {
        // required: "Please enter arabic description !",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
      line_1: {
        required: "Please enter address line 1 !"
      },
      city: {
        required: "Please enter city !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
      state: {
        required: "Please enter state !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
      country: {
        required: "Please enter country !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
     
      primary_phone: {
         required: "Please enter primary phone !",
        maxlength: "Maximum 20 charectors only allowed !"
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });
    function ClearFields() {

     document.getElementById("name").value = "";
     document.getElementById("email").value = "";
     document.getElementById("engdesptn").value = "";
     document.getElementById("arabicdesptn").value = "";
     document.getElementById("address1").value = "";
     document.getElementById("address2").value = "";
     document.getElementById("city").value = "";
     document.getElementById("state").value = "";
     document.getElementById("country").value = "";
     document.getElementById("pin").value = "";
     document.getElementById("primary_phone").value = "";
     document.getElementById("secondary_phone").value = "";
         }
   
    </script>
 @endsection