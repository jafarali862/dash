@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
    {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
    {{ Html::style('plugins/animate/animate.css') }}
    {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
    {{ Html::style('plugins/select2/select2.min.css') }}

 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }

  
 </style>
 @endsection

 @section('content')


  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Add {{$shop->name}} Shop User</h4>
            </div>
          </div>
          <div id="content" class="main-content">
            <form action="{{ route('shopuser.store',[$shop->id]) }}" method="POST"  id="quickForm">
              @csrf
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Name</label>
                    <input type="text" class="form-control" placeholder="Name" name="name" required value="{{ old('name', isset($shopMaster) ? $shopMaster->name : '') }}">
                    @if($errors->has('name'))
                        <span for="name" class="error ml-2 text-danger">
                          {{ $errors->first('name') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Email (Username)</label>
                    <input type="email" class="form-control" placeholder="Email (Username)" name="email" required value="{{ old('email', isset($shopMaster) ? $shopMaster->user->email : '') }}">
                    @if($errors->has('email'))
                        <span for="email" class="error ml-2 text-danger">
                          {{ $errors->first('email') }}
                        </span> 
                     @endif
                  </div>
                </div>
                
                <div class="form-row layout-spacing pb-3">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Password</label>
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" required data-rule-password="true">
                    @if($errors->has('password'))
                        <span for="password" class="error ml-2 text-danger">
                          {{ $errors->first('password') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <label for="validationCustom03">Confirm password</label>
                    <input type="password" class="form-control" placeholder="Confirm password" name="password_confirm" data-rule-password="true" data-rule-equalTo="#password">
                    @if($errors->has('password_confirm'))
                        <span for="password_confirm" class="error ml-2 text-danger">
                          {{ $errors->first('password_confirm') }}
                        </span> 
                     @endif
                  </div>
                </div>
                                                                           
                <div class="modal-footer md-button">
                    <button class="btn btn-outline-danger btnCancel" onclick="window.history.go(-1); return false;">cancel</button>
                    <button class="btn btn-outline-success" name="save_only" value="save_only">Save</button>
                    <button class="btn btn-outline-success" name="save_and_new" value="save_and_new">Save & New</button>
                </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
{{-- end --}}
<script>

$(document).ready(function() {
    //  $(".select2").select2({
    //   width: '100%'
    // });

      //Initialize Select2 Elements
    $('.select2').select2()

     
});

// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
      name: {
        required : true ,
        maxlength: 200
      },
      email: {
        required : true ,
        maxlength: 200
      },
      password : {
        required: true,
        minlength : 5
      },
      password_confirm : {
          minlength : 5,
          equalTo : "#password"
      },
    },
    messages: {
      name: {
        required : "Please enter name!",
      },
      email: {
        required : "Please enter Email!",
      },
       password: {
         required: "Please enter password !",
      },
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });

 $(".select2").select2().change(function() {
    $(this).valid();
  });

</script>
@endsection

