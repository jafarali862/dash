@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- END GLOBAL MANDATORY STYLES -->
 <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
 <!-- END PAGE LEVEL PLUGINS -->
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
 <!--  END CUSTOM STYLE FILE  -->
 @endsection
 @section('content')

 <style>
     .text-caps{
         text-transform: capitalize;
     }
 </style>
 <div id="content" class="main-content">

  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">

            <div class="col-xl-6 col-lg-6 col-sm-6">
              <h4>Shop Admins and Permissions</h4>
            </div>
            <div class="col-xl-6 col-lg-6 col-sm-6">
                <div id="shopTable_filter" class="dataTables_filter">
                    <label><input type="search" class="form-control" placeholder="Search..." id="search" name="search"></label>
                    <button onclick="search()" class="btn btn-warning" href="">Search</button>
                </div>
            </div>
          </div>
          <div class="table mb-4 mt-4">
            <table id="shopTable" class="table table-hover non-hover" style="width:100%">

                <thead>
                    <tr>
                    <th>Sl No</th>
                    <th>Shop Admin</th>
                    <th>Sales</th>
                    <th>WMS</th>
                    <th>purchase</th>
                    <th>Master Data</th>
                    <th>Accounts</th>
                    <th>Reports</th>
                    <th>Admin</th>
                    <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($users as $user)
                    <tr>

                        <td>{{ $loop->iteration + (( $users->currentPage() - 1 ) * $users->perPage()) }}</td>
                        <td>{{$user->name}}</td>
                        @foreach($permissions as $permission)
                        <td>
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{$permission}}{{$user->id}}" name="{{$permission}}{{$user->id}}" {{ $user->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content text-caps">{{str_replace('_',' ',$permission)}}</span>
                            </label>
                        </td>
                        @endforeach
                        <td>
                            <a title="View Shop Users" href="{{url('/permissions/users',[$user->id])}}" title="View Shop Users">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                            </a>
                        </td>
                    </tr>
                    @empty
                   
                    <tr>
                        <td style="text-align: center;"  colspan="50">No Users</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
            
            <br>
            <br>
            <div class="row">
                <div class="col-md-5">
                    <div class="dataTables_info" id="shopTable_info" role="status" aria-live="polite">Showing page {{$users->currentPage()}} of {{$users->lastPage()}}</div>
                </div>
                <div class="col-md-7">
                    <div class="dataTables_paginate paging_simple_numbers" id="shopTable_paginate">
                        {{$users->links()}}
                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection

@section('script')

@foreach($permissions as $permission)

  @foreach($users as $user)
  <script>
      $("#{{$permission}}{{$user->id}}").on('click', function(event)
      {
          var permission = '{{$permission}}';
          var shop_id = '{{$user->id}}';
          var checked = $('#{{$permission}}{{$user->id}}').is(":checked");
          console.log(permission,shop_id,checked);
          updatePermission(permission,shop_id,checked);
      });
  </script>
  @endforeach

@endforeach

<script>
    function updatePermission(permission_name,shop_id,permission_value)
      {
          var params = {
                '_token': '{{ csrf_token() }}',
                'permission_name': permission_name,
                'shop_id': shop_id,
                'permission_value': permission_value
            };

            ajaxUpdate = function (params) 
            {
                if(params.permission_value == true)
                {
                    console.log(true);
                    var submitted  = $.ajax({
                          url: '{{ url('/shop/accessPermission') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                if (params.permission_value == false) 
                {
                  console.log(false);
                    var submitted  = $.ajax({
                          url: '{{ url('/shop/revokePermission') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                
            }
            console.log(ajaxUpdate(params));
    } 

    function search()
    {
        var search = document.getElementById("search").value;  
        window.location.replace('{{ url("permissions") }}');
        if(search)
        {
            window.location.replace('{{ url("permissions") }}' + '/' + search);
        }
    }

</script>
    
<!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
<script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
<!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
<script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
<script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
<script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>

@endsection

