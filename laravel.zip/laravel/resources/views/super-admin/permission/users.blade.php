@extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- END GLOBAL MANDATORY STYLES -->
 <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/custom_dt_html5.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
 <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <link href="{{asset('plugins/animate/animate.css')}}" rel="stylesheet" type="text/css" />
 <link href="{{asset('assets/css/forms/switches.css')}}" rel="stylesheet" type="text/css" />
 <!-- END PAGE LEVEL PLUGINS -->
 <!--  BEGIN CUSTOM STYLE FILE  -->
 <link href="{{asset('assets/css/components/custom-modal.css')}}" rel="stylesheet" type="text/css" />
 <!--  END CUSTOM STYLE FILE  -->
 @endsection
 @section('content')

 <style>
  .permission-span{
    text-transform: capitalize;
  }
  .delete-btn{
    border: none;
    background: transparent;
  }
</style>

 <div id="content" class="main-content">

  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-4 col-lg-4 col-sm-4">
              <h4>{{$shop->name}} - Users Permissions</h4>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <div id="shopTable_filter" class="dataTables_filter">
                    <label><input type="search" class="form-control" placeholder="Search..." id="search" name="search"></label>
                    <button onclick="search()" class="btn btn-warning" href="">Search</button>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-sm-2">
               <a title="Add new User for this Shop" class="btn btn-outline-success btn-rounded mb-2" href="{{ route('shopuser.create',[$shop_id]) }}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Add Shop User</a>
            </div>
            <div class="col-xl-2 col-lg-2 col-sm-2">
               <a title="Back to Shop Permissions" class="btn btn-outline-info btn-rounded mb-2" href="{{ url('/permissions') }}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg> Back</a>
            </div>
          </div>
          <div class="table mb-4 mt-4">
            <table id="shopTable" class="table table-hover non-hover" style="width:100%">

                <thead>
                    <tr>
                    <th>Sl No</th>
                    <th>User Name</th>
                    <!-- Users permissions (if users shop have main permissions) -->
                    @if($shop->can('sales'))
                    <th>Sales Permissions</th>
                    @endif

                    @if($shop->can('purchase'))
                    <th>Purchase Permissions</th>
                    @endif

                    @if($shop->can('master_data'))
                    <th>Master Data Permissions</th>
                    @endif

                    @if($shop->can('accounts'))
                    <th>Accounts Permissions</th>
                    @endif

                    @if($shop->can('reports'))
                    <th>Reports Permissions</th>
                    @endif

                    @if($shop->can('admin'))
                    <th>Admin Permissions</th>
                    @endif

                    <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($shop_users as $user)
                      <tr>
                          <td>{{ $loop->iteration + (( $shop_users->currentPage() - 1 ) * $shop_users->perPage()) }}</td>
                          <td>{{$user->shopUser->name}}</td>
                          <!-- Users permissions -->
                          @if($shop->can('sales'))
                          <td>
                            @foreach($sales_permissons as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="sales-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          @if($shop->can('purchase'))
                          <td>
                            @foreach($purchase_permissions as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="purchase-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          @if($shop->can('master_data'))
                          <td>
                            @foreach($master_data_permissions as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="master-data-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          @if($shop->can('accounts'))
                          <td>
                            @foreach($accounts_permissions as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="accounts-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          @if($shop->can('reports'))
                          <td>
                            @foreach($reports_permissions as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="accounts-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          @if($shop->can('admin'))
                          <td>
                            @foreach($admin_permissions as $permission)
                            <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                                <input type="checkbox" class="new-control-input" id="{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}" name="accounts-{{$user->shopUser->id}}" {{ $user->shopUser->can($permission) ? 'checked' : '' }}>
                                <span class="new-control-indicator"></span><span class="new-chk-content permission-span">{{$permission}}</span>
                            </label>
                            <br>
                            @endforeach
                          </td>
                          @endif

                          <td>
                            <div class="row">
                              <div class="status-update">
                                    @if($user->is_active == 1)
                                    <label class="switch  s-outline  s-outline-success">
                                        <input type="checkbox" class="changeStatus" checked onclick="changeStatus('{{$user->shopUser->id}}',false)">
                                        <span class="slider"></span>
                                    </label>
                                    @else
                                    <label class="switch s-outline s-outline-success">
                                        <input type="checkbox" class="changeStatus" onclick="changeStatus('{{$user->shopUser->id}}',true)">
                                        <span class="slider"></span>
                                    </label>
                                    @endif
                              </div>

                              <div class="ml-2">
                                <form action="{{route('shop-user.delete')}}" method="POST">
                                  @csrf
                                  <input type="hidden" name="shop_user_id" id="shop_user_id" value="{{$user->user_id}}">
                                  <input type="hidden" name="shop_id" id="shop_id" value="{{$shop->id}}">
                                  <a title="Delete User" href=""><button type="submit" class="bs-tooltip delete-btn" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-circle table-cancel"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></button></a>
                                </form>
                              </div>
                            </div>
                            
                          </td>
                      </tr>
                    @empty
                    <tr>
                        <td style="text-align: center;"  colspan="50">No Users found for this shop.</td>
                    </tr>
                   @endforelse
                </tbody>
            </table>
            
            <br>
            <br>
            <div class="row">
                <div class="col-md-5">
                    <div class="dataTables_info" id="shopTable_info" role="status" aria-live="polite">Showing page {{$shop_users->currentPage()}} of {{$shop_users->lastPage()}}</div>
                </div>
                <div class="col-md-7">
                    <div class="dataTables_paginate paging_simple_numbers" id="shopTable_paginate">
                        {{$shop_users->links()}}
                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection

@section('script')

@foreach($permissons as $permission)

  @foreach($shop_users as $user)
  <script>
      $("#{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}").on('click', function(event)
      {
          var permission = '{{\Illuminate\Support\Str::slug($permission)}}';
          var shop_user_id = '{{$user->shopUser->id}}';
          var checked = $('#{{\Illuminate\Support\Str::slug($permission)}}-{{$user->shopUser->id}}').is(":checked");
          console.log(permission,shop_user_id,checked);
          updatePermission(permission,shop_user_id,checked);
      });
  </script>
  @endforeach

@endforeach

<script>
  function updatePermission(permission_name,shop_user_id,permission_value)
      {
          var params = {
                '_token': '{{ csrf_token() }}',
                'permission_name': permission_name,
                'shop_user_id': shop_user_id,
                'permission_value': permission_value
            };

            ajaxUpdate = function (params) 
            {
                if(params.permission_value == true)
                {
                    console.log(true);
                    var submitted  = $.ajax({
                          url: '{{ url('/shopuser/accessPermission') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                if (params.permission_value == false) 
                {
                  console.log(false);
                    var submitted  = $.ajax({
                          url: '{{ url('/shopuser/revokePermission') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                
            }
            console.log(ajaxUpdate(params));
      } 

      // Change status
   function changeStatus(shop_user_id,status) 
   {
      if(status == true)
      {
        $(this).addClass("active");
      }else{
        $(this).addClass("inactive");
      }
       console.log(shop_user_id,status);
        var params = {
                '_token': '{{ csrf_token() }}',
                'shop_user_id': shop_user_id,
                'status': status,
            };

            ajaxStatusUpdate = function (params) 
            {
                if(params.status == true)
                {
                    console.log(params.status);
                    var submitted  = $.ajax({
                          url: '{{ url('/shop-user/status/change') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                if (params.status == false) 
                {
                  console.log(params.status);
                    var submitted  = $.ajax({
                          url: '{{ url('/shop-user/status/change') }}',
                          method: 'POST',
                          async: false,
                          data: params,
                          success: function (data) {
                          }
                    }) .responseText ;
                    return submitted;
                }
                
            }
            console.log(ajaxStatusUpdate(params));
  }

  function search()
    {
        var search = document.getElementById("search").value;  
        window.location.replace('{{ url("/permissions/users",$shop->id) }}');
        if(search)
        {
            window.location.replace('{{ url("/permissions/users",$shop->id) }}' + '/' + search);
        }
    }
</script>

<!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
<script src="{{asset('plugins/table/datatable/datatables.js')}}"></script>
<!-- NOTE TO Use Copy CSV Excel PDF Print Options You Must Include These Files  -->
<script src="{{asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('plugins/table/datatable/button-ext/jszip.min.js')}}"></script>    
<script src="{{asset('plugins/table/datatable/button-ext/buttons.html5.min.js')}}"></script>
<script src="{{asset('plugins/table/datatable/button-ext/buttons.print.min.js')}}"></script>
<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>

@endsection

