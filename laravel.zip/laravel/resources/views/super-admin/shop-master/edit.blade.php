 @extends('layouts.app')
 @section('style')
 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
 <!-- BEGIN PAGE LEVEL PLUGINS -->
    {{ Html::style('plugins/table/datatable/dt-global_style.css') }}
   {{ Html::style('plugins/animate/animate.css') }}
   {{ Html::style('assets/css/forms/theme-checkbox-radio.css') }}
   {{ Html::style('plugins/select2/select2.min.css') }}

 <style type="text/css">
   .layout-spacing{
        margin-left: auto;
        margin-right: auto;
        width: 50%;
   }
   .select2-container{
    margin-bottom: 0px !important;
    /*width: 100vh !important;*/
   }

  
 </style>
 @endsection

 @section('content')
  <div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-row">
      <div class="col-xl-8 col-lg-8 col-sm-8 col-8 layout-spacing">
        <div class="widget-content widget-content-area br-6">
          <div class="row">
            <div class="col-xl-8 col-lg-8 col-sm-8">
              <h4>Edit Shop</h4>
            </div>
          </div>
          <div id="content" class="main-content">

            <form action="{{ route("shop-register.update", [$shopMaster->id]) }}" method="POST"  enctype="multipart/form-data" id="quickForm">
                @csrf
                @method('PUT')
                <input type="hidden" name="master_id" value="{{ $shopMaster->id }}">
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Name</label>
                    <input type="text" class="form-control" placeholder="Name" name="name" required value="{{ old('name', isset($shopMaster) ? $shopMaster->name : '') }}">
                    @if($errors->has('name'))
                        <span for="name" class="error ml-2 text-danger">
                          {{ $errors->first('name') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom01">Email (Username)</label>
                    <input type="email" class="form-control" placeholder="Email (Username)" name="email" required 
                    value="{{ old('email', isset($shopMaster) ? $shopMaster->user->email : '') }}"
                    >
                    @if($errors->has('email'))
                        <span for="email" class="error ml-2 text-danger">
                          {{ $errors->first('email') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">English Description</label>
                    <input type="text" class="form-control" placeholder="English Description" name="english_description" required value="{{ old('eng_description', isset($shopMaster) ? $shopMaster->eng_description : '') }}">
                    @if($errors->has('english_description'))
                        <span for="english_description" class="error ml-2 text-danger">
                          {{ $errors->first('english_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Arabic Description</label>
                    <input type="text" class="form-control" placeholder="Arabic Description" name="arabic_description" value="{{ old('arabic_description', isset($shopMaster) ? $shopMaster->arabic_description : '') }}">
                    @if($errors->has('arabic_description'))
                        <span for="arabic_description" class="error ml-2 text-danger">
                          {{ $errors->first('arabic_description') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Address Line 1</label>
                    <input type="text" class="form-control" placeholder="Address Line 1" name="line_1" value="{{ old('line_1', isset($shopMaster) ? $shopMaster->line_1 : '') }}">
                    @if($errors->has('line_1'))
                        <span for="line_1" class="error ml-2 text-danger">
                          {{ $errors->first('line_1') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-md-6 col-lg-6 col-12 pb-3 layout-spacing field">
                    <label for="validationCustom02">Address Line 2</label>
                    <input type="text" class="form-control" placeholder="Address Line 2" name="line_2" value="{{ old('line_2', isset($shopMaster) ? $shopMaster->line_2 : '') }}">
                    @if($errors->has('line_2'))
                        <span for="line_2" class="error ml-2 text-danger">
                          {{ $errors->first('line_2') }}
                        </span> 
                     @endif
                  </div>
                </div>
                
                  
                <div class="form-row layout-spacing pb-3">
                  <div class="col-md-6 col-lg-6 col-12  field">
                    <label for="validationCustom03">City</label>
                    <input type="text" class="form-control city" placeholder="City" name="city" value="{{ old('city', isset($shopMaster) ? $shopMaster->city : '') }}">
                    @if($errors->has('city'))
                        <span for="city" class="error ml-2 text-danger">
                          {{ $errors->first('city') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-6 col-lg-6 col-12 field">
                    <label for="validationCustom03">State</label>
                    <input type="text" class="form-control state" placeholder="State" name="state" value="{{ old('state', isset($shopMaster) ? $shopMaster->state : '') }}">
                    @if($errors->has('state'))
                        <span for="state" class="error ml-2 text-danger">
                          {{ $errors->first('state') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Country</label>
                    <input type="text" class="form-control" placeholder="Country" name="country" required value="{{ old('country', isset($shopMaster) ? $shopMaster->country : '') }}">
                    @if($errors->has('country'))
                        <span for="country" class="error ml-2 text-danger">
                          {{ $errors->first('country') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <label for="validationCustom03">Pin</label>
                    <input type="number" class="form-control" placeholder="Pin" name="pin" value="{{ old('pin', isset($shopMaster) ? $shopMaster->pin : '') }}">
                    @if($errors->has('pin'))
                        <span for="pin" class="error ml-2 text-danger">
                          {{ $errors->first('pin') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Primary phone</label>
                    <input type="number" class="form-control" placeholder="Primary phone" name="primary_phone" required value="{{ old('primary_phone', isset($shopMaster) ? $shopMaster->primary_phone : '') }}">
                    @if($errors->has('primary_phone'))
                        <span for="primary_phone" class="error ml-2 text-danger">
                          {{ $errors->first('primary_phone') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <label for="validationCustom03">Secondary phone</label>
                    <input type="number" class="form-control" placeholder="Secondary phone" name="secondary_phone" value="{{ old('secondary_phone', isset($shopMaster) ? $shopMaster->secondary_phone : '') }}">
                    @if($errors->has('secondary_phone'))
                        <span for="secondary_phone" class="error ml-2 text-danger">
                          {{ $errors->first('secondary_phone') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing pb-3">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Password</label>
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password"  data-rule-password="true">
                    @if($errors->has('password'))
                        <span for="password" class="error ml-2 text-danger">
                          {{ $errors->first('password') }}
                        </span> 
                     @endif
                  </div>
                   <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <label for="validationCustom03">Confirm password</label>
                    <input type="password" class="form-control" placeholder="Confirm password" name="password_confirm" data-rule-password="true" data-rule-equalTo="#password">
                    @if($errors->has('password_confirm'))
                        <span for="password_confirm" class="error ml-2 text-danger">
                          {{ $errors->first('password_confirm') }}
                        </span> 
                     @endif
                  </div>
                </div>
                <div class="form-row layout-spacing">
                  <div class="col-md-6 col-lg-6 col-6 field">
                    <label for="validationCustom03">Expiry date</label>
                    <input type="date" class="form-control" placeholder="Expiry date" name="expiry_date" required value="{{ old('expiry_date', isset($shopMaster) ? $shopMaster->expiry_date : '') }}">
                     @if($errors->has('expiry_date'))
                        <span for="expiry_date" class="error ml-2 text-danger">
                          {{ $errors->first('expiry_date') }}
                        </span> 
                     @endif
                  </div>
                  <div class="col-md-6 col-lg-6 col-6 pb-0 field">
                    <div class="n-chk mt-5">
                          <label class="new-control new-checkbox new-checkbox-text checkbox-outline-primary checkbox-primary">
                            <input type="checkbox" class="new-control-input" id="payment_recieved" name="payment_recieved" {{ $shopMaster->payment_recieved == 1? 'checked':'' }}>
                            <span class="new-control-indicator"></span><span class="new-chk-content">Payment recieved</span>
                          </label>
                      </div>
                  </div>
                </div>
                 
                </div>                                                           
                <div class="modal-footer md-button">
                  <button class="btn btn-outline-success" type="submit">Update</button>
                  <button class="btn btn-outline-danger btnCancel" onclick="history.back()">Cancel</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')

<!--  BEGIN CUSTOM SCRIPT FILE  -->
<script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('plugins/select2/select2.min.js')}}"></script>
{{-- end --}}
<script>

$(document).ready(function() {
    //  $(".select2").select2({
    //   width: '100%'
    // });

      //Initialize Select2 Elements
    $('.select2').select2()

     
});

// FORM SUBMIT WITH VALIDATION

  // Validate popup
  $('#quickForm').validate({
    ignore: [],
    rules: {
      name: {
        required : true ,
        maxlength: 200
      },
      email: {
        required : true ,
        maxlength: 200
      },
      english_description: {
        required: true,
        maxlength: 1000
      },
      arabic_description: {
        // required: true,
        maxlength: 1000
      },
      line_1: {
        required: true,
        maxlength: 1000
      },
      line_2: {
        maxlength: 1000
      },
      city: {
        required: true,
        maxlength: 100
      },
      state: {
        required: true,
        maxlength: 100
      },
      country: {
        required: true,
        maxlength: 100
      },
      vat_number: {
        required: true,
        maxlength: 20
      },
      vat_value: {
        required: true,
        maxlength: 20
      },
      primary_phone: {
        required: true,
        maxlength: 20
      },
      secondary_phone: {
        maxlength: 20
      },
      expiry_date: {
        required: true,
      },
      password : {
        // required: true,
        minlength : 5
      },
      password_confirm : {
          minlength : 5,
          equalTo : "#password"
      },
    },
    messages: {
      name: {
        required : "Please enter name!",
      },
      email: {
        required : "Please enter Email!",
      },
      english_description: {
        required: "Please enter english description",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
      arabic_description: {
        // required: "Please enter arabic description !",
        maxlength: "Maximum 1000 charectors only allowed !"
      },
      line_1: {
        required: "Please enter address line 1 !"
      },
      city: {
        required: "Please enter city !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
      state: {
        required: "Please enter state !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
      country: {
        required: "Please enter country !",
        maxlength: "Maximum 100 charectors only allowed !"
      },
      vat_number: {
        required: "Please enter vat number !",
        maxlength: "Maximum 20 charectors only allowed !"
      },
      primary_phone: {
         required: "Please enter primary phone !",
        maxlength: "Maximum 20 charectors only allowed !"
      },
       vat_value: {
         required: "Please enter vat value !",
         maxlength: "Maximum 20 charectors only allowed !"
      },
      //  password: {
      //    required: "Please enter password !",
      // },
       expiry_date: {
         required: "Please enter expiry date !",
      }

    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      element.closest('.field').append(error);
      $('.error').addClass('ml-2 text-danger')
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
      $(element).removeClass(errorClass);
    }, 
    submitHandler: function (form) {
        form.submit();
      }
  });

// Modal cancel button click
    $(document).on('click', '.btnCancel', function(event) {
      event.preventDefault();
      /* Act on the event */
     
    });

 $(".select2").select2().change(function() {
    $(this).valid();
  });

function back()
{
    window.location="{!!  route('shop-register.index') !!}"
}

</script>
@endsection

