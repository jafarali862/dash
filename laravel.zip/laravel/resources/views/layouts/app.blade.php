@include('inc.function')
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ setTitle($page_name) }}</title>
    <link rel="icon" type="image/x-icon" href="{{asset('assets/img/favicon.ico')}}"/>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <!-- Styles -->
    @include('inc.styles') 
    @yield('style') 
</head>
<body class="alt-menu sidebar-noneoverflow">
    
    <!-- BEGIN LOADER -->
    <div id="load_screen"> <div class="loader"> <div class="loader-content">
        <div class="spinner-grow align-self-center"></div>
    </div></div></div>
    <!--  END LOADER -->

    @include('inc.navbar')
    
    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        @if(auth()->user()->role == 'shop_user')
            @include('inc.sidebar-user')
        @else
            @include('inc.sidebar')
        @endif

        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">

            @yield('content')
           
        </div>
        <!--  END CONTENT PART  -->
     @include('inc.footer')
    </div>
    <!-- END MAIN CONTAINER -->

    @include('inc.scripts')
    @yield('script')
         {{-- ALert message popup --}}
       @if(Session::has('message'))    
        <script type="text/javascript">
            toastr.success('{{session()->get('message')}}');
         </script>
       @endif

        {{-- ALert message delete popup --}}
        @if(Session::has('deleted'))    
        <script type="text/javascript">
            toastr.success('{{session()->get('deleted')}}');
         </script>
       @endif
</body>
</html>