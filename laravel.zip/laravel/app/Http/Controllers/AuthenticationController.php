<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\User;
use App\Model\ShopMaster;
use App\ShopUser;
use Carbon\Carbon;
use Hash;

class AuthenticationController extends Controller
{
    public function authentication(Request $request)
    {
        $validator = Validator::make(request()->all(),[
            'email'      => 'required|email|unique:users',
            'password'   => 'required'
        ]); 

        if($validator->fails())
        {
           $user=User::select('*')->where('email',$request->email)->first();

            if(!(Hash::check($request->password, $user->password))) 
            {
                return back()->with('error','Incorrect password');
            }
            else if($user->shopMaster->whereDate('expiry_date', '>=', Carbon::today()->toDateString())->first())
            {   
                if($user->shopMaster->payment_recieved == 1)
                {
                    if($user->role == 'shop_user')
                    {
                        $shop_user = ShopUser::where('user_id',$user->id)->first();
                        if($shop_user && $shop_user->is_active == 0){
                            return back()->with('error', 'We were unable to sign you in, Your activation is pending. Please contact.');
                        }
                    }
                    $login = auth()->attempt(request()->except('_token'));
                    return redirect(route('superadmin.dashboard'));
                }
                else
                {
                    return back()->with('error', 'We were unable to sign you in, Your subscription billing is pending. Please contact.');
                }   
            }
            else
            {
                return back()->with('error', 'We were unable to sign you in, Your subscription is expired. Please contact. ');
            }
        }
        else
        {
            return back()->with('error','Wrong Login Details');
        }
    }
    
    public function superadminDashBorad()
    {
         $data = [
            'page_name' => 'superadminDashboard',
        ];

        return view('dashboard')->with($data);
    }

    
    public function signOut()
    {
       Auth::logout();
      
       return redirect()->route('login');
    }

    public function forgotPassword()
    {
        $data = [
            'page_name' => 'forgetpassword',
        ];

        return view('Authentication/auth_pass_recovery')->with($data);
    }

    public function index()
    {
       if(auth()->check()){
            return redirect(route('superadmin.dashboard'));
        }

        $data = [
            'page_name' => 'login',
        ];
         return view('Authentication/auth_login')->with($data);
    }

    
    public function edit(Auth $auth)
    {
        //
    }

   
    public function update(Request $request, Auth $auth)
    {
        //
    }

    
    public function destroy(Auth $auth)
    {
        //
    }
}
