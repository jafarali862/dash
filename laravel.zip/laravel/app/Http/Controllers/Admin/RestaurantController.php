<?php

namespace App\Http\Controllers\Admin;

use App\Model\Customer;
use App\Model\Item;
use App\Model\ItemGroup;
use App\Http\Controllers\Controller;
use App\Model\AddOn;
use App\Model\RestaurantInvoice;
use App\Model\ItemItemUnit;
use App\Model\TableSetting;
use App\Model\TokenSetting;
use App\Model\OrderType;
use Auth;
use Illuminate\Http\Request;

class RestaurantController extends Controller
{
    protected $page = 'restaurant';

    
     /**
     * index function ()
     *
     * @return array
     */
    public function index()
    {
        $ordertypes = OrderType::where('created_by',Auth::user()->shop_master_id)->where('is_active',1)->get();
        $tables = TableSetting::where('created_by',Auth::user()->shop_master_id)->where('is_active',1)->get();
        $customers = Customer::select("id", \DB::raw("CONCAT(customers.cust_name,' [',customers.mobile,']') as full_name"))
        ->pluck('full_name', 'id')->toArray();

        if (RestaurantInvoice::max('id')) {
            $invId = Invoice::max('id') + 1;
            $invoiceId = "#000" . $invId;
        } else {
            $invoiceId = "#001";
        }

        if (RestaurantInvoice::max('token_no')) {
            $tokenId = RestaurantInvoice::max('token_no') + 1;
        } else {
            $tokenId = TokenSetting::where('created_by',Auth::user()->shop_master_id)->pluck('token_start_no');
        }

        $categories = ItemGroup::select('id','english_description','arabic_description')->where('is_active',1)->get();
        return view('admin.sales.restaurant.index',compact('categories','customers','invoiceId','tokenId','tables','ordertypes'));
    }

    /**
     * bookTable for reserve tables
     *
     * @return array
     */
    public function bookTable(Request $request)
    {
        $response=TableSetting::where('id', $request->table_id)->update(array('booked' => $request->value));
        $tables = '';
        $tableIDArray = [];
        if($response == 1)
        {
            foreach (TableSetting::where('created_by',Auth::user()->shop_master_id)->where('is_active',1)->get() as $key => $table) {
                if($table->booked == 'booked'){
                     $tables .= '<button disabled="" style="background-color: darkorange;" class="btn tableselection" value='.$table->id. '>'.$table->table_name.'(R)</button>&nbsp;&nbsp;';
                     $tableIDArray[] = $table->id;
                }else{
                    $tables .= '<button  class="btn tableselection" value='.$table->id. '>'.$table->table_name.'</button>&nbsp;&nbsp;';
                }
            }
            
        return ['Table' => $tables, 'TableIds' => implode(",",$tableIDArray), 'single_table_id' =>$request->table_id ];  
        }
    }

    /**
     * releaseTable for release tables (booked tables)
     *
     * @return array
     */
    public function releaseTable(Request $request)
    {
        $response=TableSetting::where('id', $request->table_id)->update(array('booked' => ''));
        $tables = '';
        if($response == 1)
        {
            foreach (TableSetting::where('created_by',Auth::user()->shop_master_id)->where('is_active',1)->get() as $key => $table) {
                if($table->booked == 'booked'){
                     $tables .= '<button  style="background-color: darkorange;" class="btn tableselection" value='.$table->id. '>'.$table->table_name.'(R)</button>&nbsp;&nbsp;';
                     
                }else{
                    $tables .= '<button disabled="" class="btn tableselection" value='.$table->id. '>'.$table->table_name.'</button>&nbsp;&nbsp;';
                }
            }
            
        return ['Table' => $tables, 'table_id' => $request->table_id];  
        }
    }

    /**
     * releaseTableData get booked table datas
     *
     * @return array
     */
    public function releaseTableData()
    {
        $response=TableSetting::where('created_by',Auth::user()->shop_master_id)->get();
        $tables = '';
            foreach ($response as $key => $table) {
                if($table->booked == 'booked'){
                     $tables .= '<button  style="background-color: darkorange;" class="btn tableselection" value='.$table->id. '>'.$table->table_name.'(R)</button>&nbsp;&nbsp;';
                     
                }else{
                    $tables .= '<button disabled="" class="btn tableselection" value='.$table->id. '>'.$table->table_name.'</button>&nbsp;&nbsp;';
                }
            }
            
        return ['Table' => $tables];  
        
    }

    /**
     * loadItems for load items
     *
     * @return json
     */
    public function loadItems(Request $request)
    {
        $loadeditems = Item::select('id','english_description','barcode')
                ->where([['is_active',1],['item_group_id',$request->category_id]])
                ->get();
        
        return json_encode($loadeditems);
    }

    /**
     * getItemDetails for get details of item
     *
     * @return json
     */
    public function getItemDetails(Request $request)
    {
        $itemDetails = Item::select('id','english_description','barcode',)->where('created_by',Auth::user()->shop_master_id)->findOrFail($request->item_id);
        $itemUnit = ItemItemUnit::rightJoin('item_units', function($join) {
            $join->on('item_item_unit.item_unit_id', '=', 'item_units.id');
          })
          ->where('item_id', $request->item_id)
          ->first([
              'item_units.short_description',
              'item_item_unit.price',
          ]);
        
        $totaldata = [];
        $totaldata['details'] = $itemDetails;
        $totaldata['unit'] = $itemUnit;
        return json_encode($totaldata);
    }

    /**
    *getItemsByBarCode for get items by barcode
    *
    *@return json 
    */
    public function getItemsByBarCode(Request $request)
    {
        $itemDetails = Item::select('id','english_description','barcode',)->where('created_by',Auth::user()->shop_master_id)->where('barcode',$request->barcode)->get();
        
        if(!empty($itemDetails[0]))
        {
           $itemUnit = ItemItemUnit::rightJoin('item_units', function($join) {
            $join->on('item_item_unit.item_unit_id', '=', 'item_units.id');
          })
          ->where('item_id', $itemDetails[0]->id)
          ->first([
              'item_units.short_description',
              'item_item_unit.price',
          ]);
        
          $totaldata = [];
          $totaldata['details'] = $itemDetails[0];
          $totaldata['unit'] = $itemUnit;
        }else{
          $totaldata['details'] = 'no items found';
        }
        
        return json_encode($totaldata);
    }

    /**
     * getItemAddons for get add on of items
     *
     * @return json
     */
    public function getItemAddons(Request $request)
    {
        $addons = AddOn::select('id','add_on_name')
                    ->where('item_id', $request->item_id)
                    ->where('is_active',1)
                    ->get();
        
        return json_encode($addons);
    }
}
