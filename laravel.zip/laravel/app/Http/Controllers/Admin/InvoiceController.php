<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\ItemUnit;
use App\Model\Item;
use App\Model\Customer;
use App\Model\Invoice;
use App\Model\InvoicePurchaseDetail;
use App\Model\ItemItemUnit;
use App\Model\ItemGroup;
use Auth;
use DB;
use App\Http\Requests\InvoiceRequest;

class InvoiceController extends Controller
{
    protected $page = 'Invoice';

    public function index()
    {
        $page_name = $this->page;
        $invoices = Invoice::where('created_by', Auth::user()->shop_master_id)
            ->get();
        return view('admin.sales.sales.invoice_list', compact('page_name', 'invoices'));
    }

    public function viewInvoice()
    {
        $page_name = $this->page;
        $invoices = Invoice::where('created_by', Auth::user()->shop_master_id)
            ->pluck('invoice_number', 'id');
        $customers = Customer::pluck('cust_name', 'id');
        return view('admin.sales.sales.invoice', compact('page_name', 'invoices', 'customers'));
    }

    public function getInvoiceDetails(Request $request)
    {
        $invoice = Invoice::where('id', $request->inv_id)->first();
        $invoice_details = $invoice->invoiceDetails;

        $table = '';
        $row = '';

        foreach ($invoice_details as $key => $value) {
            $product = Item::where('id', $value->item_id)->first()->english_description;

            $row .= '<tr><td>' . ++$key . '</td><td>' . $product . '</td><td class="text-right">' . $value->unit . '</td><td class="text-right">' . $value->price . '</td><td class="text-right">' . $value->quantity . '</td><td class="text-right">' . $value->stock . '</td><td class="text-right">' . $value->stock . '</td><td class="text-right">' . $value->total . '</td><td class="text-center removeRow" data-flag=1 data-unit="' . $value->unit . '" data-item="' . $value->item_id . '" data-qty="' . $value->quantity . '" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 icon"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                        </td></tr>';

            $table .= $row;
            $row = '';
        }

        return response()->json(['Invoice' => $invoice, 'Table' => $table]);
    }

    public function editInvoiceDetails(Request $request)
    {
        $invoice = Invoice::where('id', $request->inv_id)->first();
        $invoice_details = $invoice->invoiceDetails;

        $table = '';
        $row = '';
        $counter = sizeof($invoice_details);
        $total_vat = 0;
        foreach ($invoice_details as $key => $value) {

            $select = '<select class="selectpicker productSelect" title="Select Product" name="Products[]" id="Products" required>';
            $select_unit = '<select class="selectpicker unit" data-width="80%" title="Select Unit" name="unit[]" id="Unit" required>';
            $options = '';
            $options_unit = '';


            foreach (Item::where('created_by', Auth::user()->shop_master_id)
                ->pluck('english_description', 'id') as $item_id => $item_name) {
                if ($item_id == $value->item_id) {
                    $options .= '<option selected value=' . $item_id . '>' . $item_name . '</option>';
                } else {
                    $options .= '<option value=' . $item_id . '>' . $item_name . '</option>';
                }
            }

            $item = Item::where('id', $value->item_id)->first();


            $item_units = ItemItemUnit::where('item_id', $value->item_id)
                ->pluck('item_unit_id')
                ->toArray();

            foreach (ItemUnit::whereIn('id', $item_units)->pluck('english_description', 'id')
                as $unit_id => $unit_name) {
                if ($unit_id == $value->unit) {
                    $options_unit .= '<option selected value=' . $unit_id . '>' . $unit_name . '</option>';
                } else {
                    $options_unit .= '<option value=' . $unit_id . '>' . $unit_name . '</option>';
                }
            }

            $select = $select . $options . '</select>';
            $select_unit = $select_unit . $options_unit . '</select>';

            $total_vat = $total_vat + ($value->quantity * $item->vat);
            $row .= '<tr>
                        <td>' . ++$key . '</td>
                        <td class="code">' . $item->id . '</td>
                        <td>' . $select . '</td>
                        <td>' . $select_unit . '</td>
                        <td><input type="number" name="price[]"" placeholder="Price" class="form-control price" step="0.00" min="0" value="' . $value->price . '"/></td>
                        <td><input type="number" name="qty[]"" placeholder="Qty" class="form-control qty" step="0" min="0"  value="' . $value->quantity . '" />
                        </td>
                        <td class="old_qty"><input type="number" name="old_qty[]"" placeholder="Qty" class="form-control old_qty"  value="' . $value->quantity . '" />
                        </td>
                        <td class="hideStock"><input type="number" name="Stock[]"" placeholder="Stock" class="form-control stock" value="' . $value->stock . '" readonly/></td>
                        <td><input type="number" name="invCost[]"" placeholder="InvCost" class="form-control cost" value="' . $value->invcost . '"readonly/></td>
                        <td><input type="number" name="vat[]" placeholder="0.00" class="form-control vat" readonly/ value="' . $item->vat . '"></td>
                        <td><input type="number" name="total[]" placeholder="0.00" class="form-control total" readonly/ value="' . $value->total . '"></td>
                         <td class="text-center removeRow" data-flag=1 data-unit="' . $value->unit . '" data-item="' . $value->item_id . '" data-qty="' . $value->quantity . '" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 icon"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                        </td>
                    </tr>';


            $table .= $row;
            $row = '';
        }

        return response()->json(['Invoice' => $invoice, 'Table' => $table, 'Counter' => $counter, 'Vat' => $total_vat]);
    }

    public function createInvoice()
    {
        // checking permission for shop
        if (!Auth::user()->hasPermissionTo('sales')) {
            abort(401);
        }

        $page_name = $this->page;
        $products = Item::select("id", DB::raw("CONCAT('[',items.id,'] -' ,items.english_short_description) as english_short_description"))
            ->get()
            ->pluck('english_short_description', 'id')->toArray();

        $units = [];

        $customers = Customer::where('created_by', Auth::user()->shop_master_id)
            ->select("id", DB::raw("CONCAT(customers.cust_name,' [',customers.mobile,']') as full_name"))
            ->get()
            ->pluck('full_name', 'id')->toArray();

        if (Invoice::max('id')) {
            $invId = Invoice::max('id') + 1;
            $invoiceId = "Invoice #000" . $invId;
        } else {
            $invoiceId = "Invoice #001";
        }

        $itemGroup = ItemGroup::where('is_active', 1)->where('created_by', Auth::user()->shop_master_id)->pluck('english_description', 'id');
        $itemUnit = ItemUnit::where('is_active', 1)->where('created_by', Auth::user()->shop_master_id)->pluck('short_description', 'id');
        // $quantity=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('quantity','id');
        // $quantity=[];

        return view('admin.sales.sales.create_invoice', compact('page_name', 'products', 'customers', 'invoiceId', 'units', 'itemGroup', 'itemUnit'));
    }

    public function productList()
    {
        $products = Item::where('created_by', Auth::user()->shop_master_id)
            ->select('id', 'english_description', 'arabic_description')->get();
        return response()->json(['Products' => $products]);
    }

    public function getItemDetails(Request $request)
    {

        $item = ItemItemUnit::where('item_id', $request->Product)
            ->where('item_unit_id', $request->unitId)
            ->first();
        $vat = Item::where('id', $request->Product)->first()->vat;
        return response()->json(['price' => $item->price, 'cost' => $item->cost, 'stock' => $item->minimum_stock, 'vat' => $vat, 'status' => 200, 'msg' => "item found !!"]);
    }


    public function getItemUnits(Request $request)
    {

        $item = Item::where('id', $request->itemId)->first();
        // $hasPrice = $item->itemUnit()->exists();
        $units = [];

        if ($item->itemUnit()) {
            foreach ($item->itemUnit as $key => $value) {
                array_push($units, $value->pivot->item_unit_id);
            }
            $availableUnits = ItemUnit::whereIn('id', $units)->pluck('english_description', 'id')->toArray();
            return response()->json(['units' => $availableUnits, 'status' => 200, 'msg' => "item found !!"]);
        } else {
            return response()->json(['price' => 0, 'status' => 404, 'msg' => "item not found !!"]);
        }
    }

    public function getCustomerDetails(Request $request)
    {
        $customer = Customer::where('id', $request->customer_id)->first();
        return response()->json(['customer' => $customer, 'status' => 200]);
    }

    public function saveInvoice(Request $request)
    {

        $invoice = new Invoice;
        if ($request->customer) {
            $invoice->customer_id = $request->customer;
        } else {
            $customer = new Customer();
            $customer->cust_name = $request->customer_text;
            $customer->cust_type_id = 1;
            $customer->is_regular_cust = 0;
            $customer->created_by = Auth::user()->shop_master_id;
            $customer->is_active = 1;
            $customer->save();
            $invoice->customer_id = $customer->id;
            $invoice->phone_no = $request->phone_no;
        }
        $invoice->created_by = Auth::user()->shop_master_id;
        $request->has('any') ? $invoice->any = 1 : $invoice->any = 0;
        $invoice->cash_or_card = $request->cash_or_card;
        $invoice->date = $request->date;
        $invoice->cnt_no = $request->number_2;
        $invoice->po_no = $request->po_no;
        $invoice->del_no = $request->del_no;
        $invoice->remark1 = $request->remark;
        $invoice->remark2 = $request->remark2;
        $invoice->phone_no = $request->phone_no;
        $invoice->discount = $request->discount;
        $invoice->sub_total = $request->sub_total;
        $invoice->grant_total = $request->grant_total;
        $invoice->save();
        $invoice->invoice_number = "Invoice #000" . $invoice->id;
        $invoice->save();
        foreach ($request->Products as $key => $value) {
            # code...
            $invoice_details = new InvoicePurchaseDetail;
            $invoice_details->invoice_id = $invoice->id;
            $invoice_details->item_id = $value;
            $invoice_details->unit = $request->unit[$key];
            $invoice_details->quantity = $request->qty[$key];
            $invoice_details->price = $request->price[$key];
            $invoice_details->stock = $request->Stock[$key];
            $invoice_details->invcost = $request->invCost[$key];
            $invoice_details->total = $request->total[$key];
            $invoice_details->save();

            $item_unit = ItemItemUnit::where('item_id', $value)->first();
            $new_stock = $item_unit->minimum_stock - $request->qty[$key];

            // $item_unit_id = $request->unit[$key];
            // $arr[$item_unit_id] = ['minimum_stock' => $new_stock];
            // $item = Item::where('id',$value)->first();
            // $item->itemUnit()->sync($arr,false);

            DB::table('item_item_unit')->where([['item_id', $value], ['item_unit_id', $request->unit[$key]]])->update(['minimum_stock' => $new_stock]);
        }
        if ($request->btn_value == 'save & new') {
            return redirect('create-invoice');
        } else {
            return redirect()->route('view-invoice');
        }
    }

    public function editInvoice(Request $request)
    {
        $page_name = $this->page;
        $products = Item::pluck('english_short_description', 'id');
        $units = ItemUnit::pluck('english_description', 'id');
        $customers = Customer::pluck('cust_name', 'id');
        $invId = Invoice::max('id') + 1;
        $invoiceId = "Invoice #000" . $invId;
        $invoices = Invoice::pluck('invoice_number', 'id');
        return view('admin.sales.sales.edit_invoice', compact('page_name', 'products', 'units', 'customers', 'invoiceId', 'invoices'));
    }


    public function updateInvoice(Request $request)
    {
        $invoice = Invoice::where('id', $request->invoice_id)->first();
        $invoice->customer_id = $request->customers;
        $invoice->created_by = Auth::user()->shop_master_id;
        $request->has('any') ? $invoice->any = 1 : $invoice->any = 0;
        $invoice->cash_or_card = $request->cash_or_card;
        $invoice->date = $request->date;
        $invoice->cnt_no = $request->number_2;
        $invoice->po_no = $request->po_no;
        $invoice->del_no = $request->del_no;
        $invoice->remark1 = $request->remark1;
        $invoice->remark2 = $request->remark2;
        $invoice->phone_no = $request->phone_no;
        $invoice->discount = $request->discount;
        $invoice->sub_total = $request->sub_total;
        $invoice->grant_total = $request->grant_total;
        $invoice->save();


        $purchases = InvoicePurchaseDetail::where('invoice_id', $request->invoice_id)->get();
        foreach ($purchases as $key => $value) {
            $value->delete();
        }

        foreach ($request->Products as $key => $value) {
            # code...
            $invoice_details = new InvoicePurchaseDetail;
            $invoice_details->invoice_id = $invoice->id;
            $invoice_details->item_id = $value;
            $invoice_details->unit = $request->unit[$key];
            $invoice_details->quantity = $request->qty[$key];
            $invoice_details->price = $request->price[$key];
            $invoice_details->stock = $request->Stock[$key];
            $invoice_details->invcost = $request->invCost[$key];
            $invoice_details->total = $request->total[$key];
            $invoice_details->save();

            $item = Item::where('id', $value)->first();
            $item_unit = ItemItemUnit::where('item_id', $value)->first();

            if ($request->old_qty[$key] > 0) {
                if ($request->qty[$key] > $request->old_qty[$key]) {
                    $delta = $request->qty[$key] - $request->old_qty[$key];
                    $new_stock = $item_unit->minimum_stock - $delta;
                } else {
                    $delta = $request->old_qty[$key] - $request->qty[$key];
                    $new_stock = $item_unit->minimum_stock + $delta;
                }
            } else {
                $new_stock = $item_unit->minimum_stock - $request->qty[$key];
            }


            // $item_unit = ItemItemUnit::where('item_id',$value)->first();
            // $new_stock = $item_unit->minimum_stock - $request->qty[$key];

            // $item_unit_id = $request->unit[$key];
            // $arr[$item_unit_id] = ['minimum_stock' => $new_stock];
            // $item = Item::where('id',$value)->first();
            // $item->itemUnit()->sync($arr,false);

            DB::table('item_item_unit')->where([['item_id', $value], ['item_unit_id', $request->unit[$key]]])->update(['minimum_stock' => $new_stock]);

            // $item_unit_id = $request->unit[$key];
            // $arr[$item_unit_id] = ['minimum_stock' => $new_stock];
            // $item->itemUnit()->sync($arr,false);
        }

        return redirect()->route('edit-invoice');
    }


    public function removeItem(Request $request)
    {

        $item = Item::where('id', $request->itemId)->first();
        $item_unit = ItemItemUnit::where('item_id', $request->itemId)->first();
        $new_stock = $item_unit->minimum_stock + $request->qty;

        DB::table('item_item_unit')->where([['item_id', $request->itemId], ['item_unit_id', $request->unit]])->update(['minimum_stock' => $new_stock]);

        // $item_unit_id = $request->unit;
        // $arr[$item_unit_id] = ['minimum_stock' => $new_stock];
        // $item->itemUnit()->sync($arr,false);
        // return response()->json("Stock updated !!");

    }
    public function deleteInvoice(Request $request)
    {
        Invoice::where('id', $request->id)->delete();
        return response()->json("deleted");
    }

    public function purchaseHistory(Request $request)
    {

        $invoiceId = Invoice::where('customer_id', $request->customerId)->pluck('id')->toArray();
        $productHistory = InvoicePurchaseDetail::latest('created_at')->whereIn('invoice_id', $invoiceId)
            ->where('item_id', $request->Item)->get()->take(10);
        $row = '';
        foreach ($productHistory as $key => $value) {
            # code...
            $row .= '<tr>
                        <td>Invoice #000' . $value->invoice_id . '</td>
                        <td>' . $value->item_id . '</td>
                        <td>' . $value->price . '</td>
                        <td>' . $value->invcost . '</td>
                        <td>' . $value->quantity . '</td>
                        <td>' . $value->created_at . '</td>
                   </tr>';
        }

        return response()->json($row);
    }

    public function productDetails(Request $request)
    {

        $productDetails = ItemItemUnit::where('item_id', $request->Item)
            ->where('item_unit_id', $request->unit)
            ->get();

        $row = '';
        # code...
        $row .= '<tr>
                        <td>' . $productDetails[0]->cost . '</td>
                        <td>' . $productDetails[0]->price . '</td>
                        <td>' . $productDetails[0]->quantity . '</td>
                        <td>' . $productDetails[0]->minimum_stock . '</td>
                   </tr>';
        return response()->json($row);
    }

    public function saveItem(Request $request)
    {
        $request->zero_vat ? $request['zero_vat'] = 1 : $request['zero_vat'] = 0;
        $item = new Item;
        if ($files = $request->file('item_image')) {
            $validated = $request->validate([
                'image' => 'mimes:jpeg,png,jpg|max:1014',
            ]);
            $name = $files->getClientOriginalName();
            $files->move('uploads/itemimages', $name);
            $item->image = $name;
        }
        $item->item_group_id = $request->item_group_id;
        $item->english_description = $request->english_description;
        $item->arabic_description = $request->arabic_description;
        $item->arabic_short_description = $request->arabic_short_description;
        $item->english_short_description = $request->english_short_description;
        $item->vat = $request->vat;
        $item->is_vat = $request->zero_vat;
        $item->opening_stock = $request->opening_stock;
        $item->created_by = Auth::user()->shop_master_id;
        $item->save();

        $item->itemUnit()->attach($request->item_unit, ['cost' => $request->cost, 'price' => $request->price, 'minimum_stock' => $request->minimum_quantity, 'quantity' => $request->quantity]);


        return response()->json([
            'id' => $item->id,
            'item_name' => $item->english_short_description,
            'cost' => $request->cost,
            'price' => $request->price,
            'minimum_stock' => $request->minimum_quantity,
            'unit' => $request->item_unit,
            'unit_name' => ItemUnit::where('id', $request->item_unit)->where('created_by', Auth::user()->shop_master_id)->first()->english_description,
            'vat' => $request->vat,
            'status' => 200
        ]);
    }
}
