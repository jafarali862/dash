<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Model\TokenSetting;
use Illuminate\Http\Request;

class TokenSettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=[
            'page_name' => 'token_settings',
         ];
        return view('admin.master-data.settings.token-settings.index')->with($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\TokenSetting  $tokenSetting
     * @return \Illuminate\Http\Response
     */
    public function show($tokenSetting)
    {
        $settings=TokenSetting::where('created_by',Auth::user()->shop_master_id)->get();   
        return Datatables::of($settings)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($settings){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a data-target="#edit_token_settings" data-toggle="modal" style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-token_id="'.$settings->id.'" data-token_start_no="'.$settings->token_start_no.'" data-status="'.$settings->is_active.'" data-start_time="'.$settings->start_time.'" data-end_time="'.$settings->end_time.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-token_id="'.$settings->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($settings)
                {
                 return $settings->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$settings->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$settings->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($settings) {
                     return $settings->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    public function destroy(TokenSetting $tokenSetting)
    {
        $tokenSetting->delete();
        return response()->json("deleted");
    }

    public function tokenSave(Request $request)
    {
        $tokendata = new TokenSetting();
        $tokendata->token_start_no=$request->token_start_no;
        $tokendata->start_time=$request->start_time;
        $tokendata->end_time=$request->end_time;
        $tokendata->created_by=Auth::user()->shop_master_id;
        $tokendata->save();
        return response()->json(['status'=>200]);
    }
    public function updateTokenSettings(Request $request)
    {
        $tokendata = TokenSetting::where('id', $request->edit_token_id)->first();
        $tokendata->token_start_no=$request->token_start_no;
        $tokendata->start_time=$request->start_time;
        $tokendata->end_time=$request->end_time;
        $tokendata->is_active = $request->status;
        $tokendata->created_by=Auth::user()->shop_master_id;
        $tokendata->save();
        return response()->json(['status'=>200]); 
    }
    public function statusChange(Request $request)
    {
        $response=TokenSetting::where('id', $request->token_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
}
