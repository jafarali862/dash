<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Model\Ingredient;
use Illuminate\Http\Request;

class IngredientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=[
            'page_name' => 'ingredient',
         ];
        return view('admin.master-data.settings.ingredients.index')->with($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Ingredient  $ingredient
     * @return \Illuminate\Http\Response
     */
    public function show($ingredient)
    {
        $ingredients=Ingredient::where('created_by',Auth::user()->shop_master_id)->get();   
        return Datatables::of($ingredients)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($ingredients){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a data-target="#edit_ingredient_pop_up" data-toggle="modal" style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-ingredient_id="'.$ingredients->id.'" data-ingredient="'.$ingredients->ingredient.'" data-status="'.$ingredients->is_active.'" data-min_stock="'.$ingredients->min_stock.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-ingredient_id="'.$ingredients->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($ingredients)
                {
                 return $ingredients->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$ingredients->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$ingredients->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
        //serves to distinguish the inactive & active records
 
        // this is used to show inactive records in a disabled manner
         ->setRowClass(function($ingredients) {
                     return $ingredients->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Ingredient  $ingredient
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ingredient $ingredient)
    {
        $ingredient->delete();
        return response()->json("deleted");
    }

    public function statusChange(Request $request)
    {
        $response=Ingredient::where('id', $request->ingredient_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
    }

    public function ingredientSave(Request $request)
    {
        $ingredient = new Ingredient();
        $ingredient->ingredient=$request->ingredient_name;
        $ingredient->min_stock=$request->min_stock;
        $ingredient->created_by=Auth::user()->shop_master_id;
        $ingredient->save();
        return response()->json(['status'=>200]); 
    }

    public function updateIngredient(Request $request)
    {
        $ingredient = Ingredient::where('id', $request->ingredient_id)->first();
        $ingredient->ingredient=$request->ingredient_name;
        $ingredient->min_stock=$request->min_stock;
        $ingredient->is_active = $request->status;
        $ingredient->created_by=Auth::user()->shop_master_id;
        $ingredient->save();
        return response()->json(['status'=>200]); 
    }
}
