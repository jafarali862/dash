<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Model\OrderType;
use Illuminate\Http\Request;

class OrderTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=[
            'page_name' => 'order_type',
         ];
        return view('admin.master-data.settings.order-type.index')->with($data);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\OrderType  $orderType
     * @return \Illuminate\Http\Response
     */
    public function show($orderType)
    {
        $order_type=OrderType::where('created_by',Auth::user()->shop_master_id)->get();   
        return Datatables::of($order_type)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($order_type){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a data-target="#edit_order_type_modal" data-toggle="modal" style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-order_type_id="'.$order_type->id.'" data-order_type="'.$order_type->order_type.'" data-status="'.$order_type->is_active.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-order_type_id="'.$order_type->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($order_type)
                {
                 return $order_type->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$order_type->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$order_type->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($order_type) {
                     return $order_type->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\OrderType  $orderType
     * @return \Illuminate\Http\Response
     */
    public function destroy(OrderType $orderType)
    {
        $orderType->delete();
        return response()->json("deleted");
    }
    public function orderTypeSave(Request $request)
    {
        $order_type = new OrderType();
        $order_type->order_type=$request->order_type;
        $order_type->created_by=Auth::user()->shop_master_id;
        $order_type->save();
        return response()->json(['status'=>200]); 
    }

    public function updateorderType(Request $request)
    {
        $order_type = OrderType::where('id', $request->order_type_id)->first();
        $order_type->order_type=$request->order_type;
        $order_type->is_active = $request->status;
        $order_type->created_by=Auth::user()->shop_master_id;
        $order_type->save();
        return response()->json(['status'=>200]); 
    }

    public function statusChange(Request $request)
    {
        $response=OrderType::where('id', $request->order_type_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
}
