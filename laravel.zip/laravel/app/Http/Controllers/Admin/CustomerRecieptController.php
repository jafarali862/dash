<?php

namespace App\Http\Controllers\Admin;

use App\Model\Customer;
use App\Model\CustomerReciept;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class CustomerRecieptController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = Customer::select("id", DB::raw("CONCAT(customers.cust_name,' [',customers.mobile,']') as full_name"))
        ->get()
        ->pluck('full_name', 'id')->toArray();
         $data=[
            'page_name' => 'customer_reciept',
            'customer' => $customers
         ];
         return view('admin.sales.customer-reciept.create')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\CustomerReciept  $customerReciept
     * @return \Illuminate\Http\Response
     */
    public function show(CustomerReciept $customerReciept)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\CustomerReciept  $customerReciept
     * @return \Illuminate\Http\Response
     */
    public function edit(CustomerReciept $customerReciept)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\CustomerReciept  $customerReciept
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CustomerReciept $customerReciept)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\CustomerReciept  $customerReciept
     * @return \Illuminate\Http\Response
     */
    public function destroy(CustomerReciept $customerReciept)
    {
        //
    }
}
