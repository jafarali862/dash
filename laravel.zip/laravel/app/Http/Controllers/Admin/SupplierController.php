<?php

namespace App\Http\Controllers\Admin;


use Auth;
use Session;
use App\Model\Supplier;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;


class SupplierController extends Controller
{
   
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $data=[
            'page_name' => 'supplier',
         ];
         return view('admin.master-data.supplier.index')->with($data);
    }

   
    public function create()
    {
        $data=[
            'page_name' => 'supplier',
         ];
         return view('admin.master-data.supplier.create')->with($data);
    }

   
    public function store(Request $request)
    {
            $supplier=new Supplier();
            $supplier->name=$request->name;
            $supplier->arabic_desptn=$request->english_desptn;
            $supplier->eng_address=$request->eng_address;
            $supplier->arab_address=$request->eng_address;
            $supplier->email=$request->email;
            $supplier->phone=$request->phone;
            $supplier->mobile=$request->mobile;
            $supplier->fax=$request->fax;
            $supplier->cost_center=$request->cost_center;
            $supplier->credit_limit=$request->credit_limit;
            $supplier->customer_link=$request->customer_link;
            $supplier->vat_no=$request->vat_no;
            $supplier->pmt_type=0;
            $supplier->supplier_type_id=1;
            $supplier->supplier_ref='not specified';
            $supplier->is_active=1;
            $supplier->created_by=Auth::user()->shop_master_id;
            $supplier->save();
            Session::flash('success','Supplier created successfully!..');
            $notification = array(
                'message' => 'Supplier created successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('supplier.index')->with($notification);
        }else{
            return redirect()->route('supplier.create')->with($notification);
        }
    }

    
    public function show($supplier)
    {
        $supplier=Supplier::where('created_by',Auth::user()->shop_master_id)->get();   
        return Datatables::of($supplier)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($supplier){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  href="'.route('supplier.edit', $supplier->id).'" data-supplier_id="'.$supplier->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-supplier_id="'.$supplier->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($supplier)
                {
                 return $supplier->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$supplier->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$supplier->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($supplier) {
                     return $supplier->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

   
    public function edit($supplier_id)
    {
        $supplier=Supplier::findOrFail($supplier_id);
        $data=[
            'page_name' => 'supplier',
            'supplier' => $supplier
            ];
       
        return view('admin.master-data.supplier.edit')->with($data);
    }

    
    public function update(Request $request, Supplier $supplier)
    {
            $supplier->name=$request->name;
            $supplier->arabic_desptn=$request->english_desptn;
            $supplier->eng_address=$request->eng_address;
            $supplier->arab_address=$request->eng_address;
            $supplier->phone=$request->phone;
            $supplier->mobile=$request->mobile;
            $supplier->fax=$request->fax;
            $supplier->email=$request->email;
            $supplier->cost_center=$request->cost_center;
            $supplier->credit_limit=$request->credit_limit;
            $supplier->customer_link=$request->customer_link;
            $supplier->vat_no=$request->vat_no;
            $supplier->pmt_type=0;
            $supplier->supplier_type_id=1;
            $supplier->supplier_ref='not specified';
            $supplier->is_active=$request->status;
            $supplier->created_by=Auth::user()->shop_master_id;
            $supplier->update();
            Session::flash('success','Supplier updated successfully!..');
            $notification = array(
                'message' => 'Supplier updated successfully!..',
                'alert-type' => 'success'
            );
        return redirect()->route('supplier.index');
    }

    
    public function destroy(Supplier $supplier)
    {
        $supplier->delete();
        return response()->json("deleted");
    }
    public function statusChange(Request $request)
    {
        $response=Supplier::where('id', $request->supplierid)->update(array('status' => $request->val));
        return response()->json($response); 
        
    }
}
