<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\CostCenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class CostCenterController extends Controller
{
    
    public function index()
    {
        
        $data=[
            'page_name' => 'cost_center',
         ];
         return view('admin.master-data.cost-center.index')->with($data);
    }

    
    public function create()
    {
        $data=[
            'page_name' => 'cost_center',
         ];
         return view('admin.master-data.cost-center.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $costcenter=new CostCenter();
            $costcenter->name=$request->name;
            $costcenter->created_by=Auth::user()->shop_master_id;
            $costcenter->save();
            Session::flash('success','Cost Center created successfully!..');
            $notification = array(
                'message' => 'Cost Center created successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('cost-center.index')->with($notification);
        }else{
            return redirect()->route('cost-center.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function show($cost)
    {
        $costcenter=CostCenter::where('created_by',Auth::user()->shop_master_id)->get();
        return Datatables::of($costcenter)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($costcenter){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-cost_center_id="'.$costcenter->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-cost_center_id="'.$costcenter->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($costcenter)
                {
                 return $costcenter->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$costcenter->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$costcenter->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
        
           //serves to distinguish the inactive & active records
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($costcenter) {
                     return $costcenter->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function edit(CostCenter $costCenter)
    {

        $data=[
            'page_name' => 'cost_center',
            'edit_cost_center' => $costCenter
            ];
     
        return view('admin.master-data.cost-center.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CostCenter $costCenter)
    {
       
        $costCenter->name=$request->name;
        $costCenter->created_by=Auth::user()->shop_master_id;
        $costCenter->is_active=$request->status;
        $costCenter->update();
        Session::flash('success','Cost Center updated successfully!..');
        $notification = array(
            'message' => 'Cost Center updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('cost-center.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function destroy(CostCenter $costCenter)
    {
        $costCenter->delete();
        return response()->json("deleted");
    }
    public function statusChange(Request $request)
    {
        
        $response=CostCenter::where('id', $request->costcenter_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
  
}



