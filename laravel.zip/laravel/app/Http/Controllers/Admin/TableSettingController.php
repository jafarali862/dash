<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Model\TableSetting;
use Illuminate\Http\Request;

class TableSettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=[
            'page_name' => 'table_settings',
         ];
        return view('admin.master-data.settings.table-settings.index')->with($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TableSetting  $tableSetting
     * @return \Illuminate\Http\Response
     */
    public function show($tableSetting)
    {
        $settings=TableSetting::where('created_by',Auth::user()->shop_master_id)->get();   
        return Datatables::of($settings)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($settings){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a data-target="#edit_table_settings" data-toggle="modal" style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-table_id="'.$settings->id.'" data-table_name="'.$settings->table_name.'" data-status="'.$settings->is_active.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-table_id="'.$settings->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($settings)
                {
                 return $settings->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$settings->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$settings->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($settings) {
                     return $settings->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    public function destroy(TableSetting $tableSetting)
    {
        $tableSetting->delete();
        return response()->json("deleted");
    }
    public function tableSave(Request $request)
    {
        $tabledata = new TableSetting();
        $tabledata->table_name=$request->table_name;
        $tabledata->created_by=Auth::user()->shop_master_id;
        $tabledata->save();
        return response()->json(['status'=>200]); 
    }
    public function updateTableSettings(Request $request)
    {
        $tabledata = TableSetting::where('id', $request->table_id)->first();
        $tabledata->table_name = $request->table_name;
        $tabledata->is_active = $request->status;
        $tabledata->created_by = Auth::user()->shop_master_id;
        $tabledata->save();
        return response()->json(['status'=>200]); 
    }
    public function statusChange(Request $request)
    {
        $response=TableSetting::where('id', $request->table_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
}
