<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\CostCenter;
use App\Model\Supplier;
use App\Model\AreaCode;
use App\Model\SalesMan;
use App\Model\Cash;
use App\Model\Bank;
use App\Model\AccountType;
use App\Model\Account;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class BankAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  public function index($type = 'cash')
    {
        if(!$this->isPayment($type)) return redirect('/');
        return view('admin.accounts.transaction.index');
    }

  public function isPayment($value)
    {
        return $value == 'cash' || $value == 'bank' || $value == 'cash-reciept' || $value == 'bank-pament' || $value == 'journal-entry';
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
         $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
          $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
           $bankcode = Bank::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
      

        if(Cash::max('id'))
        {
            $custId = Cash::max('id') + 1;
            $customerId = "#".$custId;
        }
        else{
            $customerId = "#1000";
        }

       $data=[
            'page_name' => 'bank_account',
            'cust_id' => $customerId,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
             'bankcode' => $bankcode,
            'supplier' => $supplier
         ];
        return view('admin.accounts.bank-payment.create_bank')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cash = new Cash();
        $cash->type = 'bank';
        $cash->doc_date = $request->doc_date;
        $cash->amount = $request->amount;
        $cash->remarks = $request->remarks;
        $cash->cheque_no = $request->cheque_no;
        $cash->account_id = $request->account_id;
        $cash->user_id = $request->user_id;
        $cash->description = $request->description;
        $cash->bank_id = $request->bank_id;
        $cash->created_by = Auth::user()->shop_master_id;
        $cash->is_active = 1;
        $cash->save();

        Session::flash('success','BankRecepits data created successfully!..');
        $notification = array(
        'message' => 'BankRecepits data created successfully!..',
        'alert-type' => 'success'
        );
        if($request->save_only == "save_only")
            return redirect()->route('bank-account.index')->with($notification);
        else
            return redirect()->route('bank-account.create')->with($notification);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show($cash)
    {
      $cash=Cash::where('created_by',Auth::user()->shop_master_id)->get();
        
        return Datatables::of($cash)
        // adding the edit button to each rows
      ->addColumn('action_button', function ($cash){
         return '<div class="btn-group">
                     <button type="button" class="btn btn-dark btn-sm">Open</button>
                     <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                     </button>
                     <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                       <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-customer_id="'.$cash->id.'">Edit</a>
                       <div class="dropdown-divider"></div>
                       <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-customer_id="'.$cash->id.'">Delete</a>
                     </div>
                 </div>';
     })
     ->editColumn('status', function($cash)
            {
             return $cash->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                 <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$cash->id.')">
                                                 <span class="slider"></span>
                                             </label>' : '<label class="switch s-outline s-outline-success">
                                                 <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$cash->id.')">
                                                 <span class="slider"></span>
                                             </label>';
            })

       //serves to distinguish the inactive & active records

     //   // this is used to show inactive records in a disabled manner
     ->setRowClass(function($cash) {
                 return $cash->is_active==1?'':'bgdisable';
                  })

      // converts the raw html tags to real button entities
      ->rawColumns(['action_button','status'])
      ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function edit($cash)
    {
       $cash = Cash::where('id',$cash)->first();
        $areacode = AreaCode::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('area_code','id');
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');   
         $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
          $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
           $bankcode = Bank::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');

        $data=[
            'page_name' => 'bank_account',
            'edit_customer' => $cash,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
            'bankcode' => $bankcode,
            'supplier' => $supplier
            
            ];
       
        return view('admin.accounts.bank-payment.create_bank')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$cash)
    {
        $cash = Cash::find($cash);
        $cash->doc_date=$request->doc_date;
        $cash->amount=$request->amount;
        $cash->remarks=$request->remarks;
        $cash->cheque_no=$request->cheque_no;
       $cash->account_id=$request->account_id;
        $cash->user_id=$request->user_id;
       $cash->description=$request->description;
        $cash->bank_id=$request->bank_id;
       $cash->created_by=Auth::user()->shop_master_id;
        // $shop_customer->is_active=$request->status;
       $cash->update();

        Session::flash('success','Deposit data updated successfully!..');
        $notification = array(
        'message' => 'Deposit  data updated successfully!..',
        'alert-type' => 'success'
        );
        return redirect()->route('bank-account.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy($cash)
    {
        $cash = Cash::where('id',$cash);
         $cash->delete();
        return response()->json("deleted");
    }

     public function statusChange(Request $request)
    {
        $response=Cash::where('id', $request->customerid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }
    public function cashSave(Request $request)
    {
           $cash=new Cash();
              $cash->doc_date=$request->doc_date;     
            $cash->amount=$request->amount;
            $cash->remarks=$request->remarks;
              $cash->cheque_no=$request->cheque_no;      
            $cash->account_id=$request->account_id;
           $cash->user_id=$request->user_id;
           $cash->description=$request->description;
            $cash->bank_id=$request->bank_id;
            $cash->created_by=Auth::user()->shop_master_id;
            $cash->save();
            return response()->json(['id'=> $cash->id,'remarks'=> $cash->remarks,'description'=> $cash->description,'status'=>200]); 
    }
}
