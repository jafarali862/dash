<?php

namespace App\Http\Controllers\Admin;

use App\Model\Item;
use App\Model\ItemGroup;
use App\Model\ItemUnit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use Carbon\Carbon;
use Session;

class ItemController extends Controller
{
    protected $pos = 'item';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $page_name = $this->pos;

        return view('admin.master-data.item.index', compact('page_name'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $page_name = $this->pos;

        $itemGroup=ItemGroup::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_description','id');
        $itemUnit=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('short_description','id');
        // $quantity=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('quantity','id');

        return view('admin.master-data.item.create', compact('page_name','itemGroup','itemUnit'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->zero_vat ? $request['zero_vat']= 1 : $request['zero_vat']=0; 
        $item = new Item;
        if ($files=$request->file('item_image')) {
            $validated = $request->validate([
                    'image' => 'mimes:jpeg,png,jpg|max:1014',
            ]);
            $name=$files->getClientOriginalName();  
            $files->move('uploads/itemimages',$name); 
            $item->image=$name; 
        }
        $item->item_group_id = $request->item_group_id;
        $item->english_description = $request->english_description;
        $item->arabic_description = $request->arabic_description;
        $item->arabic_short_description = $request->arabic_short_description;
        $item->english_short_description = $request->english_short_description;
        $item->vat = $request->vat;
        $item->is_vat = $request->zero_vat;
        $item->opening_stock = $request->opening_stock;
        $item->created_by = Auth::user()->shop_master_id;
        $item->save();

        foreach ($request->item_unit as $key => $value) {
             $item->itemUnit()->attach($value, ['cost'=> $request->cost[$key] , 'price' => $request->price[$key],'quantity' => $request->quantity[$key], 'minimum_stock' => $request->minimum_quantity[$key]]);
        }
       

        $request->session()->flash('message', 'New Item Created Successfully');
        
        if($request->save_only == "save_only")
        {
            return redirect()->route('items.index'); 
        }else{
            return redirect()->route('items.create');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function show($item)
    {
         $item=Item::with('itemUnit','itemGroup')->where('created_by',Auth::user()->shop_master_id)->get();   

       return Datatables::of($item)
           // adding the edit button to each rows
       ->addColumn('action_button', function ($item){
            return '<div class="btn-group">
                        <button type="button" class="btn btn-dark btn-sm">Open</button>
                        <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                          <a style="color:green;" class="dropdown-item btnEdit" href="'.route('items.edit', $item->id).'">Edit</a>
                          <div class="dropdown-divider"></div>
                                <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-item_id="'.$item->id.'">Delete</a>
                            </div>
                        </div>';
        })
        ->editColumn('is_active', function($item)
               {
                return $item->is_active?' <label class="switch  s-outline  s-outline-success">
                                                    <input type="checkbox" class="changeStatus" checked onclick="changeStatus('.$item->id.',true)">
                                                    <span class="slider"></span>
                                                </label>' : '<label class="switch s-outline s-outline-success">
                                                    <input type="checkbox" class="changeStatus" onclick="changeStatus('.$item->id.',false)">
                                                    <span class="slider"></span>
                                                </label>';
               })

        ->addColumn('image', function ($item) {
                    
                     return '<img width="60px;" src="'.asset("uploads/itemimages/$item->image").'"">';
                    })
        ->addColumn('english_description', function ($item) {
                     return $item->english_short_description;
                    })
        ->addColumn('item_group_id', function ($item) {
                     $unit=$item->itemGroup->first();
                     return $unit->english_description;
                    })
        ->addColumn('cost', function ($item) {
                     $unit=$item->itemUnit->first();
                     return $unit->pivot->cost;
                    })
        ->addColumn('minimum_stock', function ($item) {
                     $unit=$item->itemUnit->first();
                     return $unit->pivot->minimum_stock;
                    })
          //serves to distinguish the inactive & active records

        //   // this is used to show inactive records in a disabled manner
        ->setRowClass(function($item) {
                    return $item->is_active?'':'bgdisable';
                     })

         // converts the raw html tags to real button entities
         ->rawColumns(['action_button','is_active','image'])
         ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function edit(Item $item)
    {
        $page_name = $this->pos;

        $itemGroup=ItemGroup::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_description','id');
        $itemUnit=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('short_description','id');
        // $quantity=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('quantity','id');

        $selectUnit= $item->itemUnit;
        // dd($selectUnit);

        return view('admin.master-data.item.edit', compact('page_name','item','itemGroup','itemUnit','selectUnit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Item $item)
    {
  
        $request->zero_vat ? $request['zero_vat']= 1 : $request['zero_vat']=0; 
         if($files=$request->file('item_image')) {
            $name=$files->getClientOriginalName();  
            $files->move('uploads/itemimages',$name); 

            $item->image=$name; 
        }else{
            $item->image = $request->image; 
        }
        $item->item_group_id = $request->item_group_id;
        $item->english_description = $request->english_description;
        $item->arabic_description = $request->arabic_description;
        $item->arabic_short_description = $request->arabic_short_description;
        $item->english_short_description = $request->english_short_description;
        $item->vat = $request->vat;
        $item->is_vat = $request->zero_vat;
        $item->opening_stock = $request->opening_stock;
        $item->update();
       
        $item->itemUnit()->detach();

        foreach ($request->item_unit as $key => $value) {
             $id_array[$value] = ['cost'=> $request->cost[$key] , 'price' => $request->price[$key],'quantity' => $request->quantity[$key], 'minimum_stock' => $request->minimum_quantity[$key]];

             $item->itemUnit()->sync($id_array,false);
        }

        

        $request->session()->flash('message', 'Update Successfully !!');

        return redirect()->route('items.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function destroy(Item $item)
    {
        $item->delete();

        return response()->json("deleted");
    }


    // Status change
    public function statusChangeItems(Request $request)
    {
        if($request->status == 'true'){
            $item = Item::find($request->id);
            $item->is_active = 0;
            $item->update();
        }else{
            $item = Item::find($request->id);
            $item->is_active = 1;
            $item->update(); 
        }
        return response()->json('success',200);
    }
}
