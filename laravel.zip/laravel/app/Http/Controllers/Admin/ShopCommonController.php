<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ShopCommonController extends Controller
{
    public function shopDashBoard()
    {
         $data = [
            'page_name' => 'shopDashboard',
        ];

        return view('dashboard')->with($data);
    }
}
