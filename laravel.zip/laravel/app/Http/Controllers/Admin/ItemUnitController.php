<?php

namespace App\Http\Controllers\Admin;

use App\Model\ItemUnit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use Carbon\Carbon;
use Session;

class ItemUnitController extends Controller
{
    protected $pos = 'itemUnit';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $page_name = $this->pos;

        return view('admin.master-data.item-unit.index', compact('page_name'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $page_name = $this->pos;

        return view('admin.master-data.item-unit.create', compact('page_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $item_unit = ItemUnit::create($request->all());

        $request->session()->flash('message', 'New Record Created Successfully');

        if($request->save_only == "save_only")
        {
            return redirect()->route('item-units.index');
        }else{
            return redirect()->route('item-units.create');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\ItemUnit  $itemUnit
     * @return \Illuminate\Http\Response
     */
    public function show($itemUnit)
    {
        $item_unit=ItemUnit::where('created_by',Auth::user()->shop_master_id)->get();   

       return Datatables::of($item_unit)
           // adding the edit button to each rows
       ->addColumn('action_button', function ($item_unit){
            return '<div class="btn-group">
                        <button type="button" class="btn btn-dark btn-sm">Open</button>
                        <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                          <a style="color:green;" class="dropdown-item btnEdit" href="'.route('item-units.edit', $item_unit->id).'">Edit</a>
                          <div class="dropdown-divider"></div>
                                <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-item_unit_id="'.$item_unit->id.'">Delete</a>
                            </div>
                        </div>';
        })
        ->editColumn('is_active', function($item_unit)
               {
                return $item_unit->is_active?' <label class="switch  s-outline  s-outline-success">
                                                    <input type="checkbox" class="changeStatus" checked onclick="changeStatus('.$item_unit->id.',true)">
                                                    <span class="slider"></span>
                                                </label>' : '<label class="switch s-outline s-outline-success">
                                                    <input type="checkbox" class="changeStatus" onclick="changeStatus('.$item_unit->id.',false)">
                                                    <span class="slider"></span>
                                                </label>';
               })

          //serves to distinguish the inactive & active records

        //   // this is used to show inactive records in a disabled manner
        ->setRowClass(function($item_unit) {
                    return $item_unit->is_active?'':'bgdisable';
                     })

         // converts the raw html tags to real button entities
         ->rawColumns(['action_button','is_active'])
         ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\ItemUnit  $itemUnit
     * @return \Illuminate\Http\Response
     */
    public function edit(ItemUnit $itemUnit)
    {
        $page_name = $this->pos;

        return view('admin.master-data.item-unit.edit', compact('page_name','itemUnit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\ItemUnit  $itemUnit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ItemUnit $itemUnit)
    {
        // $request->is_active ? $request['is_active']= 1 : $request['is_active']=0;
        
        $itemUnit->update($request->all());

        $request->session()->flash('message', 'Update Successfully !!');

        return redirect()->route('item-units.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\ItemUnit  $itemUnit
     * @return \Illuminate\Http\Response
     */
    public function destroy(ItemUnit $itemUnit)
    {
        $itemUnit->delete();

        return response()->json("deleted");
    }

    // Status change
    public function statusChangeItemUnit(Request $request)
    {
        if($request->status == 'true'){
            $item = ItemUnit::find($request->id);
            $item->is_active = 0;
            $item->update();
        }else{
            $item = ItemUnit::find($request->id);
            $item->is_active = 1;
            $item->update(); 
        }
        return response()->json('success',200);
    }
    
}
