<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use App\Model\AccountType;
use App\Model\SubAccountType;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class SubAccountTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $data=[
            'page_name' => 'sub-account-type',
         ];
         return view('admin.master-data.sub-account-type.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $account_type=AccountType::where('created_by',Auth::user()->shop_master_id)
                           ->where('is_active','!=',0)
                           ->get(); 
        $data=[
            'page_name' => 'sub-account-type',
            'account_type' => $account_type
         ];
         return view('admin.master-data.sub-account-type.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $subaccnttype=new SubAccountType();
            $subaccnttype->accnt_type_id=$request->account_type_id;
            $subaccnttype->sub_accnt_name=$request->sub_account_name;
            $subaccnttype->created_by=Auth::user()->shop_master_id;
            $subaccnttype->is_active=1;
            $subaccnttype->save();
            Session::flash('success','Sub account type created successfully!..');
            $notification = array(
                'message' => 'Sub account type created successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('sub-account-type.index')->with($notification);
        }else{
            return redirect()->route('sub-account-type.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\SubAccountType  $subAccountType
     * @return \Illuminate\Http\Response
     */
    public function show($subAccountType)
    {
        $subAccountType = SubAccountType::leftJoin('account_types', function($join) {
             $join->on('account_type_subs.accnt_type_id', '=', 'account_types.id');
             })
             ->where('account_type_subs.created_by',Auth::user()->shop_master_id)
             ->select('account_type_subs.id','account_type_subs.accnt_type_id' ,'account_type_subs.sub_accnt_name','account_type_subs.created_by','account_types.english_desptn','account_type_subs.is_active')
             ->get(); 
        return Datatables::of($subAccountType)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($subAccountType){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-sub_account_type_id="'.$subAccountType->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-sub_account_type_id="'.$subAccountType->id.'">Delete</a>
                         </div>
                     </div>';
         })
          ->editColumn('status', function($subAccountType)
                {
                 return $subAccountType->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$subAccountType->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$subAccountType->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
          ->addColumn('sub_account_type', function ($subAccountType) {
                     return $subAccountType->english_desptn;;
                    })
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($subAccountType) {
                     return $subAccountType->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\SubAccountType  $subAccountType
     * @return \Illuminate\Http\Response
     */
    public function edit(SubAccountType $subAccountType)
    {
        $sub_account_type=SubAccountType::where('created_by',Auth::user()->shop_master_id)->get();
        $account_type=AccountType::where('created_by',Auth::user()->shop_master_id)->get(); 
        $data=[
            'page_name' => 'sub-account-type',
            'edit_sub_account_type' => $subAccountType,
            'account_type' => $account_type
            ];
       
        return view('admin.master-data.sub-account-type.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\SubAccountType  $subAccountType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubAccountType $subAccountType)
    {
        $subAccountType->accnt_type_id=$request->accnt_type_id;
        $subAccountType->sub_accnt_name=$request->sub_account_name;
        $subAccountType->created_by=Auth::user()->shop_master_id;
        $subAccountType->is_active=$request->status;
        $subAccountType->update();
        Session::flash('success','Sub account type updated successfully!..');
        $notification = array(
            'message' => 'Sub account type updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('sub-account-type.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\SubAccountType  $subAccountType
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubAccountType $subAccountType)
    {
        $subAccountType->delete();
        return response()->json("deleted");
    }
    public function statusChange(Request $request)
    {
        $response=SubAccountType::where('id', $request->subaccounttypeid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }
}
