<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Model\SalesMan;


class SalesManController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $data=[
            'page_name' => 'sales_man',
         ];
         return view('admin.master-data.sales-man.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $data=[
            'page_name' => 'sales_man',
         ];
         return view('admin.master-data.sales-man.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $salesman=new SalesMan();
            $salesman->name=$request->name;
            $salesman->address=$request->address;
            $salesman->created_by=Auth::user()->shop_master_id;
            $salesman->save();
            Session::flash('success','Sales Man created successfully!..');
            $notification = array(
                'message' => 'Sales Man created successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('sales-man.index')->with($notification);
        }else{
            return redirect()->route('sales-man.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SalesMan  $salesMan
     * @return \Illuminate\Http\Response
     */
    public function show($salesMan)
    {
        $salesman=SalesMan::where('created_by',Auth::user()->shop_master_id)->get();
        return Datatables::of($salesman)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($salesman){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-sales_man_id="'.$salesman->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-sales_man_id="'.$salesman->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($salesman)
                {
                 return $salesman->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$salesman->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$salesman->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
        
           //serves to distinguish the inactive & active records
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($salesman) {
                     return $salesman->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SalesMan  $salesMan
     * @return \Illuminate\Http\Response
     */
    public function edit(SalesMan $salesMan)
    {
        $data=[
            'page_name' => 'sales_man',
            'edit_sales_man' => $salesMan
         ];
         return view('admin.master-data.sales-man.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SalesMan  $salesMan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SalesMan $salesMan)
    {
        $salesMan->name=$request->name;
        $salesMan->address=$request->address;
        $salesMan->created_by=Auth::user()->shop_master_id;
        $salesMan->is_active=$request->status;
        $salesMan->update();
        Session::flash('success','Sales Man updated successfully!..');
        $notification = array(
            'message' => 'Sales Man updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('sales-man.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SalesMan  $salesMan
     * @return \Illuminate\Http\Response
     */
    public function destroy(SalesMan $salesMan)
    {
        $salesMan->delete();
        return response()->json("deleted");
    }
    public function statusChange(Request $request)
    {
        
        $response=SalesMan::where('id', $request->salesman_id)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
}
