<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\CostCenter;
use App\Model\Supplier;
use App\Model\AreaCode;
use App\Model\SalesMan;
use App\Model\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $data=[
            'page_name' => 'shop_customers',
         ];
        return view('admin.master-data.shop-customer.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $saleaman = SalesMan::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $areacode = AreaCode::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('area_code','id');
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');

        if(Customer::max('id'))
        {
            $custId = Customer::max('id') + 1;
            $customerId = "#".$custId;
        }
        else{
            $customerId = "#1000";
        }

       $data=[
            'page_name' => 'shop_customers',
            'cust_id' => $customerId,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
            'supplier' => $supplier
         ];
        return view('admin.master-data.shop-customer.create_customer')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $Customer=new Customer();
            $Customer->cust_name=$request->cust_name;
            $Customer->cust_type_id=1;
            $Customer->english_addrs=$request->english_addrs;
            $Customer->mobile=$request->mobile;
            $Customer->fax=$request->fax;
            $Customer->email=$request->email;
            $Customer->own_code=$request->own_code;
            $Customer->sales_man_id=$request->sales_man_id;
            $Customer->cost_center_id=$request->cost_center_id;
            $Customer->credit_limit=$request->credit_limit;
            $Customer->supplier_id=$request->supplier_id;
            $Customer->vist_date=$request->vist_day;
            $Customer->vat_no=$request->vat_no;
            $Customer->is_regular_cust = 1;
            $Customer->area_code_id=$request->area_code_id;
            $Customer->created_by=Auth::user()->shop_master_id;
            $Customer->is_active=1;
            $Customer->save();

            Session::flash('success','Customer data created successfully!..');
            $notification = array(
                'message' => 'Customer data created successfully!..',
                'alert-type' => 'success'
            );
            if($request->save_only == "save_only")
            {
              return redirect()->route('shop-customer.index')->with($notification);
           }
           else
           { 
               return redirect()->route('shop-customer.create')->with($notification);

            }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show($customer)
    {
       $customer=Customer::where('created_by',Auth::user()->shop_master_id)->get();
        
        return Datatables::of($customer)
        // adding the edit button to each rows
      ->addColumn('action_button', function ($customer){
         return '<div class="btn-group">
                     <button type="button" class="btn btn-dark btn-sm">Open</button>
                     <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                     </button>
                     <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                       <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-customer_id="'.$customer->id.'">Edit</a>
                       <div class="dropdown-divider"></div>
                       <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-customer_id="'.$customer->id.'">Delete</a>
                     </div>
                 </div>';
     })
     ->editColumn('status', function($customer)
            {
             return $customer->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                 <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$customer->id.')">
                                                 <span class="slider"></span>
                                             </label>' : '<label class="switch s-outline s-outline-success">
                                                 <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$customer->id.')">
                                                 <span class="slider"></span>
                                             </label>';
            })

       //serves to distinguish the inactive & active records

     //   // this is used to show inactive records in a disabled manner
     ->setRowClass(function($customer) {
                 return $customer->is_active==1?'':'bgdisable';
                  })

      // converts the raw html tags to real button entities
      ->rawColumns(['action_button','status'])
      ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer $shop_customer)
    {
        $saleaman = SalesMan::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $areacode = AreaCode::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('area_code','id');
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');

        $data=[
            'page_name' => 'shop_customers',
            'edit_customer' => $shop_customer,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
            'supplier' => $supplier
            
            ];
       
        return view('admin.master-data.shop-customer.edit_customer')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Customer $shop_customer)
    {
        $shop_customer->cust_name=$request->cust_name;
        $shop_customer->english_short_desptn=$request->english_desptn;
        $shop_customer->arabic_short_desptn=$request->english_desptn;
        $shop_customer->english_addrs=$request->english_addrs;
        $shop_customer->arabic_addrs=$request->english_addrs;
        $shop_customer->mobile=$request->mobile;
        $shop_customer->fax=$request->fax;
        $shop_customer->email =$request->email ;
        $shop_customer->vat_no=$request->vat_no;
        $shop_customer->own_code=$request->own_code;
        $shop_customer->sales_man_id=$request->sales_man_id;
        $shop_customer->cost_center_id=$request->cost_center_id;
        $shop_customer->credit_limit=$request->credit_limit;
        $shop_customer->supplier_id=$request->supplier_id;
        $Customer->is_regular_cust = $request->is_regular_cust;
        $shop_customer->vist_date=$request->vist_day;
        $shop_customer->created_by=Auth::user()->shop_master_id;
        $shop_customer->is_active=$request->status;
        $shop_customer->area_code_id=$request->area_code_id;
        $shop_customer->update();

        Session::flash('success','Customer data updated successfully!..');
        $notification = array(
            'message' => 'Customer data updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('shop-customer.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customer $shop_customer)
    {
        $shop_customer->delete();
        return response()->json("deleted");
    }

     public function statusChange(Request $request)
    {
        $response=Customer::where('id', $request->customerid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }
    public function customerSave(Request $request)
    {
            $Customer=new Customer();
            $Customer->cust_name=$request->cust_name;
            $Customer->cust_type_id=1;
            $Customer->english_desptn=$request->english_desptn;
            $Customer->arabic_desptn=$request->english_desptn;
            $Customer->english_addrs=$request->english_addrs;
            $Customer->mobile=$request->mobile;
            $Customer->fax=$request->fax;
            $Customer->email=$request->email;
            $Customer->own_code=$request->own_code;
            $Customer->sales_man=$request->sales_man;
            $Customer->cost_center=$request->cost_center;
            $Customer->credit_limit=$request->credit_limit;
            $Customer->supplier_name=$request->supplier_name;
            $Customer->vist_date=$request->vist_day;
            $Customer->vat_no=$request->vat_no;
            $Customer->area_code=$request->area_code;
            $Customer->created_by=Auth::user()->shop_master_id;
            $Customer->save();
            return response()->json(['id'=>$Customer->id,'cust_name'=>$Customer->cust_name,'mobile'=>$Customer->mobile,'status'=>200]); 
    }
}
