<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\AccountType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\AccountTypeRequest;

class AccountTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $data=[
           'page_name' => 'account_type',
        ];
        return view('admin.master-data.account-type.account_type')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data=[
            'page_name' => 'account_type',
         ];
         return view('admin.master-data.account-type.create_account_type')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $accnttype=new AccountType();
        $accnttype->english_desptn=$request->english_desptn;
        $accnttype->arabic_desptn=$request->english_desptn;
        $accnttype->created_by=Auth::user()->shop_master_id;
        $accnttype->type=$request->type;
        $accnttype->save();

        Session::flash('success','Account type created successfully!..');
        $notification = array(
            'message' => 'Account type created successfully!..',
            'alert-type' => 'success'
        );
        
        if($request->save_only == "save_only"){
            return redirect()->route('account-type.index')->with($notification);
        }else{
            return redirect()->route('account-type.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\AccountType  $accountType
     * @return \Illuminate\Http\Response
     */
    public function show($accountType)
    {
     
        $account_type=AccountType::where('created_by',Auth::user()->shop_master_id)->get();   
      
        return Datatables::of($account_type)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($account_type){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-account_type_id="'.$account_type->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-account_type_id="'.$account_type->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($account_type)
                {
                 return $account_type->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$account_type->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$account_type->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($account_type) {
                     return $account_type->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\AccountType  $accountType
     * @return \Illuminate\Http\Response
     */
    public function edit(AccountType $accountType)
    {        
        $data=[
            'page_name' => 'account_type',
            'edit_account_type' => $accountType
            ];
       
        return view('admin.master-data.account-type.edit_account_type')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\AccountType  $accountType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AccountType $accountType)
    {
        $accountType->english_desptn=$request->english_desptn;
        $accountType->arabic_desptn=$request->english_desptn;
        $accountType->type=$request->type;
        $accountType->created_by=Auth::user()->shop_master_id;
        $account->is_active=$request->status;
        $accountType->save();

        Session::flash('success','Account type updated successfully!..');
        $notification = array(
            'message' => 'Account type updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('account-type.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\AccountType  $accountType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AccountType $accountType)
    {
        $accountType->delete();
        return response()->json("deleted");
    }

    public function statusChange(Request $request)
    {
        
        $response=AccountType::where('id', $request->accounttypeid)->update(array('is_active' => $request->val));

        return response()->json($response); 
        
    }
}
