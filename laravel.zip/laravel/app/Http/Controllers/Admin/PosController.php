<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\ItemUnit;
use App\Model\Item;
use App\Model\Customer;
use App\Model\Invoice;
use App\Model\InvoicePurchaseDetail;
use App\Model\ItemItemUnit;
use App\Model\ItemGroup;
use Auth;
use DB;
use App\Http\Requests\InvoiceRequest;

class PosController extends Controller
{
    protected $page = 'pos';

    public function createInvoice()
    {
        // checking permission for shop
        if (!Auth::user()->hasPermissionTo('sales')) {
            abort(401);
        }

        $page_name = $this->page;
        $products = Item::select("id", DB::raw("CONCAT('[',items.id,'] -' ,items.english_short_description) as english_short_description"))
            ->get()
            ->pluck('english_short_description', 'id')->toArray();

        $units = [];

        $customers = Customer::where('created_by', Auth::user()->shop_master_id)
            ->select("id", DB::raw("CONCAT(customers.cust_name,' [',customers.mobile,']') as full_name"))
            ->get()
            ->pluck('full_name', 'id')->toArray();

        if (Invoice::max('id')) {
            $invId = Invoice::max('id') + 1;
            $invoiceId = "Invoice #000" . $invId;
        } else {
            $invoiceId = "Invoice #001";
        }

        $today_date = date('20y-m-d');

        $itemGroup = ItemGroup::where('is_active', 1)->where('created_by', Auth::user()->shop_master_id)->pluck('english_description', 'id');
        $itemUnit = ItemUnit::where('is_active', 1)->where('created_by', Auth::user()->shop_master_id)->pluck('short_description', 'id');
        // $quantity=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('quantity','id');
        // $quantity=[];

        return view('admin.pos.index', compact('page_name', 'products', 'customers', 'invoiceId', 'units', 'itemGroup', 'itemUnit', 'today_date'));
    }
}
