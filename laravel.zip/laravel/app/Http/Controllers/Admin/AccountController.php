<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\Account;
use App\Model\SubAccountType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class AccountController extends Controller
{
    
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $data=[
            'page_name' => 'account',
         ];
         return view('admin.master-data.account.index')->with($data);
    }

    
    public function create()
    {
        $sub_account_type=SubAccountType::where('created_by',Auth::user()->shop_master_id)->get(); 
        $data=[
            'page_name' => 'account',
            'sub_account_type' => $sub_account_type
         ];
         return view('admin.master-data.account.create_account')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $accnt=new Account();
            $accnt->sub_accnt_type_id=$request->sub_accnt_type_id;
            $accnt->english_desptn=$request->english_desptn;
            $accnt->arabic_desptn=$request->english_desptn;
            $accnt->open_balance=$request->open_balance;
            $accnt->balance_start_date=$request->balance_start_date;
            $accnt->created_by=Auth::user()->shop_master_id;
            $accnt->save();
            Session::flash('success','Account created successfully!..');
            $notification = array(
                'message' => 'Account created successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('account.index')->with($notification);
        }else{
            return redirect()->route('account.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function show($account)
    {
        $account =Account::leftJoin('account_type_subs', function($join) {
             $join->on('accounts.sub_accnt_type_id', '=', 'accounts.id');
             })
             ->where('accounts.created_by',Auth::user()->shop_master_id)
             ->get(); 

        return Datatables::of($account)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($account){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-account_id="'.$account->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-account_id="'.$account->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($account)
                {
                 return $account->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$account->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$account->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
        ->addColumn('account_type', function ($account) {
                     return $account->sub_accnt_name;;
                    })
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($account) {
                     return $account->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function edit(Account $account)
    {
        $sub_account_type=SubAccountType::where('created_by',Auth::user()->shop_master_id)->get(); 
        $data=[
            'page_name' => 'account',
            'edit_account' => $account,
            'sub_account_type' => $sub_account_type
            ];
       
        return view('admin.master-data.account.edit_account')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Account $account)
    {
        $account->sub_accnt_type_id=$request->sub_accnt_type_id;
        $account->english_desptn=$request->english_desptn;
        $account->arabic_desptn=$request->english_desptn;
        $account->open_balance=$request->open_balance;
        $account->balance_start_date=$request->balance_start_date;
        $account->created_by=Auth::user()->shop_master_id;
        $account->is_active=$request->status;
        $account->update();
        Session::flash('success','Account updated successfully!..');
        $notification = array(
            'message' => 'Account updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('account.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function destroy(Account $account)
    {
        $account->delete();
        return response()->json("deleted");
    }

    public function statusChange(Request $request)
    {
        $response=Account::where('id', $request->accountid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }
}
