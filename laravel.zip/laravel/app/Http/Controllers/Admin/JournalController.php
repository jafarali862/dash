<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Http\Request;
use App\Model\Item;
use App\Model\Journal;
use App\Model\JournalEntries;
use App\Model\Account;
use App\Model\AccountTransaction;
use App\Model\CostCenter;
use App\Model\AccountType;
use Auth;
use DB;
use App\Http\Requests\InvoiceRequest;

class JournalController extends Controller
{
    protected $page = 'Journal';

    public function index()
    {
        $page_name = $this->page;
        $journals = Journal::where('created_by', Auth::user()->shop_master_id)
            ->get();

        return view('admin.accounts.journal.index', compact('page_name', 'journals'));
    }

    public function viewJournal()
    {
        $page_name = $this->page;
        $journals = Journal::where('created_by', Auth::user()->shop_master_id)
            ->get();
        $costcode = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
       return view('admin.accounts.journal.index', compact('page_name', 'journals','costcode'));
    }

    public function show($journals)
    {
    $journals=Journal::where('created_by',Auth::user()->shop_master_id)->get();
        return Datatables::of($journals)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($journals){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-area_code_id="'.$journals->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-area_code_id="'.$journals->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($journals)
                {
                 return $journals->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$journals->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$journals->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
        
       
         ->setRowClass(function($journals) {
                     return $journals->is_active==1?'':'bgdisable';
                      })

          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    public function createJournal()
    {
       
        // checking permission for shop
        if (!Auth::user()->hasPermissionTo('accounts')) {
            abort(401);
        }

        $page_name = $this->page;
        $products = Item::select("id", DB::raw("CONCAT('[',items.id,'] -' ,items.english_short_description) as english_short_description"))
            ->get()
            ->pluck('english_short_description', 'id')->toArray();

        if (Journal::max('id')) {
            $jvId = Journal::max('id') + 1;
            $journalId = "JV No #000" . $jvId;
        } else {
            $journalId = "JV No #001";
        }
    
        $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
         $costcode = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');

        return view('admin.accounts.journal.create_journal', compact('page_name','products'
        ,'journalId','saleaman','areacode','costcode'));
    }


    

    public function saveJournal(Request $request)
    {
       $journals = Journal::where('id',$request->journal_id)->first();
        if(isset($journals->id)){
            JournalEntries::where('journal_id',$journals->id)->delete();
            $journals = Journal::find($journals->id);
        }
        else
            $journals = new Journal;
        
        $journals->created_by   = Auth::user()->shop_master_id;
        $journals->doc_date     = $request->doc_date;
        $journals->cost_id      = $request->cost_id;
        $journals->is_active = 1;
        $journals->save();

        foreach ($request->account_id as $key => $value) {
            $journal_details = new JournalEntries;
            $journal_details->journal_id = $journals->id;
            $journal_details->account_id = $request->account_id[$key];
            $journal_details->user_id = $request->user_id[$key];
            $journal_details->particular = $request->particular[$key];
            $journal_details->debit = $request->debit[$key];
            $journal_details->credit = $request->credit[$key];
            $journal_details->save();
        }      
        if ($request->btn_value == 'save & new') {
            return redirect()->route('view-journal');
        } else {
            return redirect()->route('view-journal');

        }
    }

    public function edit($id)
    {
        
        $journals = Journal::where('id',$id)->first();
        $products = Item::select("id", DB::raw("CONCAT('[',items.id,'] -' ,items.english_short_description) as english_short_description"))
            ->get()
            ->pluck('english_short_description', 'id')->toArray();
        $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $costcode = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
           $jvId = Journal::max('id');
        $journalId = "JV No #000" . $jvId;    
        $journalDetails = JournalEntries::where('journal_id',$id)->get();

        $data=[
            'page_name' => 'Journal',
            'edit_journal' => $journals,
            'journalDetails' => $journalDetails,
            'saleaman' => $saleaman,
             'journalId'=> $journalId,
            'areacode' => $areacode,
             'products'=>$products,
            'costcode' => $costcode,      
            
            ];
       
        return view('admin.accounts.journal.create_journal')->with($data);
    }

     public function update(Request $request, $journals)
    {
       $journals = new Journal; 
        $journals->created_by = Auth::user()->shop_master_id;   
        $journals->doc_date = $request->doc_date;
        $journals->cost_id = $request->cost_id;
        $journals->save();
        foreach ($request->account_id as $key => $value) {
     
            $journal_details = new JournalEntries;
            $journal_details->journal_id = $journals->id;
            $journal_details->account_id = $request->account_id[$key];
            $journal_details->user_id = $request->user_id[$key];
            $journal_details->particular = $request->particular[$key];
            $journal_details->debit = $request->debit[$key];
            $journal_details->credit = $request->credit[$key];
            $journal_details->created_by = Auth::user()->shop_master_id;
            $journal_details->save();
        }

        $notification = array(
            'message' => 'Journal data updated successfully!..',
            'alert-type' => 'success',
            'success' => 'Journal updated successfully!..'
        );
        return redirect('journal-code/show/')->with($notification);
    }

     public function statusChange(Request $request)
    {
        $response = Journal::where('id', $request->customerid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }

     public function destroy($journals)
    {
        $journals = Journal::where('id',$journals);
        $journals->delete();
        return response()->json("deleted");
    }

    public function delete($id)
    {
        $journals = Journal::where('id',$id);
        $journals->delete();
        return response()->json("deleted");
    }

   
}
