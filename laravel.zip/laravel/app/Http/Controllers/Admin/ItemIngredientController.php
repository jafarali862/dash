<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use Carbon\Carbon;
use Session;
use DB;
use App\Model\Ingredient;
use App\Model\ItemIngredient;
use App\Model\Item;
use Illuminate\Http\Request;

class ItemIngredientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=[
            'page_name' => 'item_ingredient',
         ];
        return view('admin.master-data.settings.item-ingredients.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $items =  Item::where('created_by',Auth::user()->shop_master_id)->get()->pluck('english_description','id');; 
        $ingredients=Ingredient::where('created_by',Auth::user()->shop_master_id)->get()->pluck('ingredient','id');;    
        $data=[
            'page_name' => 'item_ingredient',
            'items' => $items,
            'ingredients' => $ingredients
         ];
        return view('admin.master-data.settings.item-ingredients.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $items = new ItemIngredient();
        $sync_data = [];
        for($i = 0; $i < count($request->input('ingredient_id')); $i++)
        {
           $data = ItemIngredient::where('item_id', $request->input('item_id'))
           ->where('ingredient_id', $request->input('ingredient_id')[$i])
           ->get();

            if(count($data) > 0)
            {
                ItemIngredient::where('item_id', $request->input('item_id'))
                ->where('ingredient_id', $request->input('ingredient_id')[$i])
                ->delete();
                $sync_data['item_id'] = $request->input('item_id');
                $sync_data['ingredient_id'] = $request->input('ingredient_id')[$i];
                $sync_data['qty_used'] = $request->input('qty_used')[$i];
                $sync_data['created_by'] = Auth::user()->shop_master_id;
                DB::table('ingredient_item')->insert($sync_data);
            }else{
                ItemIngredient::where('item_id', $request->input('item_id'))
                ->where('ingredient_id', $request->input('ingredient_id')[$i])
                ->delete();
                $ingredients = Ingredient::where('id', $request->input('ingredient_id')[$i])->get();
                $qty['min_stock'] = $ingredients[0]->min_stock - $request->input('qty_used')[$i];
                Ingredient::where('id', $request->input('ingredient_id')[$i])->update($qty);
                $sync_data['item_id'] = $request->input('item_id');
                $sync_data['ingredient_id'] = $request->input('ingredient_id')[$i];
                $sync_data['qty_used'] = $request->input('qty_used')[$i];
                $sync_data['created_by'] = Auth::user()->shop_master_id;
                DB::table('ingredient_item')->insert($sync_data);
            }
        }
        Session::flash('success','Ingredients added to items successfully!..');
            $notification = array(
                'message' => 'Ingredients added to items successfully!..',
                'alert-type' => 'success'
            );

        if($request->save_only == "save_only")
        {
            return redirect()->route('item-ingredient.index')->with($notification);
        }else{
            return redirect()->route('item-ingredient.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\ItemIngredient  $itemIngredient
     * @return \Illuminate\Http\Response
     */
    public function show($itemIngredient)
    {
        $itemingredients =  Item::where('created_by',Auth::user()->shop_master_id)->get(); 
       
        return Datatables::of($itemingredients)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($itemingredients){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a data-target="#edit_ingredient_pop_up" data-toggle="modal" style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-ingredient_id="'.$itemingredients->id.'">Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-ingredient_id="'.$itemingredients->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($itemingredients)
                {
                 return $itemingredients->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$itemingredients->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$itemingredients->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
         ->addColumn('ingredients', function ($itemingredients) {

                 $ingredient = '';
                     foreach ($itemingredients->ingredients as $key => $ingredients) {
                          $url = url('/assets/img/cancel.png');
                          $ingredient .= '<a style="cursor:pointer;" onclick="getId('.$ingredients->id.')"><img src="'.$url.'"></a> <span class="badge badge-success">'.$ingredients->ingredient.'</span>&nbsp;&nbsp;';
                     }

                    if($ingredient != ""){ 
                       return $ingredient;
                    }else{
                        return '<span class="badge badge-warning">No Ingredients Added</span>&nbsp;&nbsp;';
                    }
                    
                    })
 
        //serves to distinguish the inactive & active records
 
        // this is used to show inactive records in a disabled manner
         ->setRowClass(function($itemingredients) {
                     return $itemingredients->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['ingredients','action_button','status'])
          ->make(true);
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\ItemIngredient  $itemIngredient
     * @return \Illuminate\Http\Response
     */
    public function editItemIngredient($ingredient_id)
    {
        $ingredients = Ingredient::where('created_by',Auth::user()->shop_master_id)->pluck('ingredient','id');
        $selectedIngredients =  ItemIngredient::where('created_by',Auth::user()->shop_master_id)->where('item_id',$ingredient_id)->get();
        $items = Item::where('created_by',Auth::user()->shop_master_id)->where('id',$ingredient_id)->pluck('english_description','id');

        $data=[
            'page_name' => 'item_ingredient',
            'ingredients' => $ingredients,
            'items' =>$items,
            'selectedIngredients' => $selectedIngredients
         ];
        return view('admin.master-data.settings.item-ingredients.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\ItemIngredient  $itemIngredient
     * @return \Illuminate\Http\Response
     */
    public function updateItemIngredient(Request $request)
    {
        $sync_data = [];
        for($i = 0; $i < count($request->input('ingredient_id')); $i++)
        {
           $data = ItemIngredient::where('item_id', $request->input('item_id'))
           ->where('ingredient_id', $request->input('ingredient_id')[$i])
           ->get();

           if($data[0]->qty_used == $request->input('qty_used')[$i])
           {
             $sync_data['item_id'] = $request->input('item_id');
             $sync_data['ingredient_id'] = $request->input('ingredient_id')[$i];
             $sync_data['qty_used'] = $request->input('qty_used')[$i];
             $sync_data['created_by'] = Auth::user()->shop_master_id;
             
             $updated = ItemIngredient::where('item_id', $request->input('item_id'))
             ->where('ingredient_id', $request->input('ingredient_id')[$i])
             ->update($sync_data);
           }else{

            $ingredients = Ingredient::where('id', $request->input('ingredient_id')[$i])->get();
            $qty['min_stock'] = $ingredients[0]->min_stock - $request->input('qty_used')[$i];

            Ingredient::where('id', $request->input('ingredient_id')[$i])->update($qty);
            $sync_data['item_id'] = $request->input('item_id');
            $sync_data['ingredient_id'] = $request->input('ingredient_id')[$i];
            $sync_data['qty_used'] = $request->input('qty_used')[$i];
            $sync_data['created_by'] = Auth::user()->shop_master_id;

             DB::table('ingredient_item')->update($sync_data);
           }
           
        }
        Session::flash('success','Ingredients updated to items successfully!..');
            $notification = array(
                'message' => 'Ingredients updated to items successfully!..',
                'alert-type' => 'success'
            );

            return redirect()->route('item-ingredient.index')->with($notification);
    }

    public function getStock(Request $request)
    {
        
    }

    public function deleteIngredient(Request $request)
    {
        DB::delete('delete from ingredient_item where ingredient_id = ?',[$request->item_igredient_id]);
        return response()->json("deleted");
    }
}
