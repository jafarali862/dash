<?php

namespace App\Http\Controllers\Admin;


use App\Model\Item;
use App\Model\ItemGroup;
use App\Model\ItemUnit;
use App\Http\Controllers\Controller;
use Auth;
use Carbon\Carbon;
use Session;
use DB;
use Illuminate\Http\Request;

class StockEnquiryController extends Controller
{
      public function index()
      {
      	 // // checking permission for shop
        // if(!Auth::user()->hasPermissionTo('sales')){
        //     abort(401);
        // }
        $products = Item::select("id", DB::raw("CONCAT('(',items.id,') -',items.english_short_description) as english_short_description"))
        ->where('created_by',Auth::user()->shop_master_id)
        ->get()
        ->pluck('english_short_description', 'id')->toArray();
      	 $data=[
            'page_name' => 'stock_enquiry',
            'items'     => $products
         ];

         return view('admin.stock-enquiry.index')->with($data);
      }
      public function getDetails(Request $request ,Item $item)
      {
        $item=Item::with('itemUnit','itemGroup')->where('created_by',Auth::user()->shop_master_id)->where('id',$request->itemid)->get();   
       
        $details = null;
        // $item_code = null;
        foreach ($item as $key => $value) {
        	foreach ($value->itemUnit as $keys => $values) {
        		$itemunit=ItemUnit::where('is_active',1)->where('id',$values->pivot->item_unit_id)->get(); 
        		$uomvalue=$keys + 1;
        		// dd($values->pivot->item_id);
        		// if($value->id == $values->pivot->item_id)
        		// {
          //         $item_code.=
        	
        		// '<br>
        		//  <div class="col-md-3 col-lg-3">
        		//   </div>
        		//   <div class="col-md-6 col-lg-6">
        		//     <label for="validationCustom03">Item Code #</label>
          //           <input type="text" class="form-control" readonly=""  value="'.$value->id.'">
        		//   </div>
        		//    <div class="col-md-3 col-lg-3">
        		//   </div>
        		// ';
        		// }
        		$details .= 
        		'
        		<br>
        		<div class="row">
                  <div class="col-md-12 col-lg-12">
                   <h6>--&nbsp;'.$itemunit[0]->short_description.'&nbsp;'.$uomvalue.'&nbsp;(UOM)&nbsp;--</h6>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3 col-lg-3">
                    <label for="validationCustom03">Stock</label>
                    <input type="text" class="form-control" readonly=""  value="'.$values->pivot->minimum_stock.'">
                  </div>
                  <div class="col-md-3 col-lg-3">
                    <label for="validationCustom03">Cost</label>
                    <input type="text" class="form-control" readonly="" value="'.$values->pivot->cost.'">
                  </div>
                  <div class="col-md-3 col-lg-3">
                    <label for="validationCustom03">Price</label>
                    <input type="text" class="form-control" readonly="" value="'.$values->pivot->price.'"> 
                  </div>
                   <div class="col-md-3 col-lg-3">
                    <label for="validationCustom03">Quantity</label>
                    <input type="text" class="form-control" readonly="" value="'.$values->pivot->quantity.'"> 
                  </div>
                </div>';
        	}
        	
        }
        return response()->json(['status' => 200 ,'items'=>$details]);
      }
}
