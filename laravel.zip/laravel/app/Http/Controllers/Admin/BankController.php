<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Session;
use Carbon\Carbon;
use App\Model\Bank;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\BankRequest;

class BankController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::user()->hasPermissionTo('master_data')){
            abort(401);
        }
        
        $data=[
            'page_name' => 'bank',
         ];
        return view('admin.master-data.bank.bank')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data=[
            'page_name' => 'bank',
         ];
        return view('admin.master-data.bank.create_bank')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $Bank=new Bank();
        $Bank->english_desptn=$request->english_desptn;
        $Bank->arabic_desptn=$request->english_desptn;
        $Bank->location=$request->location;
        $Bank->account_no=$request->accnt_no;
        $Bank->cost_center=$request->cost_center;
        $Bank->sales_accnt=$request->sales_accnt;
        $Bank->created_by=Auth::user()->shop_master_id;
        $Bank->is_active=1;
        $Bank->save();
        Session::flash('success','Bank created successfully!..');
        $notification = array(
            'message' => 'Bank created successfully!..',
            'alert-type' => 'success'
        );

        if($request->save_only == "save_only")
        {
            return redirect()->route('bank.index')->with($notification);
        }else{
            return redirect()->route('bank.create')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function show($bank)
    {

         $bank_data=Bank::where('created_by',Auth::user()->shop_master_id)->get();  

        return Datatables::of($bank_data)
            // adding the edit button to each rows
        ->addColumn('action_button', function ($bank_data){
             return '<div class="btn-group">
                         <button type="button" class="btn btn-dark btn-sm">Open</button>
                         <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                         </button>
                         <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                           <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit" data-bank_id="'.$bank_data->id.'" >Edit</a>
                           <div class="dropdown-divider"></div>
                           <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-bank_id="'.$bank_data->id.'">Delete</a>
                         </div>
                     </div>';
         })
         ->editColumn('status', function($bank_data)
                {
                 return $bank_data->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                     <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$bank_data->id.')">
                                                     <span class="slider"></span>
                                                 </label>' : '<label class="switch s-outline s-outline-success">
                                                     <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$bank_data->id.')">
                                                     <span class="slider"></span>
                                                 </label>';
                })
 
           //serves to distinguish the inactive & active records
 
         //   // this is used to show inactive records in a disabled manner
         ->setRowClass(function($bank_data) {
                     return $bank_data->is_active==1?'':'bgdisable';
                      })
 
          // converts the raw html tags to real button entities
          ->rawColumns(['action_button','status'])
          ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function edit(Bank $bank)
    {
        $data=[
            'page_name' => 'bank',
            'edit_bank' => $bank
            ];
       
        return view('admin.master-data.bank.edit_bank')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bank $bank)
    {
        $bank->english_desptn=$request->english_desptn;
        $bank->arabic_desptn=$request->english_desptn;
        $bank->location=$request->location;
        $bank->account_no=$request->accnt_no;
        $bank->cost_center=$request->cost_center;
        $bank->sales_accnt=$request->sales_accnt;
        $bank->created_by=Auth::user()->shop_master_id;
        $bank->is_active=$request->status;
        $bank->save();
        Session::flash('success','Bank updated successfully!..');
        $notification = array(
            'message' => 'Bank updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('bank.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bank $bank)
    {
        $bank->delete();
        return response()->json("deleted");
    }

    public function statusChange(Request $request)
    {
        
        $response=Bank::where('id', $request->bankid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }
}
