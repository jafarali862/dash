<?php
namespace App\Http\Controllers\Admin;

use Auth;
use App\User;
use Session;
use App\Model\Profile;
use App\Model\ShopMaster;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class ProfileController extends Controller
{
   
    public function index()
    {
        $shopdata=ShopMaster::where('id',Auth::user()->id)->get();
        $data=[
            'page_name' => 'profile',
            'shopdata'  => $shopdata,
         ];
        return view('profile.index')->with($data);
    }

    public function create()
    {
        //
    }

   
    public function store(Request $request)
    {
        //
    }

   
    public function show(Profile $profile)
    {
        //
    }

    public function edit($Shopmaster_id)
    {
        $Shopmaster=Shopmaster::findorFail($Shopmaster_id);
        $data=[
            'page_name' => 'profile',
            'shopdata'  => $Shopmaster,
         ];
        return view('profile.edit')->with($data);
    }

   
    public function update(Request $request,$shopmaster_id)
    {

        if ($files=$request->file('image')) {
            $validated = $request->validate([
                    'image' => 'mimes:jpeg,png|max:1014',
                ]);

            $name=$files->getClientOriginalName();  
            $files->move('uploads',$name);  
            ShopMaster::where('id', $shopmaster_id)->update(array('photo' => $name,
            'name' => $request->name,
            'eng_description' => $request->eng_description,
            'arabic_description' => $request->arabic_description,
            'line_1' => $request->line_1,
            'line_2' => $request->line_2,
            'city' => $request->city,
            'state' =>$request->state,
            'country' => $request->country,
            'primary_phone' => $request->primary_phone,
            'secondary_phone' => $request->secondary_phone,
            'fb_url' => $request->fb_name,
            'linked_url' => $request->linked_name,
            'tiwtter_url' => $request->tweet_name
                    ));
         }else{
            if($request->image)
            {
                $name=$request->image;
            }else{
                $name='';
            }
            ShopMaster::where('id', $shopmaster_id)->update(array('photo' => $name,
            'name' => $request->name,
            'eng_description' => $request->eng_description,
            'arabic_description' => $request->arabic_description,
            'line_1' => $request->line_1  ,
            'line_2' => $request->line_2,
            'city' => $request->city,
            'state' =>$request->state,
            'country' => $request->country,
            'primary_phone' => $request->primary_phone,
            'secondary_phone' => $request->secondary_phone,
            'fb_url' => $request->fb_name,
            'linked_url' => $request->linked_name,
            'tiwtter_url' => $request->tweet_name
                    ));
            
         } 
        Session::flash('success','Profile updated successfully!..');
            $notification = array(
            'message' => 'Profile updated successfully!..',
            'alert-type' => 'success'
        );
        return redirect()->route('profile.index');

         
    }

  
    public function destroy(Profile $profile)
    {
        //
    }
}
