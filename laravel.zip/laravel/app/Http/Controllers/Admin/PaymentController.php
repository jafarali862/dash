<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\AccountTransaction;
use App\Model\CostCenter;
use App\Model\Supplier;
use App\Model\Account;
use App\Model\AccountType;
use App\Model\Bank;
use App\Model\AreaCode;
use Auth;
use Yajra\DataTables\Facades\DataTables;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($type = 'cash')
    {
        if(!$this->isPayment($type)) return redirect('/');
        return view('admin.accounts.transaction.index');
    }

    public function isPayment($value)
    {
        return $value == 'cash' || $value == 'bank' || $value == 'cash-receipt' || $value == 'bank-payment';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($type = 'cash')
    {
        if(!$this->isPayment($type)) return redirect('/');
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $bankcode = Bank::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $costcode = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');

        if(AccountTransaction::max('id'))
        {
            $custId = AccountTransaction::max('id') + 1;
            $customerId = "#".$custId;
        }
        else{
            $customerId = "#1000";
        }

       $data=[
            'page_name' => 'bank_account',
            'cust_id' => $customerId,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
            'bankcode' => $bankcode,
            'costcode' => $costcode,
            'supplier' => $supplier,
            'type' => $type,
         ];
        return view('admin.accounts.transaction.create_transaction',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $cash = new AccountTransaction();
       $cash->type = $request->type;
       $cash->doc_date = $request->doc_date;
       $cash->amount =  $request->amount;
       $cash->remarks = $request->remarks;
       $cash->cheque_no = $request->cheque_no;
       $cash->account_id = $request->account_id;
       $cash->user_id = $request->user_id;
       $cash->description = $request->description; 
       $cash->bank_id = $request->bank_id;
       $cash->cost_id = $request->cost_id;     
       $cash->created_by = Auth::user()->shop_master_id;
       $cash->is_active = 1;
       $cash->save();
        $notification = array(
            'message' => 'CashRecepits data created successfully!..',
            'alert-type' => 'success',
            'success' => 'CashRecepits data created successfully!..'
        );
        if($request->save_only == "save_only")
            return redirect()->route('account-transactions')->with($notification);
        else
            return redirect('account-transactions/create/'.$request->type)->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$type = 'cash')
    {
        if(!$this->isPayment($type)) return redirect('/');
        if($request->ajax()){
            $accounts = AccountTransaction::where('type',$type)->get();
            return Datatables::of($accounts)
              ->addColumn('action_button', function ($cash){
                 return '<div class="btn-group">
                             <button type="button" class="btn btn-dark btn-sm">Open</button>
                             <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                             </button>
                             <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                               <a style="color:green;cursor: pointer;" class="dropdown-item btnEdit"  data-toggle="modal" data-target="#editModal" data-customer_id="'.$cash->id.'">Edit</a>
                               <div class="dropdown-divider"></div>
                               <a style="color:red;cursor: pointer;" class="dropdown-item btnDelete" data-customer_id="'.$cash->id.'">Delete</a>
                             </div>
                         </div>';
             })
             ->editColumn('status', function($cash)
                    {
                     return $cash->is_active==1?' <label class="switch  s-outline  s-outline-success">
                                                         <input type="checkbox" class="changeStatus" checked onclick="changeStatus(this.checked,'.$cash->id.')">
                                                         <span class="slider"></span>
                                                     </label>' : '<label class="switch s-outline s-outline-success">
                                                         <input type="checkbox" class="changeStatus" onclick="changeStatus(this.checked,'.$cash->id.')">
                                                         <span class="slider"></span>
                                                     </label>';
                    })
             ->setRowClass(function($cash) {
                         return $cash->is_active==1?'':'bgdisable';
                          })
              ->rawColumns(['action_button','status'])
              ->make(true);;
        }
        $data = [
            'page_name' => $type,
            'type' => $type,
        ];
        return view('admin.accounts.transaction.index',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id,$type = 'cash')
    {
        if(!$this->isPayment($type)) return redirect('/');
        $cash = AccountTransaction::where('id',$id)->first();
        $areacode = AreaCode::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('area_code','id');
        $costcenter = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');
        $supplier = Supplier::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');   
        $saleaman = Account::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $areacode = AccountType::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $bankcode = Bank::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_desptn','id');
        $costcode = CostCenter::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('name','id');

        $data=[
            'page_name' => 'cash_account',
            'edit_account' => $cash,
            'saleaman' => $saleaman,
            'costcenter' =>$costcenter,
            'areacode' => $areacode,
            'bankcode' => $bankcode,
            'costcode' => $costcode,
            'supplier' => $supplier,
            'type' => $type
            
            ];
       
        return view('admin.accounts.transaction.create_transaction')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $cash)
    {
        $cash = AccountTransaction::find($cash);
        $cash->doc_date = $request->doc_date;
        $cash->amount = $request->amount;
        $cash->remarks = $request->remarks;
        $cash->cheque_no = $request->cheque_no;
        $cash->account_id = $request->account_id;
        $cash->user_id = $request->user_id;
        $cash->description = $request->description;
        $cash->bank_id = $request->bank_id;
        $cash->cost_id = $request->cost_id;
        $cash->created_by = Auth::user()->shop_master_id;
        $cash->save();

        $notification = array(
            'message' => 'Cash data updated successfully!..',
            'alert-type' => 'success',
            'success' => 'Cash data updated successfully!..'
        );
        return redirect('account-transactions/show/'.$request->type)->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($cash)
    {
        $cash = AccountTransaction::where('id',$cash);
        $cash->delete();
        return response()->json("deleted");
    }

    public function delete($id)
    {
        $cash = AccountTransaction::where('id',$id);
        $cash->delete();
        return response()->json("deleted");
    }
    
    public function statusChange(Request $request)
    {
        $response = AccountTransaction::where('id', $request->customerid)->update(array('is_active' => $request->val));
        return response()->json($response); 
        
    }

    public function cashSave(Request $request)
    {
        $cash = new AccountTransaction();
        $cash->doc_date = $request->doc_date;     
        $cash->amount = $request->amount;
        $cash->remarks = $request->remarks;
        $cash->cheque_no = $request->cheque_no;     
        $cash->account_id = $request->account_id;
        $cash->user_id = $request->user_id;
        $cash->description = $request->description;
        $cash->bank_id = $request->bank_id;
        $cash->cost_id = $request->cost_id;
        $cash->created_by = Auth::user()->shop_master_id;
        $cash->save();
        return response()->json(['id'=> $cash->id,'remarks'=> $cash->remarks,'description'=> $cash->description,'status'=>200]); 
    }
}
