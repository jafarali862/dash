<?php

namespace App\Http\Controllers\Admin;

use App\Model\Damage;
use Illuminate\Http\Request;
use App\Model\Customer;
use App\Model\Item;
use App\Http\Controllers\Controller;
use App\Model\DamageDetail;
use App\Model\ItemItemUnit;
use App\Model\ItemUnit;
use App\Model\ItemGroup;
use Auth;
use DB;

class DamageController extends Controller
{
    protected $page = 'damage';

    public function index()
    {
        $page_name = $this->page;
        $damages = Damage::all();
        return view('admin.sales.damage.damage_list',compact('page_name','damages'));
    }

    public function viewDamage()
    {
        $page_name = $this->page;
        $damages = Damage::pluck('damage_number','id');
        $customers = Customer::pluck('cust_name','id');
        return view('admin.sales.damage.Damage',compact('page_name','damages','customers'));
    }

    public function getDamageDetails(Request $request)
    {
        $damage = Damage::where('id',$request->inv_id)->first();
        $damage_details = $damage->damageDetails;

        $table = '';
        $row = '';

        foreach($damage_details as $key => $value) 
        {
            $product = Item::where('id',$value->item_id)->first()->english_description;

            $row.= '<tr><td>'.++$key.'</td><td>'.$product.'</td><td class="text-right">'.$value->unit.'</td><td class="text-right">'.$value->price.'</td><td class="text-right">'.$value->quantity.'</td><td class="text-right">'.$value->stock.'</td><td class="text-right">'.$value->stock.'</td><td class="text-right">'.$value->total.'</td><td class="text-center removeRow" data-flag=1 data-unit="'.$value->unit.'" data-item="'.$value->item_id.'" data-qty="'.$value->quantity.'" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 icon"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                        </td></tr>';

            $table.= $row;
            $row = '';
        }

        return response()->json(['Damage'=>$damage,'Table'=>$table]);
    }

    public function editDamageDetails(Request $request)
    {
        $damage = Damage::where('id',$request->inv_id)->first();
        $damage_details = $damage->damageDetails;

        $table = '';
        $row = '';
        $counter = sizeof($damage_details);
        $total_vat = 0;
        foreach($damage_details as $key => $value) 
        {

            $select = '<select class="selectpicker productSelect" title="Select Product" name="Products[]" id="Products" required>';
            $select_unit = '<select class="selectpicker unit" data-width="80%" title="Select Unit" name="unit[]" id="Unit" required>';
            $options = '';
            $options_unit = '';
            

            foreach (Item::where('created_by',Auth::user()->shop_master_id)
                         ->pluck('english_description','id') as $item_id => $item_name) 
            {
                if($item_id == $value->item_id)
                {
                    $options.='<option selected value='.$item_id.'>'.$item_name.'</option>';
                }
                else
                {
                    $options.='<option value='.$item_id.'>'.$item_name.'</option>';
                }
                
            }

            $item = Item::where('id',$value->item_id)->first();


            $item_units = ItemItemUnit::where('item_id',$value->item_id)
                            ->pluck('item_unit_id')
                            ->toArray();

            foreach (ItemUnit::whereIn('id',$item_units)->pluck('english_description','id') 
                as $unit_id => $unit_name) 
            {
                if($unit_id == $value->unit)
                {
                    $options_unit.='<option selected value='.$unit_id.'>'.$unit_name.'</option>';
                }
                else
                {
                    $options_unit.='<option value='.$unit_id.'>'.$unit_name.'</option>';
                }
                
            }

            $select = $select.$options.'</select>';
            $select_unit = $select_unit.$options_unit.'</select>';

            $total_vat = $total_vat + ($value->quantity*$item->vat);
            $row.= '<tr>
                        <td>'.++$key.'</td>
                        <td class="code">'.$item->id.'</td>
                        <td>'.$select.'</td>
                        <td>'.$select_unit.'</td>
                        <td><input type="number" name="price[]"" placeholder="Price" class="form-control price" step="0.00" min="0" value="'.$value->price.'"/></td>
                        <td><input type="number" name="qty[]"" placeholder="Qty" class="form-control qty" step="0" min="0"  value="'.$value->quantity.'" />
                        </td>
                        <td class="old_qty"><input type="number" name="old_qty[]"" placeholder="Qty" class="form-control old_qty"  value="'.$value->quantity.'" />
                        </td>
                        <td class="hideStock"><input type="number" name="Stock[]"" placeholder="Stock" class="form-control stock" value="'.$value->stock.'" readonly/></td>
                        <td><input type="number" name="invCost[]"" placeholder="InvCost" class="form-control cost" value="'.$value->invcost.'"readonly/></td>
                        <td><input type="number" name="vat[]" placeholder="0.00" class="form-control vat" readonly/ value="'.$item->vat.'"></td>
                        <td><input type="number" name="total[]" placeholder="0.00" class="form-control total" readonly/ value="'.$value->total.'"></td>
                         <td class="text-center removeRow" data-flag=1 data-unit="'.$value->unit.'" data-item="'.$value->item_id.'" data-qty="'.$value->quantity.'" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 icon"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                        </td>
                    </tr>';

                   
            $table.= $row;
            $row = '';
        }

        return response()->json(['Damage'=>$damage,'Table'=>$table,'Counter'=>$counter,'Vat'=>$total_vat]);
        
    }

    public function createDamage()
    {
        // checking permission for shop
        if(!Auth::user()->hasPermissionTo('sales')){
            abort(401);
        }
        
        $customers = Customer::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('cust_name','id');
        $products = Item::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_short_description','id');
        $units = ItemUnit::pluck('english_description','id');
        if(Damage::max('id'))
        {
            $invId = Damage::max('id') + 1;
            $damageId = "Damage #000".$invId;
        }
        else{
            $damageId = "Damage #001";
        }
         $itemGroup=ItemGroup::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('english_description','id');
        $itemUnit=ItemUnit::where('is_active',1)->where('created_by',Auth::user()->shop_master_id)->pluck('short_description','id');


        $data=[
            'page_name' => $this->page,
            'customers'  => $customers,
            'products'  => $products,
            'units' => $units,
            'damageId' => $damageId,
            'itemGroup' => $itemGroup,
            'itemUnit' => $itemUnit 
         ];

         return view('admin.sales.damage.create')->with($data);
        
    }

    public function productList()
    {
        $products = Item::select('id','english_description','arabic_description')->get();
        return response()->json(['Products'=>$products]);
    }

    public function getItemDetails(Request $request)
    {
        $item = Item::where('id',$request->itemId)->first();
        $hasPrice = $item->itemUnit()->exists();
    
        if($hasPrice)
        {
            $instance = $item->itemUnit->first();
            // $unit = ItemUnit::where('id',$instance->pivot->item_unit_id)->first()->english_description;
            $unit = $instance->pivot->item_unit_id;
            $price = $instance->pivot->price;
            $cost = $instance->pivot->cost;
            $stock = $instance->pivot->minimum_stock;
            
            return response()->json(['price'=>$price,'cost'=>$cost,'price'=>$price,'unit'=>$unit,'stock'=>$stock,'vat'=>$item->vat,'status'=>200,'msg'=>"item found !!"]);
        }
        else
        {
            return response()->json(['price'=>0,'status'=>404,'msg'=>"item not found !!"]);
        }
    }

    public function getCustomerDetails(Request $request)
    {
        $customer = Customer::where('id',$request->customer_id)->first();
        return response()->json(['customer'=>$customer,'status'=>200]);
    }

    public function saveDamage(Request $request)
    {
        // dd($request->all());
        $damage =new Damage;
        $damage->customer_id = $request->customer;
        $damage->created_by = Auth::user()->shop_master_id;
        $request->has('any') ? $damage->any =1 : $damage->any =0;
        $request->cash_credit == 'credit' ? $damage->credit =1 : $damage->credit =0;
        $damage->date = $request->date;
        $damage->remark1 = $request->number_2;
        $request->discount == null ?  $damage->discount = 0:$damage->discount = $request->discount;
        $damage->sub_total = $request->sub_total;
        $damage->grant_total = $request->grant_total;
        $damage->save();

        $damage->damage_number = "Damage #000".$damage->id;
        $damage->save();

        foreach ($request->Products as $key => $value) {
            # code...
            $damage_details = new DamageDetail;
            $damage_details->damage_id = $damage->id;
            $damage_details->item_id = $value;
            $damage_details->unit = $request->unit[$key];
            $damage_details->quantity = $request->qty[$key];
            $damage_details->price = $request->price[$key];
            $damage_details->stock = $request->Stock[$key];
            $damage_details->invcost = $request->invCost[$key];
            $damage_details->total = $request->total[$key];
            $damage_details->save();

            // $item_unit = ItemItemUnit::where('item_id',$value)->first();
            // $new_stock = $item_unit->minimum_stock - $request->qty[$key];

      
            // DB::table('item_item_unit')->where([['item_id',$value],['item_unit_id',$request->unit[$key]]])->update(['minimum_stock' => $new_stock]);

            }
        if($request->btn_value == 'save & new')
        {
          return redirect()->action('DamageController@createDamage');
        }else{
          return redirect()->route('view-damage');  
        }
        
    }

    public function editDamage(Request $request)
    {
        $page_name = $this->page;
        $products = Item::pluck('english_short_description','id');
        $units = ItemUnit::pluck('english_description','id');
        $customers = Customer::pluck('cust_name','id');
        $invId = Damage::max('id') + 1;
        $damageId = "Damage #000".$invId;
        $damage = Damage::pluck('damage_number','id');
        return view('admin.sales.damage.edit_damage', compact('page_name','products','units','customers','damageId','damage'));        
    }


    public function updateDamage(Request $request)
    {
        $damage = Damage::where('id',$request->damage_id)->first();
        $damage->customer_id = $request->customers;
        $damage->created_by = Auth::user()->shop_master_id;
        $request->has('any') ? $damage->any =1 : $damage->any =0;
        $request->cash_credit == 'credit' ? $damage->credit =1 : $damage->credit =0;
        $damage->date = $request->date;
        $damage->remark1 = $request->remark1;
        $damage->discount = $request->discount;
        $damage->sub_total = $request->sub_total;
        $damage->grant_total = $request->grant_total;
        $damage->update();
 

        $purchases = DamageDetail::where('damage_id',$request->damage_id)->get();
        foreach ($purchases as $key => $value)
        {
            $value->delete();
        }

        foreach ($request->Products as $key => $value) {
            # code...
            $damage_details = new DamageDetail;
            $damage_details->damage_id = $damage->id;
            $damage_details->item_id = $value;
            $damage_details->unit = $request->unit[$key];
            $damage_details->quantity = $request->qty[$key];
            $damage_details->price = $request->price[$key];
            $damage_details->stock = $request->Stock[$key];
            $damage_details->invcost = $request->invCost[$key];
            $damage_details->total = $request->total[$key];
            $damage_details->save();

            // $item = Item::where('id',$value)->first();
            // $item_unit = ItemItemUnit::where('item_id',$value)->first();

            // if($request->old_qty[$key] > 0)
            // {
            //     if($request->qty[$key] > $request->old_qty[$key])
            //     {
            //         $delta = $request->qty[$key] - $request->old_qty[$key];
            //         $new_stock = $item_unit->minimum_stock - $delta;
            //     }
            //     else
            //     {
            //         $delta = $request->old_qty[$key] - $request->qty[$key];
            //         $new_stock = $item_unit->minimum_stock + $delta;
            //     }
            // }
            // else
            // {
            //     $new_stock = $item_unit->minimum_stock - $request->qty[$key];
            // }
            

            // DB::table('item_item_unit')->where([['item_id',$value],['item_unit_id',$request->unit[$key]]])->update(['minimum_stock' => $new_stock]);

        }

        return redirect()->route('edit-damage');
    }


    public function removeItem(Request $request)
    {
           
            $item = Item::where('id',$request->itemId)->first();
            $item_unit = ItemItemUnit::where('item_id',$request->itemId)->first();
            $new_stock = $item_unit->minimum_stock + $request->qty;

            DB::table('item_item_unit')->where([['item_id',$request->itemId],['item_unit_id',$request->unit]])->update(['minimum_stock' => $new_stock]);
            
            // $item_unit_id = $request->unit;
            // $arr[$item_unit_id] = ['minimum_stock' => $new_stock];
            // $item->itemUnit()->sync($arr,false);
            // return response()->json("Stock updated !!");

    }
    public function deleteDamage(Request $request)
    {
       Damage::where('id',$request->id)->delete();
       return response()->json("deleted");
        
    }
}
