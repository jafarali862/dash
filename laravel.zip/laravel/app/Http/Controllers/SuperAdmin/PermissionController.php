<?php

namespace App\Http\Controllers\SuperAdmin;

use Config;
use App\User;
use App\ShopUser;
use Session;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    protected $pos = 'permissions';

    public function index($search = null)
    {
        $query = User::query();

        if(!empty($search))
        {
            Session::put('search', $search);
            $query->where('name', 'like', '%' . Session::get('search') . '%');
        }
        else
        {
            Session::forget('search');
        }

        $page_name = $this->pos;

        $users = $query->where('role','shop')->latest('id')->paginate(3)->appends(Session::get('search'));
        
        $permissions = Config::get('permissionconst.permissions');
        
        return view('super-admin.permission.index', compact('page_name','permissions','users'));
    }

    public function accessPermission(Request $request)
    {
        $shop = User::find($request->shop_id);
        $permission = $request->permission_name;

        $shop->givePermissionTo([$permission]);

        $shop_users_ids = ShopUser::where('shop_id',$request->shop_id)->pluck('user_id');
        $shop_users = User::whereIn('id',$shop_users_ids)->get();

        foreach($shop_users as $user)
        {
            if($permission == 'sales'){
                $user->givePermissionTo(Config::get('permissionconst.sales_permissions'));
            }
            if($permission == 'purchase'){
                $user->givePermissionTo(Config::get('permissionconst.purchase_permissions'));
            }
            if($permission == 'master_data'){
                $user->givePermissionTo(Config::get('permissionconst.master_data_permissions'));
            }
            if($permission == 'accounts'){
                $user->givePermissionTo(Config::get('permissionconst.accounts_permissions'));
            }
            if($permission == 'reports'){
                $user->givePermissionTo(Config::get('permissionconst.reports_permissions'));
            }
            if($permission == 'admin'){
                $user->givePermissionTo(Config::get('permissionconst.admin_permissions'));
            }
        }

        return 'access';
    }

    public function revokePermission(Request $request)
    {
        $shop = User::find($request->shop_id);
        $permission = $request->permission_name;

        $shop->revokePermissionTo([$permission]);

        $shop_users_ids = ShopUser::where('shop_id',$request->shop_id)->pluck('user_id');
        $shop_users = User::whereIn('id',$shop_users_ids)->get();

        foreach($shop_users as $user)
        {
            if($permission == 'sales'){
                $user->revokePermissionTo(Config::get('permissionconst.sales_permissions'));
            }
            if($permission == 'purchase'){
                $user->revokePermissionTo(Config::get('permissionconst.purchase_permissions'));
            }
            if($permission == 'master_data'){
                $user->revokePermissionTo(Config::get('permissionconst.master_data_permissions'));
            }
            if($permission == 'accounts'){
                $user->revokePermissionTo(Config::get('permissionconst.accounts_permissions'));
            }
            if($permission == 'reports'){
                $user->revokePermissionTo(Config::get('permissionconst.reports_permissions'));
            }
            if($permission == 'admin'){
                $user->revokePermissionTo(Config::get('permissionconst.admin_permissions'));
            }
        }
        return 'revoked';
    }
}
