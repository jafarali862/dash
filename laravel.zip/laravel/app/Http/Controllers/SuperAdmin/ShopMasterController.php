<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Model\ShopMaster;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use Carbon\Carbon;
use Session;
use Illuminate\Support\Facades\Hash;
use Validator;

class ShopMasterController extends Controller
{
    protected $pos = 'shopRegistration';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $page_name = $this->pos;

        return view('super-admin.shop-master.index', compact('page_name'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $page_name = $this->pos;

        return view('super-admin.shop-master.create', compact('page_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make(request()->all(),[
            'email'      => 'required|email|unique:users',
        ]); 

        if($validator->fails())
        {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $request->payment_recieved ? $request['payment_recieved'] = 1 : $request['payment_recieved'] = 0; 

        $ShopMaster = new ShopMaster;
        $ShopMaster->name = $request->name;
        $ShopMaster->eng_description = $request->english_description;
        $ShopMaster->arabic_description = $request->arabic_description;
        $ShopMaster->line_1 = $request->line_1;
        $ShopMaster->line_2 = $request->line_2;
        $ShopMaster->city = $request->city;
        $ShopMaster->state = $request->state;
        $ShopMaster->country = $request->country;
        $ShopMaster->primary_phone = $request->primary_phone;
        $ShopMaster->secondary_phone = $request->secondary_phone;
        $ShopMaster->start_date = Carbon::now();
        $ShopMaster->expiry_date = Carbon::parse($request->expiry_date);
        $ShopMaster->payment_recieved = $request->payment_recieved;
        $ShopMaster->save();

        $user = new User;
        $user->name=$request->name;
        $user->email=$request->email;
        $user->password=Hash::make($request->password);
        $user->role = 'shop';
        $user->shop_master_id = $ShopMaster->id;
        $user->save();

        // giving permissions to users while creating
        $user->givePermissionTo(['sales','wms','purchase','master_data','accounts','reports','admin']);

        $request->session()->flash('message', 'New Record Created Successfully');

        if($request->save_only == "save_only")
        {
            return redirect()->route('shop-register.index');
        }else{
            return redirect()->route('shop-register.create');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\ShopMaster  $shopMaster
     * @return \Illuminate\Http\Response
     */
    public function show($shopMaster)
    {
          $shopMaster=ShopMaster::whereNotIn('id',[1])->get();   

       return Datatables::of($shopMaster)
           // adding the edit button to each rows
       ->addColumn('action_button', function ($shopMaster){
            return '<div class="btn-group">
                        <button type="button" class="btn btn-dark btn-sm">Open</button>
                        <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                          <a style="color:green;" class="dropdown-item btnEdit" href="'.route('shop-register.edit', $shopMaster->id).'">Edit</a>
                          <div class="dropdown-divider"></div>
                                <form action="'.route('shop-register.destroy', $shopMaster->id) .'" method="POST" id="form_id" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="'. csrf_token().'">
                                    <a style="color:red;" class="dropdown-item btnDelete" href="">Delete</a>
                                </form>
                            </div>
                        </div>';
        })
        ->editColumn('is_active', function($shopMaster)
               {
                return $shopMaster->is_active?' <label class="switch  s-outline  s-outline-success">
                                                    <input type="checkbox" class="changeStatus" checked onclick="changeStatus('.$shopMaster->id.',true)">
                                                    <span class="slider"></span>
                                                </label>' : '<label class="switch s-outline s-outline-success">
                                                    <input type="checkbox" class="changeStatus" onclick="changeStatus('.$shopMaster->id.',false)">
                                                    <span class="slider"></span>
                                                </label>';
               })
         ->editColumn('payment_recieved', function ($shopMaster) {
                       return $shopMaster->payment_recieved?  '<i class="far fa-check-circle fa-lg text-success"></i>' :  '<i class="far fa-lg fa-times-circle text-danger"></i>';
                    })

        ->addColumn('name', function ($shopMaster) {
                     return $shopMaster->user->name;
                    })
        ->addColumn('email', function ($shopMaster) {
                     return $shopMaster->user->email;
                    })
        ->addColumn('address', function ($shopMaster) {
                     $address=$shopMaster->line_1.','.$shopMaster->line_2.','.$shopMaster->city.','.$shopMaster->state;
                     return $address;
                    })
        ->addColumn('phone', function ($shopMaster) {
                     return $shopMaster->primary_phone;
                    })
        ->addColumn('expiry', function ($shopMaster) {
                     return $shopMaster->expiry_date;
                    })
       
          //serves to distinguish the inactive & active records

        //   // this is used to show inactive records in a disabled manner
        ->setRowClass(function($shopMaster) {
                    return $shopMaster->is_active?'':'bgdisable';
                     })

         // converts the raw html tags to real button entities
         ->rawColumns(['action_button','is_active','payment_recieved'])
         ->make(true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\ShopMaster  $shopMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(ShopMaster $shop_register)
    {
        $shopMaster = $shop_register;

        $page_name = $this->pos;

        return view('super-admin.shop-master.edit', compact('page_name','shopMaster'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\ShopMaster  $shopMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ShopMaster $shop_register)
    {
        $validator = Validator::make(request()->all(),[
            'email'   =>  'max:100|required|unique:users,email,'.$shop_register->id.',id',
        ]); 

        if($validator->fails())
        {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $request->payment_recieved ? $request['payment_recieved'] = 1 : $request['payment_recieved'] = 0; 

        $shop_register->name = $request->name;
        $shop_register->eng_description = $request->english_description;
        $shop_register->arabic_description = $request->arabic_description;
        $shop_register->line_1 = $request->line_1;
        $shop_register->line_2 = $request->line_2;
        $shop_register->city = $request->city;
        $shop_register->state = $request->state;
        $shop_register->country = $request->country;
        $shop_register->primary_phone = $request->primary_phone;
        $shop_register->secondary_phone = $request->secondary_phone;
        $shop_register->start_date = Carbon::now();
        $shop_register->expiry_date = Carbon::parse($request->expiry_date);
        $shop_register->payment_recieved = $request->payment_recieved;
        $shop_register->update();

        $user = User::where('shop_master_id',$shop_register->id)->first();
        $user->name=$request->name;
        $user->email=$request->email;
        
        if($request->password)
            $user->password=Hash::make($request->password);

        $user->update();

        $request->session()->flash('message', 'New Record Created Successfully');

        return redirect()->route('shop-register.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\ShopMaster  $shopMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(ShopMaster $shop_register)
    {
        $shop_register->delete();

        Session::flash('deleted', 'Deleted Successfully !!');

        return back();
    }

    // Status change
    public function statusChangeShop(Request $request)
    {
        if($request->status == 'true'){
            $item = ShopMaster::find($request->id);
            $item->is_active = 0;
            $item->update();
        }else{
            $item = ShopMaster::find($request->id);
            $item->is_active = 1;
            $item->update(); 
        }
        return response()->json('success',200);
    }
}
