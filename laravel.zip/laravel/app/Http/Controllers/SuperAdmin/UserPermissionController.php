<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Config;
use DB;
use Hash;
use Session;
use Illuminate\Http\Request;
use App\User;
use App\ShopUser;
use Validator;
use Spatie\Permission\Models\Permission;

class UserPermissionController extends Controller
{
    protected $pos = 'permissions';

    public function getUsers($id,$search = null)
    {
        $page_name = $this->pos;

        $query = ShopUser::query();

        if(!empty($search))
        {
            Session::put('searchuser', $search);
            $query->whereHas('shopUser', function ($user) {
                $user->where('users.name', 'like', '%' . Session::get('searchuser') . '%');
            });
        }
        else
        {
            Session::forget('searchuser');
        }

        $shop = User::findOrFail($id);

        $shop_name = $shop->name;

        $shop_id = $shop->id;

        $shop_users = $query->with('shopUser')->where('shop_id',$shop->id)->latest('id')->paginate(3)->appends(Session::get('searchuser'));

        $sales_permissons = Config::get('permissionconst.sales_permissions');
        // $wms_permissons = ['wms'];
        $purchase_permissions = Config::get('permissionconst.purchase_permissions');
        $master_data_permissions = Config::get('permissionconst.master_data_permissions');
        $accounts_permissions = Config::get('permissionconst.accounts_permissions');
        $reports_permissions = Config::get('permissionconst.reports_permissions');
        $admin_permissions = Config::get('permissionconst.admin_permissions');

        $permissons = Permission::pluck('name');
        
        return view('super-admin.permission.users', compact('page_name','shop','shop_id','shop_users','sales_permissons','purchase_permissions','master_data_permissions','accounts_permissions','reports_permissions','admin_permissions','permissons'));
    }

    public function addShopUser($id)
    {
        $page_name = $this->pos;

        $shop = User::find($id);
        return view('super-admin.permission.createshopuser', compact('page_name','shop'));
    }

    public function storeShopUser(Request $request,$id)
    {
        $validator = Validator::make(request()->all(),[
            'email'      => 'required|email|unique:users',
        ]); 

        if($validator->fails())
        {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $shop_details = User::findOrFail($id);

        DB::beginTransaction();
        try{
            $user = new User;
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->role = 'shop_user';
            $user->shop_master_id = $shop_details->id;
            $user->save();

            $shop_user = new ShopUser;
            $shop_user->shop_id =$shop_details->id;
            $shop_user->user_id =$user->id;
            $shop_user->is_active = 1;
            $shop_user->save();

            //finding shops permissions
            $shop_permissions = $shop_details->getDirectPermissions()->pluck('name')->toArray();
            
            if (in_array('sales', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.sales_permissions'));
            }
            if (in_array('wms', $shop_permissions)){
                $user->givePermissionTo(['wms']);
            }
            if (in_array('purchase', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.purchase_permissions'));
            }
            if (in_array('master_data', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.master_data_permissions'));
            }
            if (in_array('accounts', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.accounts_permissions'));
            }
            if (in_array('reports', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.reports_permissions'));
            }
            if (in_array('admin', $shop_permissions)){
                $user->givePermissionTo(Config::get('permissionconst.admin_permissions'));
            }
            
            DB::commit();
            $request->session()->flash('message', 'New Record Created Successfully');

            if($request->save_only == "save_only")
            {
                return redirect()->route('permissions.users',$shop_user->shop_id);
            }else{
                return redirect()->route('shopuser.create',$shop_user->shop_id);
            }
        }
        catch (\Exception $e)
        {
            DB::rollback();
            $request->session()->flash('error', 'Something went wrong');
            return redirect()->route('shopuser.create',$shop_user->shop_id);
        }
    }

    public function revokePermission(Request $request)
    {
        $shop_user = User::find($request->shop_user_id);
        $permission = str_replace('-', ' ', $request->permission_name);

        $shop_user->revokePermissionTo([$permission]);
        return 'revoked';
    }

    public function accessPermission(Request $request)
    {
        $shop_user = User::find($request->shop_user_id);
        $permission = str_replace('-', ' ', $request->permission_name);

        $shop_user->givePermissionTo([$permission]);
        return 'access';
    }

    public function changeShopUserStatus(Request $request)
    {
        $item = ShopUser::where('user_id',$request->shop_user_id)->first();

        if($item)
        {
            $item->is_active = $request->status == 'true' ? 1 : 0;
            $item->update();
    
            return response()->json('success',200);
        }
        return response()->json('failed',401);
    }

    public function deleteShopUserStatus(Request $request)
    {
        $shopuser = User::findOrFail($request->shop_user_id);
        $shopuser_relation = ShopUser::where('user_id',$request->shop_user_id)->first();

        if($shopuser && $shopuser_relation)
        {
            // $permissions = $shopuser->getAllPermissions();
            // $shopuser->revokePermissionTo($permissions);
            $shopuser->delete();
            $shopuser_relation->delete();
        }

        $request->session()->flash('message', 'User deleted Successfully');
        return redirect()->route('permissions.users',$request->shop_id);
    }
}
