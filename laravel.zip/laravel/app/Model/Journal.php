<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Journal extends Model
{
    public function journalDetails()
    {
    	return $this->hasMany(JournalEntries::class);
    }
}
