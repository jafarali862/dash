<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JournalEntries extends Model
{
    public function journal() {

   		return $this->belongsTo(Journal::class);
	}
}
