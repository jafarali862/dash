<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
	protected $table = "accounts";

    protected $fillable = [
        'id','english_desptn','arabic_desptn','accnt_type_id','address','phone','mobile','fax','email','contact_person','created_by','updated_by','status'
    ];

    public $timestamps = true;   
}
