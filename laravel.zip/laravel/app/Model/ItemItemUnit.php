<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ItemItemUnit extends Model
{
    protected $table = 'item_item_unit';

    protected $fillable = [
        'item_id','item_unit_id','cost','price','minimum_stock','is_view','quantity'
    ];
    
	// // Relationship to item model
	//    public function item() {
	//    		return $this->belongsTo(Item::class);
	// 	}

	// // Relationship to item unit model
	//    public function itemUnit() {
	//    		return $this->belongsTo(ItemUnit::class);
	// 	}
}
