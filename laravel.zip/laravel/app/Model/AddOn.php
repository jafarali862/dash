<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AddOn extends Model
{
    protected $table = "add_ons";

    protected $fillable = [
        'id','item_id','add_on_name','created_by','is_active'
    ];

    public $timestamps = true;   
}
