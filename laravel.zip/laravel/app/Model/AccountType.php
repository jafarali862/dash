<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{
    protected $fillable = [
        'id','english_desptn','arabic_desptn','type','created_by','status'
    ];

    protected $table = "account_types";
}
