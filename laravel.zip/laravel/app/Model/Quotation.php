<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Quotation extends Model
{
   public function quotationDetails()
    {
    	return $this->hasMany(QuotationDetail::class);
    }
}
