<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RestaurantInvoice extends Model
{
    protected $table = "restaurant_invoices";

    protected $fillable = [
        'id','invoice_number','date','cnt_no','customer_id','any','cash_or_card','po_no','del_no','remark1','remark2','phone_no','discount','sub_total','grant_total','created_by','status'
    ];

    public $timestamps = true;
}
