<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $table = "suppliers";

    protected $fillable = [
        'id','name','arabic_desptn','supplier_type_id ','eng_address','arab_address','email','phone','mobile','fax','cost_center','credit_limit','customer_link','vat_no','pmt_type','supplier_ref','is_active','created_by'
    ];
    public $timestamps = true;   
}
