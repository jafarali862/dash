<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Cash extends Model
{
	protected $table = "account_transaction";

    protected $fillable = [
        'id','doc_type','shop_id','doc_id','doc_date','trans_type','doc_ref','amount','remarks','cheque_no','cheque_date','trans_date','doc_status','flag','vat','account_id','user_id','description','bank_id','created_by','status'
    ];

    // Relationship to customer type model

    public function customerType() {

   		return $this->belongsTo(CustomerType::class);
	}
    
}
