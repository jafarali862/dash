<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ShopMaster extends Model
{
    protected $table = 'shop_masters';

    protected $fillable = [
        'name','photo','eng_description','arabic_description','line_1','line_2','city','state','country','primary_phone','secondary_phone','start_date','expiry_date','payment_recieved','is_active','fb_url','insta_url','tiwtter_url'
    ];

    public $timestamps = true;

  	//method for relationship to user model

    public function user(){

        return $this->hasOne('App\User');
    }

}
