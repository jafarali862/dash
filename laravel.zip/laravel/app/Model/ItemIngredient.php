<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ItemIngredient extends Model
{
    protected $table = 'ingredient_item';

    protected $fillable = [
        'item_id','ingredient_id','qty_used','created_by','is_active'
    ];

    public $timestamps = true;
}
