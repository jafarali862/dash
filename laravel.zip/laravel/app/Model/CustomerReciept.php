<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CustomerReciept extends Model
{
    //
}
