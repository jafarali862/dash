<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ItemGroup extends Model
{
    protected $table = 'item_groups';

    protected $fillable = [
        'english_description','arabic_description','group_type','is_active','created_by'
    ];

    public $timestamps = true;

   	public function save(array $options = array())
	{
	    $this->created_by = auth()->user()->shop_master_id;
	    parent::save($options);
	}

  	// Relationship to item model
   public function item() {

   		return $this->hasMany(Item::class);
	}
}
