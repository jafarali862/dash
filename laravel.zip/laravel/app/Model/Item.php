<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    protected $table = 'items';

    protected $fillable = [
        'english_description','arabic_description','english_short_description','arabic_short_description','vat','barcode','country_id','is_vat','is_active'
    ];

    public $timestamps = true;

  	// Relationship to item groups model
    public function itemGroup() {

   		return $this->belongsTo(ItemGroup::class);
	}

	//method for relationship to item uniit model
    
    public function itemUnit(){

        return $this->belongsToMany(ItemUnit::class)->withPivot('cost','price','quantity','minimum_stock','is_view');
    }

    public function ingredients()
    {
        return $this->belongsToMany(Ingredient::class);
    }
}
