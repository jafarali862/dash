<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AreaCode extends Model
{
	protected $table = "area_codes";

    protected $fillable = [
        'id','area_code','area_name','created_by','is_active'
    ];

    public $timestamps = true;   
}

