<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Quotation1 extends Model
{
    //
}
