<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
   public function invoiceDetails()
    {
    	return $this->hasMany(InvoicePurchaseDetail::class);
    }
}
