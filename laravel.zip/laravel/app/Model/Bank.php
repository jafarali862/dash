<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
	protected $table = "banks";
	
    protected $fillable = [
        'id','english_desptn','arabic_desptn','location','created_by','updated_by','status'
    ];
    
}
