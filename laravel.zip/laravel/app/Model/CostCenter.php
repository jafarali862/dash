<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CostCenter extends Model
{
    protected $table = "cost_centers";

    protected $fillable = [
        'id','name','created_by','is_active'
    ];

    public $timestamps = true;   
}
