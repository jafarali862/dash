<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubAccountType extends Model
{
    protected $table = "account_type_subs";

    protected $fillable = [
        'id','accnt_type_id','sub_accnt_name','created_by','status'
    ];

    public $timestamps = true;

}
