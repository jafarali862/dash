<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CustomerType extends Model
{
	protected $table = "customer_types";

    protected $fillable = [
        'id','english_desptn','arabic_desptn','status'
    ];

    // Relationship to customer model

    public function accounts() {

   		return $this->hasMany(AccountTransaction::class);
	}

	
    
}
