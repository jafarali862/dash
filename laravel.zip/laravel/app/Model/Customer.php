<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
	protected $table = "customers";

    protected $fillable = [
        'id','cust_type_id','shop_id','cust_name','english_short_desptn','arabic_short_desptn','english_addrs','arabic_addrs','credit_check','credit_hold','credit_limit','price_list_id','customer_ref','is_credit','point_type_id','area_code','english_desptn','arabic_desptn','phone','mobile','fax','email','created_by','updated_by','area_code','own_code','sales_man','cost_center','supplier_name','vist_date','status'
    ];

    // Relationship to customer type model

    public function customerType() {

   		return $this->belongsTo(CustomerType::class);
	}
    
}
