<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SupplierType extends Model
{
    protected $table = 'supplier_types';

    protected $fillable = [
        'english_desptn','arabic_desptn','status'
    ];

    public $timestamps = true;
}
