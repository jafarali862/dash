<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ItemUnit extends Model
{
    protected $table = 'item_units';

    protected $fillable = [
        'short_description','english_description','quantity','is_active','created_by'
    ];

    public $timestamps = true;

    public function save(array $options = array())
	{
	    $this->created_by = auth()->user()->shop_master_id;
	    parent::save($options);
	}

  	//method for relationship to item model

    public function item(){

        return $this->belongsToMany(Item::class)->withPivot('cost','price','quantity','minimum_stock','is_view');
    }
}
