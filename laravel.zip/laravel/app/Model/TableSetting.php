<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TableSetting extends Model
{
    protected $table = 'table_settings';

    protected $fillable = [
        'table_name','is_active'
    ];

    public $timestamps = true;
}
