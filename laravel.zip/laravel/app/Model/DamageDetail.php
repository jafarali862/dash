<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DamageDetail extends Model
{
    public function damage() {

   		return $this->belongsTo(Damage::class);
	}
}
