<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class InvoicePurchaseDetail extends Model
{
    public function invoice() {

   		return $this->belongsTo(Invoice::class);
	}
}
