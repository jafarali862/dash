<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrderType extends Model
{
    protected $table = 'order_types';

    protected $fillable = [
        'order_type','is_active'
    ];

    public $timestamps = true;
}
