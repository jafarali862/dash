<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SalesMan extends Model
{
    protected $table = "sales_men";

    protected $fillable = [
        'id','name','address','created_by','status'
    ];

    public $timestamps = true;  
}
