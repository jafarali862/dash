<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TokenSetting extends Model
{
    protected $table = 'token_settings';

    protected $fillable = [
        'token_start_no','start_time','end_time','created_by','is_active'
    ];

    public $timestamps = true;
}
