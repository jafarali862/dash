<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class WarehouseMaster extends Model
{
    //
}
