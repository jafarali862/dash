<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    protected $table = 'ingredients';

    protected $fillable = [
        'ingredient','min_stock','created_by','is_active'
    ];

    public $timestamps = true;

    public function items()
    {
        return $this->belongsToMany(Item::class);
    }
}
