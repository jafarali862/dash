<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Authentication extends Authenticatable
{
    use Notifiable;
    protected $fillable = [
        'name', 'username', 'password','role','login_token','last_login','login_ip','status'
    ];
    protected $hidden = [
        'password', 'login_token',
    ];
}
