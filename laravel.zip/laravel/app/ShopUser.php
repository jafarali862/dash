<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShopUser extends Model
{
	protected $fillable = [
        'shop_id','user_id'
    ];

    public function shopUser()
    {
        return $this->belongsTo('App\User','user_id')->where('role','shop_user');
    }

    public function shopDetail()
    {
        return $this->belongsTo('App\User','shop_id')->where('role','shop');
    }
}
